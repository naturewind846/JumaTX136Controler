///*************************************************************************************************
//
// Simple UART interface for dsPIC30F6012
// Juha Niinikoski, OH2NLT 18.05.2005
//
// Below is the code to initialize the USART
// 8 bits, 1 start and 1 stop, no error handling
// kbhit and getch added 22.05.2005
// getche added 02.06.2005
// overrun error handling added 29.08.2005
// MPLAB C30 conversion, OH2GWE 2006.10.17
// Baud Rate setup & IRQ receiver for fast baud rates 14.01.2008
// Adaptation to JUMA-PA100 board, FCY = 7,3728MHz, 07.07.2008
// UART init sequence changed 30.10.2008
// rx buffer pointer cast corrections 18.11.2008
//
// Program structure modified to improve readability and maintenance - F4GCB 02-2015
//
//*************************************************************************************************


#include <stdio.h>
#include <p30f6014A.h>

// Definitions ------------------------------------------------------------------------------------
#define BAUD_DEFAULT  3								// 9600

// Local variables --------------------------------------------------------------------------------
static volatile unsigned char rx_buffer[256];      	// UART mod(256) RX queue, must be exactly 256 long
static volatile unsigned char rx_buf_out_idx = 0;  	// buffer output index, pointer behind in idx
static volatile unsigned char rx_buf_in_idx = 1;   	// buffer input index, pointer always "leading"
static const unsigned int baud_rates[8] =			// Baud Rate divisors for 29,4912 MHz osc =  7,3728 MHz
	{383, 191, 95, 47, 23, 11, 7, 3};				// 1200>383, 2400>191, 4800>95, 9600>47, 19200>23, 38400>11, 57600>7, 115200>3


//=================================================================================================
// UART1 IRQ service
// put received character to RX queue
//=================================================================================================
void __attribute__((interrupt, no_auto_psv)) _U1RXInterrupt(void)
{
  	unsigned char rx;

  	rx = U1RXREG;                        							// data read
  	if((unsigned char)(rx_buf_in_idx + 1) != rx_buf_out_idx) 		// check overrun
  		rx_buffer[rx_buf_in_idx++] = rx;    						// place just received character in queue
 
	// check & handle possible errors
	if(U1STAbits.OERR == 1)											// OERR is blocking uart, should not happen but..
		U1STAbits.OERR = 0;											// reset overrun error if occured

	// this is not automatic in 30F6014 UART
	IFS0bits.U1RXIF = 0;											// reset irq flag
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// UART1 init
//=================================================================================================
void uart1_init(void)
{
	//U1BRG = ((FCY/16)/BAUD) - 1;   	// set baud rate
 	U1BRG = baud_rates[BAUD_DEFAULT];	// set intial baud rate to 9600

 	U1MODE = 0x0000;
 	U1STA = 0x0000;						// IRQ on every character
 	IFS0bits.U1RXIF = 0;				// clear possible pending irq
 	IEC0bits.U1RXIE = 1;				// enable RX IRQs
 	U1MODEbits.UARTEN = 1;				// enable uart
 	U1STAbits.UTXEN = 1;				// enable transmitter
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set baud rate
//=================================================================================================
void uart1_set_baud(int baud_sel)
{
	if(baud_sel > 7)
		baud_sel = 7;					// stay in the table

	 U1BRG = baud_rates[baud_sel];		// set baud rate
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Clear serial port, reset input buffer
//=================================================================================================
void uart1_clear(void)
{
	rx_buf_out_idx = 0;  				// buffer output index
	rx_buf_in_idx = 1;   				// buffer input index
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Print character
//=================================================================================================
void uart1_put_char(char c)
{
	while(U1STAbits.UTXBF == 1) {}		// wait here if tx fifo full
	U1TXREG = (int)c &0x00FF;			// Tx reg is 16-bit long
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Get char from RX queue, IRQ RX system
//=================================================================================================
unsigned char uart1_get_char(void)
{
 	while(((unsigned char)(rx_buf_out_idx + 1)) == rx_buf_in_idx);   	// wait data if queue is empty 
  	return rx_buffer[++rx_buf_out_idx];             					// return with data
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Check if key pressed, data available from receive buffer
// Not pressed = 0, Pressed = number of characters
// IRQ based RX queue check
//=================================================================================================
unsigned char uart1_kbhit(void)
{
	// return with number of available characters
  	return(unsigned char)((rx_buf_in_idx  - (unsigned char)(rx_buf_out_idx + 1)));
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Receive character with echo
//=================================================================================================
unsigned char uart1_get_checho(void)
{
	unsigned char c;
	uart1_put_char(c = uart1_get_char());
	return c;
}
//-------------------------------------------------------------------------------------------------


//*************************************************************************************************
// Special debug functions
//*************************************************************************************************

//=================================================================================================
// Get unsigned long
//=================================================================================================
unsigned long uart1_get_long(void)
{
	unsigned long val = 0;
	char tmp;
	
	do
	{
		tmp = uart1_get_char() & 0x7F;
		uart1_put_char(tmp);
		if(tmp >= '0' && tmp <= '9')
			val = 10 * val + (tmp - '0');
	}
	while (tmp != 0x0D);
	
	return(val);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Convert character to HEX nibble
//=================================================================================================
char cvt_hex(unsigned char ch)
{
	if (ch <= '9')
		return(ch - '0');
	if (ch <= 'F')
		return(ch - 'A' + 10);
	if (ch <= 'f')
		return(ch - 'a' + 10);
	return ' ';
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Get byte (2 hex characters)
//=================================================================================================
unsigned char uart1_get_2hex(void)
{
	unsigned char temp;
	char input, echo;

	echo = uart1_get_char();
	uart1_put_char(echo);
	input = cvt_hex(echo);
	temp = input;
	
	echo = uart1_get_char(); 
	uart1_put_char(echo);
	input = cvt_hex(echo);
	temp = temp * 16 + input;

	return(temp);
}
//-------------------------------------------------------------------------------------------------

//*************************************************************************************************
//
// JUMA-TX500/136 Transmitter Controller
// F4GCB 10.2014
//
// Microchip MPLAB + C30 compiler
// MCU dsPIC30F6014A
//
// Generates a WSPR message from call locator and power to a symbol/tone
//
// Acknowledgement :
// The WSPR message algorithm is derived from Fortran and C files found the K1JT WSPR source code. 
// Portions of the WSPR message algorithm is the work of Andy Talbot, G4JNT
// Portions of this code is derived from the work of Gene Marcus, W3PM
//
// Functions rewritten - F4GCB 02.2015
// Program structure modified to improve readability and maintenance - F4GCB 02-2015
// Add compound call and grid 6 checking - F4GCB 06-2016
// Some functions rewritten to save program memory space - F4GCB 10.2020
// Harmonization of timeslots control - F4GCB 10.2020
//
//*************************************************************************************************

#ifndef WSPR_H
#define WSPR_H

	// Variables
	extern int wspr_shift[4];												// TX WSPR shift for DDS

	// Functions
	extern int wspr_check_call(char *, int);								// Test the call validity (0=standard call, 1=compound call)
	extern int wspr_check_grid(char *, int);								// Test grid validity (0=grid 4, 1=grid 6)
	extern int wspr_ndbm(int);												// Standard dBm WSPR (types 0 3 7 10 13 17 ... 60)
	extern void wspr_init_beacon(const char *, const char *, const int);	// Init WSPR beacon							// Run WSPR beacon
	extern void wspr_sym_irq(void);											// Beacon WSPR generator
	extern char *wspr_get_code(char *);										// Return transmitted WSPR symbol value

#endif

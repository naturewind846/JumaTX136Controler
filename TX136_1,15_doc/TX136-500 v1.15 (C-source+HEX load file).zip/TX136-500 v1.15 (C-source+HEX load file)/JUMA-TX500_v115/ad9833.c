//*************************************************************************************************
//
// AD9833 DDS Driver for JUMA-TX500/136
//
// OH2NLT, Juha Niinikoski 14.01.2005
//
// Phase reg definitions corrected 19.01.2005
// Filter select flip-flop drive added 03.07.2005
// AUX output added 06.10.2005
// Flip-flop control corrected 13.10.2005
// TX500 version 09.06.2009
// Program structure modified to improve readability and maintenance - F4GCB 02-2015
//
//*************************************************************************************************

#include <p30f6014A.h>

// AD9833 DDS chip signals definitions ------------------------------------------------------------
#define AD_FSYNC	_LATB7
#define AD_SCLK		_LATB4
#define AD_SDATA	_LATB6

// AD9833 definitions -----------------------------------------------------------------------------
#define REG_SELECT	(3<<14)		// Register select mask
#define	FREQ0		(1<<14)		// Select FREQ0 register
#define	FREQ1		(2<<14)		// select FREQ1 register
#define	PHASE0		0xC000		// select PHASE0 register
#define	PHASE1		0xE000		// select PHASE1 register

// Control register bits --------------------------------------------------------------------------
#define	B28			(1<<13)
#define	HLB			(1<<12)
#define	FSELECT		(1<<11)
#define	PSELECT		(1<<10)
#define	ADRESET		(1<<8)
#define	SLEEP1		(1<<7)
#define	SLEEP12		(1<<6)
#define	OPBITEN		(1<<5)
#define	DIV2		(1<<3)
#define	ADMODE		(1<<1)

// Mode select combinations -----------------------------------------------------------------------
#define AD_RUN		0x0000		// Control register bits for normal Run mode
	

//=================================================================================================
// Send 16-bits to AD9833 chip
//=================================================================================================
void send_ad9833(unsigned int dta)
{
	char x;
	AD_FSYNC = 1;					// set start condition
	AD_SCLK = 1;
	AD_FSYNC = 0;					// start frame
	for(x=0; x<16; x++)
	{
		if((dta & 0x8000) == 0)	// set data
			AD_SDATA = 0;
		else
			AD_SDATA = 1;

		AD_SCLK = 0;				// generate clock pulse
		asm("nop");
		AD_SCLK = 1;

		dta = dta << 1;				// next bit
	}

	AD_FSYNC = 1;					// end frame
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Send tuning word to AD9833 chip
//=================================================================================================
void tune_ad9833(unsigned long tw)
{
	unsigned int temp;
	temp = (tw >> 14) & 0x3FFF;		// filter upper 14 bits

	send_ad9833(AD_RUN | HLB);		// select MSB
	send_ad9833(temp | FREQ0);		// write to FEQ0 register
	temp = tw & 0x3FFF;				// filter lower 14 bits
	send_ad9833(AD_RUN);			// select LSB
	send_ad9833(temp | FREQ0);		// write to FEQ0 register
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Setup & start AD9833 chip
//=================================================================================================
void init_ad9833(void)
{
	send_ad9833(ADRESET);			// keep chip in reset state	
	send_ad9833(PHASE0);			// clear PHASE0 register

	tune_ad9833(0);					// Set start up frequency & start DDS
}
//-------------------------------------------------------------------------------------------------

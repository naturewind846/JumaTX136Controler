//*************************************************************************************************
//
// JUMA TX500 & TX136 Transmitter Controller
// Juha Niinikoski, OH2NLT 06.07.2008
//
// Microchip MPLAB + C30 compiler
// MCU dsPIC30F6014A
//
// speed tune added, calibration constants changed 24.08.2009
// 136kHz / 500kHz ref osc selection added 31.08.2009
// command clean up, beacon test play, bug fixes 10.09.2009
// Beacon repeat count logic added 14.09.2009
// More morse characters coded 15.09.2009
// Scandi character LCD display, more TX500 protocol commands, Beacon auto start after power failure 16.09.2009
// very slow CW keyer speed, downto 0.1 wpm 20.09.2009
// CW speed user interface setup limited down to 1 wpm 23.09.2009
// Band limits set  SW v1.00, 10.10.2009
// Beacon end quick TX release 11.10.2009, SW v1.01
// Beacon Transmit =BT command added 15.10.2009, SW v1.02
// beacon message '=' and '?' character behaviour corrected 17.10.2009 SW v1.03
// 0.1 wpm CW bug corrected, beep(int, unsigned int), cw_period => unsigned int  24.03.2010
// Add QRSS and DFCW modes, SW 1.05a - F4GCB 08.2014
// Add WSPR mode, SW 1.06a - F4GCB 10.2014
// Bug fixed: add init WSPR beacon for automatically restart, SW 1.06b - F4GCB 12.2014
// Add declarations to avoid compilation warnings - F4GCB 12-2014
// Program structure modified to improve readability and maintenance - F4GCB 02-2015
// Add setting configuration values - F4GCB 02-2015
// Add OPERA mode - F4GCB 05.2015
// Add JASON mode, SW 1.07 - F4GCB 08.2015
// Add CW identity option - F4GCB 04.2016
// Add SCRIPT mode - F4GCB 04.2016
// Limit EEPROM writing to preserve byte endurance, SW 1.08 - F4GCB 05.2016
// Add WSQ mode - F4GCB 06.2016
// PTT management modified - F4GCB 06.2016
// Add REMOTE mode - F4GCB 06.2016
// Improve JUMA software interface - F4GCB 06.2016
// Extended use of callsign and locator - F4GCB 06.2016
// Add JT9 mode - F4GCB 07.2016
// Alarm for unavailable call or grid - F4GCB 09.2016
// Bug fixed : with GPS synchronization, the counter.ms could skip the set by IRQ, SW 1.09 - F4GCB 09-2016
// Add optional bi-band board control, SW 1.10 - F4GCB 11-2018
// Add tune on/off with CW UP/DOWN buttons, SW 1.10 - F4GCB 11-2018
// Some functions rewritten to save program memory space - F4GCB 10.2020
// Harmonization of timeslots control - F4GCB 10.2020
// Add FST4W mode, SW 1.11 - F4GCB 10.2020
// Bug fixed : no TX FST4W shifts initialization, only when FST4W speed change, SW 1.12 - F4GCB 12.2020
// Bug fixed : TX freeze (need to off/on) if alarm during tune in script mode - F4GCB 12.2021
// Bug fixed : TX continously with TX x1 frame and CW identity available - F4GCB 12.2021
// Improvement of script management - F4GCB 12.2021
// Add AFP interface via REMOTE mode, SW 1.13 - F4GCB 12.2021
// Bug fixed : occasional 1s delay on the next frame waiting time if GPS synchronization , SW 1.14 - F4GCB 10.2022
// Bug fixed : bad management of some keys in configuration mode due function pointers which have NULL value - F4GCB 12.2022
// Add GPS time display for SWR, current and relay alarms - F4GCB 12.2022
// Bug fixed : bad management in tune operating mode after stopping script
// Bug fixed : incomplete OPER button management after stopping script, SW 1.15 - F4GCB 04.2023
//
//*************************************************************************************************

#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "juma-tx500.h"						// JUMA-TRX2 hardware specific definitions
#include "eeprom_tx500.h"
#include "lcd_tx500.h"						// LCD specific definitions
#include "serial_test.h"
#include "serial_tx500.h"
#include "ad9833.h"
#include "gene_fst4w.h"
#include "gene_jason.h"
#include "gene_jt9.h"
#include "gene_morse.h"
#include "gene_opera.h"
#include "gene_wspr.h"
#include "gene_wsq.h"
#include "timers_pwm.h"
#include "uart.h"
#include "uart2.h"

// Definitions ------------------------------------------------------------------------------------
#define MAX_LCD_MODE 1						// last display "main" page			/
#define	MAX_SUB_PAGE0 4						// sub page 0 displays				|
#define	MAX_SUB_PAGE1 13					// sub page 1 displays				|> display control
#define	MAX_SUB_PAGE2 7						// sub page 2 displays				|
#define S_BAR 0x07							// S-meter vertical bar character	/
#define MAX_SERVICE_PAGES 8					// number of display pages for service mode


// ????? ------------------------------------------------------------------------------------------ 
_FOSC(CSW_FSCM_OFF & XT_PLL4);				// 7,3728MHz XT, 29,4912MHz clock = 7,3728MHz cycle
//_FOSC(CSW_FSCM_OFF & XT_PLL8);			// 3,68640MHz XT, 29,4912MHz clock = 7,3728MHz cycle
_FWDT(WDT_OFF);                				//Turn off the Watch-Dog Timer.
_FBORPOR(MCLR_EN & PWRT_64 & BORV_20);   	//Enable MCLR, power on timer, brown out 2V
//_FBORPOR(MCLR_EN & PWRT_64 & BORV_27);   	//Enable MCLR, power on timer, brown out 2V
//_FGS(GEN_PROT);            				//Disable Code Protection, old compiler
_FBS(CODE_PROT_OFF);
_FSS(CODE_PROT_OFF);
_FGS(CODE_PROT_OFF);


// Constant variables -----------------------------------------------------------------------------
const char ver[] = {"1.15"};			// software version information, displayed at startup
const char date[] = {"13.02.2023"};		// version date


// Global variables -------------------------------------------------------------------------------
int board_type;							// main board type, 1=TX500, 2=TX136, 3=TX500-136, 4=TX136-500, 0=unknown
unsigned int alarms;					// alarm bits
int cw_active;							// cw active flag for keyer code
int keyer_mode;							// keyer mode selector
int key;								// TX request status
char message[MSG_BUFFER_SIZE + 1];		// message buffer from JUMA software
int afp_ptt;							// PTT via AFP interface (1=active)
int afp_serial;							// serial port AFP running (1=active)


// Local variables --------------------------------------------------------------------------------
static int fcy;							// clock / kHz
static int service_mode;				// service mode selected flag
static int alarm_beep;					// alarm beep logic flag
static int alarm_rly = 0;				// alarm antenna relay counter

static int lcd_mode;					// lcd display mode 0=Display 1=Config 2=Mode setup
static int sub_page0;					// lcd display sub page for lcd_mode0
static int sub_mode;					// lcd display sub mode for lcd_mode0
static int sub_page1;					// lcd display sub page for lcd_mode1
static int sub_page2;					// lcd display sub page for lcd_mode2

static int batt_samples = 0;			// battery voltage meter
static unsigned long batt_mean = 0;
static long out_pwr;					// scaled output power = fwd_pwr - rev_pwr * scale
static long peak_pwr;					// peak, fast attach slow decay power
static int swr;							// calculated swr * 100
static int old_swr;						// for alarm trigger
static int pwr_meter;					// scaled S-meter value 0 ... 48 

static char beacon_lcd[300];			// beacon message for display
static int beacon_lcd_idx;				// beacon message display index
static int beacon_lcd_roll	;			// speed flag for rolling beacon message display
static int lcd_blink;					// speed flag for lcd blink
static char alarm_time[7];				// GPS time alarm

static const char br_txt[8][8] = {{"1200  "}, {"2400  "}, {"4800  "} ,{"9600  "}, {"19200 "}, {"38400 "}, {"57600 "}, {"115200 "}}; // Baud rate

static char mode_display[11][6] = {		// Mode display
	"CW   ",
	"QRSS ",
	"DFCW ",
	"JSON ",
	"WSQ2 ",
	"OPRA ",
	"WSPR ",
	"FS4W ",
	"JT9  ",
	"SCRI ",
	"REM  "};
static int sub_mode_menu[11][7] = {		// menu display validation by mode (various, fsk , frame, text, beacon in progress, script running, script wait time)
	{1, 0, 1, 1, 0, 0, 0},				// CW mode
	{1, 0, 1, 1, 0, 0, 0},				// QRSS mode
	{1, 1, 1, 1, 0, 0, 0},				// DFCW mode
	{1, 0, 1, 1, 0, 0, 0},				// JASON mode
	{0, 0, 1, 1, 0, 0, 0},				// WSQ mode
	{1, 0, 1, 1, 0, 0, 0},				// OPERA mode
	{1, 0, 1, 1, 0, 0, 0},				// WSPR mode
	{1, 0, 1, 1, 0, 0, 0},				// FST4W mode
	{1, 0, 1, 1, 0, 0, 0},				// JT9 mode
	{1, 0, 0, 1, 0, 0, 0},				// SCRIPT mode
	{1, 0, 0, 0, 0, 0, 0}};				// REMOTE mode
static int sub_page0_timer[11] = {		// sub_page0 display timer by mode
	0,									// CW mode	 
	0,									// QRSS mode
	0,									// DFCW mode
	0,									// JASON mode
	0,									// WSQ mode
	0,									// OPERA mode
	1,									// WSPR mode
	1,									// FST4W mode
	1,									// JT9 mode
	1,									// SCRIPT mode
	0};									// REMOTE mode
static int sub_page2_init[11] = {		// sub_page2 initialization by mode
	0,									// CW mode									 
	1,									// QRSS mode
	1,									// DFCW mode
	1,									// JASON mode
	1,									// WSQ mode
	2,									// OPERA mode
	2,									// WSPR mode
	2,									// FST4W mode
	2,									// JT9 mode
	7,									// SCRIPT mode
	0};									// REMOTE mode


// Local functions --------------------------------------------------------------------------------
static void service(void);							// Service & calibration functions, when tested move to own module
static void disp_timer(int);						// Display WSPR timer


// Local function pointers to replace switch/case and save program memory space -------------------
static void (*key_x[8])(int, int, int) = {	// select key by sub_page2
	key_cw_beacon,
	key_beacon,
	key_call,
	key_grid,
	NULL,
	NULL,
	NULL,
	key_script};
static void (*set_sub_mode0[11])(int, int, int, int) = {	// select function by mode
	set_cw_speed,
	set_dot_time,
	set_dot_time,
	set_jason_speed,
	NULL,
	set_opera_speed,
	set_wspr_speed,
	set_fst4w_speed,
	set_jt9_speed,
	set_script_frame,
	set_rem_soft};
static void (*set_cal_x[8])(int, int, int, int) = {	// select calibration by cal_page
	set_cal_oscillator,								// local oscillator
	set_cal_batt,									// battery voltage
	set_cal_beep,									// beep length
	set_cal_fwr_pwr,								// Forward power scaling
	set_cal_id,										// ID scaling
	set_cal_cw_break,								// CW break period
	set_cal_ms_offset,								// offset for WSPR timer
	set_cal_power_q4};								// jumper Q4 value
			

// External functions -----------------------------------------------------------------------------
extern void us_delay( unsigned int);		// delay routines
extern void ms_delay( unsigned int);

extern void init_adc12(void);				// ADC routines
extern int convert_adc12(unsigned int);


//*************************************************************************************************
// On/Off, Alarms and RS232 test functions
//*************************************************************************************************

//=================================================================================================
// Handle PWR button. Shut down the system
//=================================================================================================
void power_off(void)
{
	const char line1[] = {"Pwr OFF after %ld "};
	const char line2[] = {"                "};
	char buffer[17];

	beep(HZ466_85, cal.calval.beep_len);								// notify PWR button pressed
	ms_delay(250);

	lcd_clear();
	counter.push = POWER_OFF;											// load power off guard timer

	while (PWR_SW == 1)
	{
		sprintf(buffer, line1, (counter.push/300));						// display off counter, 3,2,1,0
		lcd_display_all(buffer, line2);

		if (counter.push == 0)
		{
			beep(HZ392_01, cal.calval.beep_len*2);						// play low sound when ready for power down
			while (PWR_SW == 1) {};
		}
	}

	if (counter.push != 0)												// too short push, continue normal operation
		return;

	if (!cal.calval.power_q4)											// start always in standby mode
		set_pa_state(STATE_STBY, 1, 0, 0);
	save_defaults();
	//save_beacon();
	//save_script();
 	if (eeprom.defval.serial_mode == 1)	// conditional print only if RS232 = Test
		printf("\n\rUser settings saved to EEPROM, Power off\n\r");

	ms_delay(2);														// let the printout finish
	PWR_ON = 0;
	for (;;) {};
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set PTT according to PA state and mode
//=================================================================================================
void set_ptt(void)
{
	if (eeprom.defval.pa_state == STATE_OPER)
	{
		if (eeprom.defval.mode == MODE_REM && eeprom.defval.rem_soft < REM_AFP)
			set.ptt = PTT_RTS;
		else
			set.ptt = eeprom.defval.mox;
	}
	else
		set.ptt = PTT_AUTO;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Check if any alarms
//=================================================================================================
void check_alarms(void)
{
	const char gps_hour[] = {" %.2d%.2d "};

	// check over current alarm bit & set alarm
	if (OC)
	{
		CW = 0;									// RF off immediately
		alarms = alarms | CURR_AL;				// set alarm flag
	}

	// check SWR, two samples neded for trip
	// Note, SWR alarm is active also in STBY
	if (swr > eeprom.defval.swr_limit[eeprom.defval.rfpwr] && old_swr > eeprom.defval.swr_limit[eeprom.defval.rfpwr])
	{
		CW = 0;									// RF off immediately
		alarms = alarms | SWR_AL;				// set alarm flag
	}

	// check if ptt is on (antenne relay on) when PA power on
	// twice needed for trip
	if (CW && !key)
	{
		if (alarm_rly++ > 1)
		{
			CW = 0;								// RF off immediately
			alarms = alarms | RLY_AL;			// set alarm flag
		}
	}
	else
		alarm_rly = 0;

	if (alarms != 0)
	{
		stop_keyer();
		lcd_mode = 0;							// force normal display
		set_pa_state(STATE_STBY, 1, 0, 0);		// force transmitter to STBY
		if (eeprom.defval.beacon_tx_on)			// force beacon Off
			set_beacon_on_off(0, 0);
		if (eeprom.defval.script_on)			// force script Off
			set_script_on_off(0, 0);
		set.ptt = PTT_AUTO;						// diseable PTT
		if (counter.gps)						// if GPS available
			sprintf(alarm_time, gps_hour, counter.gps_hour, (counter.sync / 60));
		else
			sprintf(alarm_time, "      ");
			
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Clear alarms & try to reset over current latch
//=================================================================================================
void clear_alarms(void)
{
	alarms = 0;									// clear alarm flags
	alarm_beep = 0;

	OC_CLR = 0;									// generate reset pulse for over current latch
	ms_delay(20);
	OC_CLR = 1;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// RS232 loop back test
//=================================================================================================
void rs232_test(void)
{
	unsigned char c;
	const char line1[] = {"RS232 Test      "};
	const char line2[] = {"Waiting data...."};
	const char data[] = {"RX data  %c  0x%x"};
	char buffer[17];

	lcd_clear();
	lcd_display_all(line1, line2);

	for (;;)
	{
		if (uart1_kbhit())
		{
			c = uart1_get_char();
			beep(HZ698_45, 10);				// give beep tone
			uart1_put_char(c);				// echo character
			sprintf(buffer, data, c, c);
			lcd_display_line(2, buffer);
		}

		if (PWR_SW == 1)						// exit test
			break;
	}
}
//-------------------------------------------------------------------------------------------------


//*************************************************************************************************
// Calculate and measure values
//*************************************************************************************************

//=================================================================================================
// Check I/O board type
//=================================================================================================
int check_io_board_type(void)
{
	int x, b;

	x = convert_adc12(B_TYPE);					// get board ID voltage
	b = UNKNOWN_TYPE;							// board identified

	if (x > TX500_LOW && x < TX500_HI)			// is it TX500
		b = TX500_TYPE;

	if (x > TX136_LOW && x < TX136_HI)			// is it TX136
		b = TX136_TYPE;	

	if (x > TX500_136_LOW && x < TX500_136_HI)	// is it TX500-136 (TX500 with bi-band board)
		b = TX500_136_TYPE;

	if (x > TX136_500_LOW && x < TX136_500_HI)	// is it TX136-500 (TX136 with bi-band board)
		b = TX136_500_TYPE;

	return b;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Calculate SWR
//=================================================================================================
int calc_swr(int fwd, int rev)
{
	int swr;						// swr calculated
	long Ro100;						// 100*Ro
	long x;							// 100*(1-Ro)

	old_swr = swr;

	//  rev/fwd ratio * 100
	Ro100 = ((long)rev * 100L) / fwd;
	x = 100 - Ro100;

	// prevent divide by zero
	if (x < 1)
		x = 1;

	// calculate only if we have some signal
	if (fwd >= 50)
		// 100 * (1+Ro)/(1-Ro)
		swr = (((100 + Ro100)*100) / x);
	else
		// no swr reading if low power
		swr = 0;

	// max display value 99.99
	if (swr > 9999)
		swr = 9999;

	// value 100 = swr 1.00
	return swr;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Power measurements
//=================================================================================================
void power_measurements(void)
{
	int fwd_adval, rev_adval;
	long fwd_pwr, rev_pwr;

	// convert fwd & rev A/D channells
	fwd_adval = convert_adc12(FWD_PWR);
	rev_adval = convert_adc12(REV_PWR);

	// store not scaled values for later use
	// calculate relative power levels (U^2)
	fwd_pwr = (long)fwd_adval * (long)fwd_adval;
	rev_pwr = (long)rev_adval * (long)rev_adval;

	// output power = forward - reverse.
	out_pwr = fwd_pwr - rev_pwr;

	// forward voltage display
	pwr_meter = (fwd_adval * F_VOLT_GRAPH_MULT) >> 17;

	// shift sample queue and calculate SWR
	old_swr = swr;
	swr = calc_swr(fwd_adval, rev_adval);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Get output power
//=================================================================================================
int get_out_pwr(void)
{
	return (out_pwr * cal.calval.fwd_pwr_mult) >> 16;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Get SWR
//=================================================================================================
int get_swr(void)
{
	return swr;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Measure battery voltage
//=================================================================================================
unsigned long meas_batt_volt(void)
{
	return ((unsigned long)convert_adc12(BATT_CH) * cal.calval.batt_mult) >> 8;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Measure drain current
//=================================================================================================
long meas_id(void)
{
	return ((long)convert_adc12(ID_CUR) * cal.calval.id_mult) >> 16;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// decrease dBm level in function TX power for WSPR mode
//=================================================================================================
int ndbm_rfpwr(void)
{
	int nu_rfpwr[4] = {13,6,3,0};

	return wspr_ndbm(eeprom.defval.wspr_ndbm - nu_rfpwr[eeprom.defval.rfpwr]);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Get TX500/136 info
//=================================================================================================
char *get_info(char *info)
{
	char type[5][11] = {
		{"UNKNOWN"},
		{"JUMA-TX500"},
		{"JUMA-TX136"},
		{"TX500-136 "},
		{"TX136-500 "}};

	sprintf(info, "%s, SW %s, DATE %s", type[board_type], ver, date);

	return info;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Sub mode menu initialization
//=================================================================================================
void init_sub_mode(void)
{
	sub_mode = 0;
	while(!sub_mode_menu[eeprom.defval.mode][sub_mode])
		sub_mode++;
	
}
//-------------------------------------------------------------------------------------------------


//*************************************************************************************************
// Beacon management
//*************************************************************************************************

//=================================================================================================
// Get standard callsign
//=================================================================================================
char *get_std_call(char *std_call)
{
	int i, pos = 0;

	strcpy(std_call, eeprom.defval.call);

	for (i=0; i<strlen(std_call); i++)				// find the only slash position
		if (std_call[i] == '/')
			if (!pos)
				pos = i;

	if (!pos)									// no slash
		return std_call;
	else if (pos < 4)							// prefix
	{
		for (i=0; i<strlen(std_call)-pos-1; i++)
			std_call[i] = std_call[i+pos+1];
		std_call[i] = 0x00;
	}
	else										// suffix
		std_call[pos] = 0x00;

	return std_call;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Get locator with grid 6 according to gps availability
//=================================================================================================
char *get_grid6(char *grid6)
{
	if (eeprom.defval.gps == 1 && counter.gps)
		return get_gps_grid6(grid6);
	
	return strcpy(grid6, eeprom.defval.grid);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Get locator with grid 4 according to gps availability
//=================================================================================================
char *get_grid4(char *grid4)
{
	if (eeprom.defval.gps == 1 && counter.gps)
		return get_gps_grid4(grid4);
	
	strncpy(grid4, eeprom.defval.grid, 4);
	grid4[4] = 0x00;

	return grid4;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Get JT9 message (13 characters) from callsign and locator
//=================================================================================================
char *get_jt9_msg(char *text)
{
	char call[11], grid[7];

	if (strlen(eeprom.defval.call) < 6)
	{
		strcat(text, eeprom.defval.call);
		strcat(text, " ");
		strcat(text, get_grid6(grid));
	}
	else if (strlen(eeprom.defval.call) < 8)
	{
		strcat(text, eeprom.defval.call);
		strcat(text, " ");
		strcat(text, get_grid4(grid));
	}
	else
	{
		strcat(text, get_std_call(call));
		strcat(text, " ");
		strcat(text, get_grid4(grid));
	}
	strcat(text, " ");
		
	return text;
}
//------------------------------------------------------------------------------------------------


//=================================================================================================
// Get cw beacon, beacon and message text according to the call and locator tags
//=================================================================================================
char *get_text_tag(char *buffer, int size, char *text)
{
	int i, idx = 0;
	char grid6[7];

	for (i=0; i<strlen(buffer); i++)
	{
		// call tag
		if (buffer[i] == '#' && buffer[i+1] == 'C' && (strlen(text) + strlen(eeprom.defval.call)) < size)
		{
			strcat(text, eeprom.defval.call);
			idx += strlen(eeprom.defval.call);
			i++;
		}
		// locator tag
		else if (buffer[i] == '#' && buffer[i+1] == 'L'&& strlen(text) + 6 < size)
		{
			strcat(text, get_grid6(grid6));
			idx += 6;
			i++;
		}
		// beacon text
		else if ((strlen(text) + 1) < size)
		{
			text[idx] = buffer[i];
			idx++;
		}	
	}
	text[idx] = 0x00;
	
	return text;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set synchronization timer
//=================================================================================================
void set_sync_timer(int value, int new_val, int gps, int irq, int beep_on, int display_on)
{
	const char line1[17] = {"Synchro Timer   "};

	// set synchronization timer value by GPS
	if (gps)
	{
		// case where the counter.ms can skip the set by IRQ
		if ((value - counter.sync == 1) || (value - counter.sync == -3599))
		{
			counter.s++;
			if (counter.s == 36000)			// max 10 hours
				counter.s = 0;
			if (counter.script)
				counter.script--;
		}

        counter.sync = value;

		// set timers_pwm and gps synchronization counters
		counter.ms = 1000 - irq;
		counter.ms_offset = 0;
		counter.gps = 3;
	}

	// set synchronization timer value by IRQ
    else if (irq)
        counter.sync = counter.sync + value;

	// set synchronization timer value
	else if (new_val && counter.gps == 0)
	{
		counter.sync = value;

		// set timers_pwm counters
        counter.ms = 1000;
		counter.ms_offset = 0;
	}
		
	// set synchronization timer value by button (set minutes only)
	else if (value && counter.gps == 0)
	{
		counter.sync = ((counter.sync / 60) + value) * 60;

		// set timers_pwm counters
        counter.ms = 1000;
		counter.ms_offset = 0;
	}

	if (value && !gps)
	{
        // check value
        if (counter.sync >= 3600)
			counter.sync = 0;
		else if (counter.sync <= -1)
			counter.sync = 3540;

        // sound tone for each second (help to set manually)
        if (beep_on && !counter.gps && lcd_mode == 1 && sub_page1 == 2)
			beep_up_down(&value);
	}

	if (display_on)
	{
		lcd_display_line(1, line1);
		disp_timer(1);
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Init beacon
//=================================================================================================
void init_beacon(void)
{
	int cwid_speed[3] = {0, 120, 240};
	char text[CW_BEACON_BUFFER_SIZE] = {0}, buffer[48], std_call[11], grid4[5];
	char cmd_cwid[10];
	char cmd_cw[5];
	char cmd_mode[4];

	// define commands and place escape sequences for CW identity
	if (eeprom.defval.cwid)
	{
		sprintf(cmd_cwid, "%cs%3d", 0x5C, cwid_speed[eeprom.defval.cwid]);
		sprintf(cmd_cw, "%cs%3d", 0x5C, eeprom.defval.cw_speed);
		sprintf(cmd_mode, "%cg%1d", 0x5C, eeprom.defval.mode);
	}
 
	switch (eeprom.defval.mode)
	{
		case MODE_CW: default:
			morse_init_beacon(get_text_tag(cw_beacon_buffer, CW_BEACON_BUFFER_SIZE, text));
		break;

		case MODE_QRSS: case MODE_DFCW:
			if (eeprom.defval.cwid)					// CW identity available
			{
				sprintf(buffer, "%s%s %s %s%s", get_text_tag(beacon_buffer, BEACON_BUFFER_SIZE*2, text), cmd_cwid, eeprom.defval.call,
					cmd_cw, cmd_mode); 
				flag.cwid = 1;
			}
			else
			{
				strcpy(buffer, get_text_tag(beacon_buffer, BEACON_BUFFER_SIZE*2, text));
				flag.cwid = 0;
			}
			morse_init_beacon(buffer);
		break;

		case MODE_JASON:
			jason_init_beacon(get_text_tag(beacon_buffer, BEACON_BUFFER_SIZE*2, text));
		break;

		case MODE_WSQ:
			wsq_init_beacon(get_text_tag(beacon_buffer, BEACON_BUFFER_SIZE*2, text));
		break;

		case MODE_OPERA:
			opera_init_beacon(get_std_call(std_call));
		break;

		case MODE_WSPR:
			wspr_init_beacon(get_std_call(std_call), get_grid4(grid4), ndbm_rfpwr());
		break;

		case MODE_FST4W:
			fst4w_init_beacon(get_std_call(std_call), get_grid4(grid4), ndbm_rfpwr());
		break;

		case MODE_JT9:
			jt9_init_beacon(get_jt9_msg(text));
		break;
	}

	// CW identity available
	if (eeprom.defval.cwid && eeprom.defval.mode > MODE_DFCW)
	{
		sprintf(buffer, "%s %s %s%s", cmd_cwid, eeprom.defval.call, cmd_cw, cmd_mode);
		morse_init_beacon(buffer);
		flag.cwid = 1;
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Init message
//=================================================================================================
void init_message(void)
{
	int cwid_speed[3] = {0, 120, 240};
	char text[MSG_BUFFER_SIZE] = {0}, buffer[MSG_BUFFER_SIZE + 20];
	char cmd_cwid[10];
	char cmd_cw[5];
	char cmd_mode[4];

	// define commands and place escape sequences for CW identity
	if (eeprom.defval.cwid)
	{
		sprintf(cmd_cwid, "%cs%3d", 0x5C, cwid_speed[eeprom.defval.cwid]);
		sprintf(cmd_cw, "%cs%3d", 0x5C, eeprom.defval.cw_speed);
		sprintf(cmd_mode, "%cg%1d", 0x5C, eeprom.defval.mode);
	}
 
	switch (eeprom.defval.mode)
	{
		case MODE_CW: default:
			morse_init_beacon(get_text_tag(message, MSG_BUFFER_SIZE, text));
		break;

		case MODE_QRSS: case MODE_DFCW:
			if (eeprom.defval.cwid)					// CW identity available
			{
				sprintf(buffer, "%s%s %s %s%s", get_text_tag(message, MSG_BUFFER_SIZE, text), cmd_cwid, eeprom.defval.call,
					cmd_cw, cmd_mode); 
				flag.cwid = 1;
			}
			else
				sprintf(buffer, get_text_tag(message, MSG_BUFFER_SIZE, text));
			morse_init_beacon(buffer);
		break;

		case MODE_JASON:
			jason_init_beacon(get_text_tag(message, MSG_BUFFER_SIZE, text));
		break;

		case MODE_WSQ:
			wsq_init_beacon(get_text_tag(message, MSG_BUFFER_SIZE, text));
		break;

		case MODE_JT9:
			jt9_init_beacon(get_text_tag(message, MSG_BUFFER_SIZE, text));
		break;
	}

	// CW identity available
	if (eeprom.defval.cwid && eeprom.defval.mode > MODE_DFCW)
	{
		sprintf(buffer, "%s %s %s%s", cmd_cwid, eeprom.defval.call, cmd_cw, cmd_mode);
		morse_init_beacon(buffer);
		flag.cwid = 1;
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set beacon on/off
//=================================================================================================
void set_beacon_on_off(int tx_on, int beep_on)
{
	const int tone = TONE_B;
	int *mode_frame[9] = {
		&eeprom.defval.cw_frame,
		&eeprom.defval.cw_frame,
		&eeprom.defval.cw_frame,
		&eeprom.defval.jason_frame,
		&eeprom.defval.wsq_frame,
		&eeprom.defval.opera_frame,
		&eeprom.defval.wspr_frame,
		&eeprom.defval.fst4w_frame,
		&eeprom.defval.jt9_frame};

	if (tx_on == -1)							// message transmission with the juma-tx136-500 control software
	{
		switch (eeprom.defval.mode)				// only for CW, QRSS, DFCW, JASON, WSQ and JT9 modes

		{
			case MODE_OPERA: case MODE_WSPR: case MODE_FST4W: case MODE_SCRIPT: case MODE_REM:
				return;
			break;

			default:
				flag.msg = 1;
			break;
		}
	}
											
	// beacon was off
	if (tx_on && !eeprom.defval.beacon_tx_on)
	{
		if (tx_on >= 1)
			init_beacon();
		else
			init_message();
		flag.beacon = 1;
		flag.ptt = 0;											// beacon run via ptt
		old.mode = eeprom.defval.mode;
		old.pa_state = eeprom.defval.pa_state;
		old.keyer = keyer_mode;

		switch (eeprom.defval.mode)
		{
			case MODE_CW: case MODE_QRSS: case MODE_DFCW: case MODE_JASON: case MODE_WSQ: case MODE_JT9:
				if ((*mode_frame[eeprom.defval.mode] == 0 || tx_on == -1) && !eeprom.defval.script_on)
					set_beacon_tx(1, 1);						// one play or message from JUMA software
				else if (eeprom.defval.script_on)
					set_beacon_tx(tx_on, 1);					// n play according to the script
				else
					set_beacon_tx(-1, 1);						// continuous play according to the frame	
			break;

			case MODE_OPERA: case MODE_WSPR: case MODE_FST4W:
				if (*mode_frame[eeprom.defval.mode] == 0 && !eeprom.defval.script_on)
					set_beacon_tx(1, 1);						// one play
				else if (eeprom.defval.script_on)
					set_beacon_tx(tx_on, 1);					// n play according to the script
				else
					set_beacon_tx(-1, 1);						// continuous play according to the frame
			break;
		}

		set_pa_state(STATE_OPER, 1, 0, 0);					// force OPER
		set_cw_keyer(KEYER_BEACON , 1, 0, 0);				// force CW keyer mode = Beacon
		if (cal.calval.power_q4 && !eeprom.defval.script_on)
			save_defaults();								// save system state, beacon restart automatically after power failure
		set.cw_break = cal.calval.cw_break_time * 4;		// extended cw break time
		sub_mode_menu[eeprom.defval.mode][4] = 1;			// beacon in progress display
		sub_mode = 4;
		ts.on = 0;											// init timeslot parameters
		ts.end = 0;
		ts.cwid = 0;
		if (!(eeprom.defval.script_on && set.ts == old.ts))	// if script and no timeslot difference : no timeslot restarting
			ts.next = 0;
	}

	// beacon was on
	else
	{
		stop_keyer();
		set_beacon_tx(0, 1);									// turn it off
		counter.cw_break = 10;									// fast release 10 ms
		set.cw_break = cal.calval.cw_break_time;				// normal cw break time
		encoder_get();											// clear encoder
		sub_mode_menu[eeprom.defval.mode][4] = 0;				// any more beacon in progress display
		init_sub_mode();
		flag.msg = 0;
		flag.ptt = 0;											// beacon stopped via ptt
		if (flag.cwid)
		{
			set_mode(old.mode, 1, 0, 0);						// if beacon stopped during cwid tx
			flag.cwid = 0;
		}
		old.ts = set.ts;
	}

	if (beep_on && !eeprom.defval.script_on)
		beep(tone, cal.calval.beep_len*10);						// long beep for Beacon mode change
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Beacon timeslots control
//=================================================================================================
int beacon_ts(int frame, int period, int sync, int delay)
{
	// wait for machine free
	if (ts.on)
		return 0;

	// for CWID only
	if (ts.cwid && !ts.end)
	{
		ts.on = 1;
		return 0;
	}

	if (ts.end)
	{
		ts.end = 0;
		ts.period = counter.s;
		return 1;
	}
	
	// if not a given timeslot
	if (!period)
		period = ts.period;
	// check timer for timeslot starting
	if (ts.next)
	{
		if (counter.s >= frame * period)
			ts.on = 1;
		else
			ts.wait = (frame * period) - counter.s;
	}
	// timeslot starting synchronized
	else if (sync)
	{
		if (!((counter.sync - delay - period) % period))
			ts.on = 1;
		else
		{
			ts.wait = ((((counter.sync / period) + 1) * period) + delay) - counter.sync;
			if (!(counter.sync % period))
				ts.wait -= period;
		}
	}
	// timeslot starting
	else
		ts.on = 1;


	// enable TX according to the frame
	if (ts.on)
	{
		ts.next = 1;
		counter.s = 0;
	}

	return 0;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Run beacon
//=================================================================================================
void run_beacon(void)
{
	int on = 0;

	switch (eeprom.defval.mode)
	{
		case MODE_CW: case MODE_QRSS: case MODE_DFCW: default:
			if (beacon_ts(eeprom.defval.cw_frame, set.ts, 0, 0))
				set_beacon_tx(-1,0);
		break;

		case MODE_JASON:
			on = beacon_ts(eeprom.defval.jason_frame, set.ts, 0, 0);
		break;

		case MODE_WSQ:
			on = beacon_ts(eeprom.defval.wsq_frame, set.ts, 0, 0);
		break;

		case MODE_OPERA:
			on = beacon_ts(eeprom.defval.opera_frame, set.ts, 0, 0);
		break;

		case MODE_WSPR:
			on = beacon_ts(eeprom.defval.wspr_frame, set.ts, 1, 1);
		break;

		case MODE_FST4W:
			on = beacon_ts(eeprom.defval.fst4w_frame, set.ts, 1, 1);
		break;

		case MODE_JT9:
			on = beacon_ts(eeprom.defval.jt9_frame, set.ts, 1, 1);
		break;
	}
	if (on)
	{
		if (flag.cwid && !ts.cwid)
		{
			set_mode(MODE_CW, 1, 0, 0);
			ts.cwid = 1;
		}
		else if (ts.cwid)
		{
			ts.cwid = 0;
			set_beacon_tx(-1, 0);
		}
		else
			set_beacon_tx(-1, 0);
			
	}
	if (eeprom.defval.beacon_tx_on == 0)
		set_beacon_on_off(0,1);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set script on/off
//=================================================================================================
void set_script_on_off(int on, int beep_on)
{
	const int tone = TONE_B;
	int i;

	// script was off
	if (on && !eeprom.defval.script_on)
	{
		serial_script_init(script_buffer);
		old.ts = -1;										// timeslot restarting
		flag.ptt = 0;										// script run via ptt
		if (eeprom.defval.script_frame == 0)
			set_script_on(1, 1);							// one play
		else
			set_script_on(-1, 1);							// continuous play
		if (cal.calval.power_q4)
			save_defaults();								// save system state, beacon restart automatically after power failure
		for (i=0; i<=MODE_JT9; i++)							// force script display for all modes
			sub_mode_menu[i][5] = 1;
	}

	// script was on
	else
	{
		stop_keyer();
		set_script_on(0, 1);
		counter.script = 0;
		set_mode(MODE_SCRIPT, 1, 0, 0);
		sub_mode = 0;
		flag.ptt = 0;										// script stopped via ptt
		for (i=0; i<=MODE_JT9; i++)							// any more script display
			sub_mode_menu[i][5] = 0;
		for (i=0; i<=MODE_SCRIPT; i++)						// any more script wait time display
			sub_mode_menu[i][6] = 0;
	}

	if (beep_on)
		beep(tone, cal.calval.beep_len*10);					// long beep for script mode change
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Run script
//=================================================================================================
void run_script(void)
{
	int i;

	// if beacon in progress, no script reading
	if (eeprom.defval.beacon_tx_on == 0)
	{
		// script wait time
		if (counter.script)
		{
			if (!sub_mode_menu[MODE_SCRIPT][6])
			{
				for (i=0; i<=MODE_SCRIPT; i++)					// force script wait time display
					sub_mode_menu[i][6] = 1;
				sub_mode = 6;
			}
			return;
		}
		else if (sub_mode_menu[MODE_SCRIPT][6])
		{
			for (i=0; i<=MODE_SCRIPT; i++)						// any more script wait time display
				sub_mode_menu[i][6] = 0;
		}

		// script reading
		if (serial_script_run() && eeprom.defval.script_frame == 0)
			set_script_on_off(0,1);
	}
}
//-------------------------------------------------------------------------------------------------


//*************************************************************************************************
// Display functions
//*************************************************************************************************

//=================================================================================================
// Display hello message
//=================================================================================================
void disp_hello(void)
{
	const char line1[5][14] = {
		{"JUMA ????? %s"},
		{"JUMA TX500 %s"},
		{"JUMA TX136 %s"},
		{" TX500-136 %s"},
		{" TX136-500 %s"}};
	const char line2[] = {"  OH2NLT OH7SV  "};
	char buffer[17];

	lcd_clear();
	sprintf(buffer, line1[board_type], ver);
	lcd_display_all(buffer, line2);
}
//-------------------------------------------------------------------------------------------------


//*************************************************************************************************
// Display meter functions
//*************************************************************************************************

//=================================================================================================
// Display alarms
//=================================================================================================
void disp_alarms(void)
{
	if(flag.blink == 0)
	{
		if((alarms & SWR_AL) || (alarms & CURR_AL) || (alarms & RLY_AL))
			lcd_display_at(2, 5, alarm_time);			// show alarm time
		else
			lcd_display_at(2, 5, "      ");			// show nothing
		alarm_beep = 0;
	}
	else										// show alarm, only highest priority is shown
	{
		if(alarm_beep == 0)						// trigger with rising edge
		{
			alarm_beep = 1;
			beep(HZ698_45, ALARM_BEEP_LEN);		// make sound
		}
		if(alarms & SWR_AL)
			lcd_display_at(2, 5, " SWR  ");
		else if(alarms & CURR_AL)
			lcd_display_at(2, 5, " CURR ");
		else if (alarms & MSG_AL)
			lcd_display_at(2, 5, " MSG  ");
		else if (alarms & CALL_AL)
			lcd_display_at(2, 5, " CALL ");
		else if (alarms & LOC_AL)
			lcd_display_at(2, 5, " LOC  ");
		else if (alarms & RLY_AL)
			lcd_display_at(2, 5, " RLY  ");
		else if (alarms & OUT_BD_AL)
			lcd_display_at(2, 5, " BAND ");
		else
			lcd_display_at(2, 5, " ???? ");		// unknown
		lcd_cursor_on(2, 5, 0);					// cursor off if alarm in beacon configuration mode
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Display watt meter
//=================================================================================================
void disp_fwd_pwr(void)
{
	long decay_term;
	double temp;
	const char ok_pwr[] = {"P %4.1fW"};
	char buffer[9];

	if(key)													// TXon ?
	{
		if(out_pwr > peak_pwr)								// fast attach
		{
			peak_pwr = out_pwr;								// fast attach
			counter.decay = PEAK_SHOW_TIME;					// reload decay timer
		}
		else												// slow release
		{
			if(counter.decay == 0)
			{
				counter.decay = DECAY_TIME;					// reload decay timer
				decay_term = peak_pwr >> DECAY_RATE;

				if(decay_term == 0)							// zero reached
					peak_pwr = 0;
				else
					peak_pwr = peak_pwr - decay_term;		// decay
			}
		}
		temp = (peak_pwr * cal.calval.fwd_pwr_mult) >> 16;	// scaling, P*100 = ADC^2 * scaling / 65536
		sprintf(buffer, ok_pwr, temp / 10);
		lcd_display_at(1, 10, buffer);
	}
	else
	{
		set_tx_power(0, 0, 0, 1);							// display setting
		peak_pwr = 0;
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Display SWR meter
//=================================================================================================
void disp_swr(void)
{
	const char no_swr[] = {"SWR N/A"};
	const char ok_swr[] = {"SWR%4.1f"};
	char buffer[9];

	if(key)								// TXon ?
	{
		sprintf(buffer, ok_swr, (double)swr / 100);
		lcd_display_at(1, 10, buffer);
	}
	else
		lcd_display_at(1, 10, no_swr);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Display battery voltage meter
//=================================================================================================
void disp_batt_volt(void)
{
	const char batt[] = {" %5.2fV"};
	char buffer[9];

	if(batt_samples > 15)									// 16 samples done ?
	{
		sprintf(buffer, batt, (double)batt_mean / 1600);
		lcd_display_at(1, 10, buffer);
		batt_samples = 0;
		batt_mean = 0;
	}
	else
	{
		batt_mean += meas_batt_volt();						// measure & add
		batt_samples++;										// add sample counter
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Display Drain current meter
//=================================================================================================
void disp_id(void)
{
	const char no_id_cur[] = {"I --.-A"};
	const char ok_id_cur[] = {"I %4.1fA"};
	char buffer[9];

	if(key)								// TXon ?
	{
		sprintf(buffer, ok_id_cur, (double)meas_id() / 10);
		lcd_display_at(1, 10, buffer);
	}
	else
		lcd_display_at(1, 10, no_id_cur);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Display WSPR timer
//=================================================================================================
void disp_timer(int area)
{
	const char no_gps[] = {"T %.2d:%.2d   "};
	const char ok_gps[] = {"T^%.2d:%.2d   "};
	const char ok_gps_hour[] = {"T^%.2d:%.2d:%.2d"};
	char buffer[12];

	if (counter.gps)
		if (area)
			sprintf(buffer, ok_gps_hour, counter.gps_hour, (counter.sync / 60), (counter.sync % 60));
		else
			sprintf(buffer, ok_gps, (counter.sync / 60), (counter.sync % 60));
	else
		sprintf(buffer, no_gps, (counter.sync / 60), (counter.sync % 60));

	if (area)
	{
		lcd_display_line(2, buffer);
		lcd_display_at(2, 11, "      ");
	}
	else
		lcd_display_at(1, 10, buffer);

}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Display beacon message in progress
//=================================================================================================
void disp_beacon_in_progress(void)
{
	char buffer[10]= "         ";
	char* (*display_x[9])(char*) = {		// display function pointers by mode
		morse_get_display,
		morse_get_display,
		morse_get_display,
		jason_get_display,
		wsq_get_display,
		opera_get_code,
		wspr_get_code,
		fst4w_get_code,
		jt9_get_code};

	if (eeprom.defval.beacon_tx_on == 0)
	{
		init_sub_mode();
		return;
	}
	lcd_display_at(1, 1, display_x[eeprom.defval.mode](buffer));
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Display AFP bandwith in progress
//=================================================================================================
void disp_afp_tone(void)
{
	char buffer[10];

	lcd_display_at(1, 0, afp_get_tone(buffer));
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Display beacon message to transmit
//=================================================================================================
void disp_beacon_lcd(int mode)
{
	int i;
	char text[CW_BEACON_BUFFER_SIZE] = {0}, std_call[11], grid4[5], buffer[9];

	if (beacon_lcd_roll != flag.roll)					// speed for rolling display
	{
		if (!mode) mode = eeprom.defval.mode;
		switch (mode)
		{
			case MODE_CW: default:
				if (flag.cwid)
					sprintf(beacon_lcd, "    Id [%s]       ", eeprom.defval.call);
				else
					sprintf(beacon_lcd, "    Text [%s]       ", get_text_tag(cw_beacon_buffer, CW_BEACON_BUFFER_SIZE, text));
			break;

			case MODE_QRSS: case MODE_DFCW: case MODE_JASON: case MODE_WSQ:
				if (eeprom.defval.cwid)
					sprintf(beacon_lcd, "    Text [%s]+Id       ", get_text_tag(beacon_buffer, BEACON_BUFFER_SIZE*2, text));
				else
					sprintf(beacon_lcd, "    Text [%s]       ", get_text_tag(beacon_buffer, BEACON_BUFFER_SIZE*2, text));
			break;

			case MODE_OPERA:
				if (eeprom.defval.cwid)
					sprintf(beacon_lcd, "    Text [%s]+Id       ", get_std_call(std_call));
				else
					sprintf(beacon_lcd, "    Text [%s]       ", get_std_call(std_call));
			break;

			case MODE_WSPR: case MODE_FST4W:
				if (eeprom.defval.cwid)
					sprintf(beacon_lcd, "    Text [%s %s %d]+Id       ", get_std_call(std_call), get_grid4(grid4), ndbm_rfpwr());
				else
					sprintf(beacon_lcd, "    Text [%s %s %d]       ", get_std_call(std_call), get_grid4(grid4), ndbm_rfpwr());
			break;

			case MODE_JT9:
				if (eeprom.defval.cwid)
					sprintf(beacon_lcd, "    Text [%s]+Id       ", get_jt9_msg(text));
				else
					sprintf(beacon_lcd, "    Text [%s]       ", get_jt9_msg(text));
			break;

			case MODE_SCRIPT:
				sprintf(beacon_lcd, "    Script [%s]       ", script_buffer);
				if (eeprom.defval.script_on)			//  last command executed in the script
					beacon_lcd[get_script_next() + 12] = '<';
			break;
		}

		beacon_lcd_roll = flag.roll;
		for (i=0; i<8; i++)
			buffer[i] = beacon_lcd[i+beacon_lcd_idx];
		buffer[8] = ' ';
		lcd_display_at(1, 1, buffer);

		if (beacon_lcd_idx < strlen(beacon_lcd) - 8)
			beacon_lcd_idx++;
		else
			beacon_lcd_idx = 0;
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// main
//=================================================================================================
int main(void)
{

//*************************************************************************************************
// ----------> Main first init part
//*************************************************************************************************

	int temp;
	unsigned int y, w;

	// set general I/O
	TRISA = INIT_TRISA;				// SWITCHES, PTT
	PORTA = INIT_PORTA;

	TRISB = INIT_TRISB;				// ADC inputs, TXEN, RXEN, General I/O
	PORTB = INIT_PORTB;

	TRISC = INIT_TRISC;				// sideband select & switches
	PORTC = INIT_PORTC;

	TRISD = INIT_TRISD;				// LEDs & LCD pins = output
	PORTD = INIT_PORTD;

	TRISF = INIT_TRISF;				// DDS controls
	PORTF = INIT_PORTF;

	TRISG = INIT_TRISG;				// DDS controls, EEPROM, DScard signals
	PORTG = INIT_PORTG;

	// Power switch
	PWR_ON = 1;								// secure power ON

	// start PWM system
	set.cw_period = 100;					// set something before timer system starts
	//IPC0 =0X5444;							// set tone generator (TMR1) priority higher than others
	init_timers_pwm();						// setup pwm & tone generators
	fcy = FCY / 1000;						// clock freq (kHz)

	// start LCD
	lcd_init();								// init LCD
	lcd_set_chgen();						// load bar graph fonts

	// start UART
	uart1_init();							// wake up serial interfaces
	uart2_init();

	// start ADC
	init_adc12();							// setup A/D converter, must be done before Keyer is started, RB I/O bits

	// check I/O boards
	board_type = check_io_board_type();		// measure & set main board type

	// put hello messages to LCD
	disp_hello();

	// Read calibration & default values from EEPROM
	y = read_calval();
	w = read_defaults();
 	if (eeprom.defval.serial_mode == 1)		// conditional print only if RS232 = Test
		printf("\n\rEEPROM checksums, Cal = %X, Def Cs = %X, Factory default resets = %d\n\r",y, w, fd_counter);
	if (y != 0 || w != 0)					// compare checksums
	{
		if(eeprom.defval.serial_mode == 1)	// conditional print only if RS232 = Test
		{
			dump_eeprom();					// test, show EEPROM content before reset
			printf("\n\rEEPROM checksum error, reload factory defaults");
		}

		set_factory_defaults();				// EEPROM empty or corrupted, set factory defaults
		save_calval();
		save_defaults();
	}

	// set LCD contrast & back light with EEPROM data
	set_pwm4_dac(eeprom.defval.contrast);
	set_pwm3_dac(eeprom.defval.back_light);

	// set display mode etc
	lcd_mode = 0;									// select default display
	sub_page0 = 0;
	init_sub_mode();
	sub_page1 = 0;
	sub_page2 = 0;
	beacon_lcd_idx = 0;

	// start up beep
	beep(HZ698_45, cal.calval.beep_len * 2);		// give start up beep

	OC_CLR = 0;										// clear over current latch
	ms_delay(1);
	OC_CLR = 1;

	// set user baud rate
	ms_delay(20);									// wait TX empty
	uart1_set_baud(eeprom.defval.br);

	// CW identification flag for CW mode
	flag.cwid = 0;
	
	// temporay storage for ptt
	old.key = 0;

	// conditional start up text printout, print only if RS232 = Test
 	if(eeprom.defval.serial_mode == 1)
	{
		switch(board_type)							// select hello message by board type
		{
			case TX500_TYPE:
				printf("\n\r\n\rJUMA TX500 / ");
			break;

			case TX136_TYPE:
				printf("\n\r\n\rJUMA TX136 / ");
			break;

			case TX500_136_TYPE:
				printf("\n\r\n\rJUMA TX500-136 / ");
			break;

			case TX136_500_TYPE:
				printf("\n\r\n\rJUMA TX136-500 / ");
			break;

			case UNKNOWN_TYPE: default:
				printf("\n\r\n\rJUMA Unknown Main Board type/ ");
			break;
		}
		printf(ver);
		printf(" / ");
		printf(date);
		printf("\n\rCopyright Juha Niinikoski, OH2NLT\n\r\n\r");
		printf("System Clock = %i kHz\n\r", fcy);

		// serial baud rate info
		if(eeprom.defval.br != DEFAULT_BAUD_RATE)
			printf("\n\rSet UART user baud rate to #%i,  %sbd\n\r", eeprom.defval.br, br_txt[eeprom.defval.br]);	// print with user baud rate

		printf("\n\rCW break time set to %i units", cal.calval.cw_break_time);	// show CW break time setup
	}


//*********************************************************************************************
// ----------> Do front panel switches during startup
//*********************************************************************************************

	//-----------------------------------------------------------------------------------------
	// POWER swith long push (service mode)
	//-----------------------------------------------------------------------------------------
	service_mode = 0;
	counter.push = VERY_LONG_PUSH;									// set long push timer
	while(PWR_SW == 1)
	{
		if(counter.push == 0)
		{
			beep(HZ392_01, 300);									// give service beep
			lcd_display_line(2, "Service Mode    ");
			ms_delay(1000);
			service_mode = 1;

			while(PWR_SW == 1) 										// show message as login as Power switch is pressed
				lcd_display_all("Push DISPLAY nxt", "Push OPER = Save");// display some instructions
		}
	}
	if(service_mode != 0)											// do calibration functions if service mode start
		service();

	//-----------------------------------------------------------------------------------------
	// OPER swith long push (factory defaults)
	//-----------------------------------------------------------------------------------------
	while(OPER == 0)								// if OPER button pressed ask user what to do
	{
		lcd_display_all("Push RF PWR for ", "factory defaults");
		if(RFPWR == 0)								// factory defaults asked
		{
			set_factory_defaults();					// EEPROM empty, set factory defaults
			save_calval();
			save_defaults();
			break;
		}
	}

	//-----------------------------------------------------------------------------------------
	// DISP swith long push (RS232 I/O test)
	//-----------------------------------------------------------------------------------------
	if(DISP == 0)						// If Config/DISPLAY pressed during startup
		rs232_test();					// goto RS232 test loop


//*************************************************************************************************
// ----------> Main second init part after possible new calibration values setting
//*************************************************************************************************

	// main board relays
	set_tx_power(0, 0, 0, 0);					// RF power selector
	set_preamp(0, 0, 0, 0);						// set pre amplifier
	set_converter(0, 0, 0, 0);					// select up converter
	set_spare_io(0, 0, 0, 0);					// set SPARE digital I/O state or optional bi-band board

	// PTT
	PTT_OUT_1 = 0;
	PTT_OUT_2 = 0;

	// AFP remote
	afp_serial = 0;
	afp_ptt = 0;

	// start DDS
	calc_hz_bit();								// calculate Hz/bit from ref osc actual value
	freq_band();								// Define frequency according to the band
	calc_tword();								// calculate DDS set value
	calc_tword_hi();							// calculate DDS high TX frequency
	calc_morse_shift();							// calcultate TX MORSE shift for DDS
	calc_jason_shift(eeprom.defval.jason_speed);// calcultate TX JASON shift for DDS
	calc_wsq_shift();							// calcultate TX WSQ shift for DDS
	calc_wspr_shifts();							// calcultate TX WSPR shifts for DDS
	calc_fst4w_shifts();						// calcultate TX FST4W shifts for DDS
	calc_jt9_shifts();							// calcultate TX JT9 shifts for DDS
	init_ad9833();
	tune_ad9833(0);								// keep DDS stopped for now

	// keyer setup
	set.cw_break = cal.calval.cw_break_time; 	// normal cw break time
	calc_cw_period();							// calculate CW period value(ms)
	calc_sidetone();							// calculate sidetone timer value
	read_cw_beacon();							// read CW beacon message from the EEPROM
	read_beacon();								// read beacon message from the EEPROM
	read_script();								// read script from the EEPROM
	if (eeprom.defval.beacon_tx_on && cal.calval.power_q4 && eeprom.defval.mode != MODE_REM)
	{
		init_beacon();							// init beacon for automatically restart
		if (eeprom.defval.mode == MODE_DFCW)	// display beacon in progress
			sub_mode = 4;
		else if (eeprom.defval.mode == MODE_WSQ)
			sub_mode = 2;
		else
			sub_mode = 3;
	}
	else
		set_beacon_tx(0, 1);					// if shutdown done during TX
	if (eeprom.defval.script_on && cal.calval.power_q4)
		serial_script_init(script_buffer);		// init script for automatically restart

	ms_delay(2000);								// show start up message

	if(board_type == UNKNOWN_TYPE)				// stop here if unknown board
	{
		printf("\n\r\n\rUnknown main board type, press OPER to continue anyway\n\r");
		lcd_display_at(1, 0, "OPER = Continue ");
		while(OPER == 1) {}						// can continue with OPER button
	}

	// start with clean display
	lcd_clear();


//*************************************************************************************************
// ----------> Main forever loop
//*************************************************************************************************
	for(;;)
	{
		MAIN_TEST = !MAIN_TEST;				// timing test

		// Check alarm conditions
		check_alarms();						// check if any alarms

		set_ptt();
		// Make atomic copy of KEY (TX request) signal for this user interface processing round
		key = PTT_OUT_1;					// 1 = active

		// if ptt changes then flag to run beacon or script once
		if (key != old.key)
		{
			flag.ptt = 1;
			old.key = key;
		}	

		// Set keyer active flag
		if(eeprom.defval.pa_state)			// OPER or TUNE
			cw_active = 1;					// cw active flag for keyer code
		else								// Standby
			cw_active = 0;					// no TX allowed

		// set keyer mode
		if(eeprom.defval.pa_state == STATE_TUNE)		// if TUNE selected
			keyer_mode = KEYER_STRAIGHT;				// force straight
		else if(eeprom.defval.mode == MODE_CW)			// CW mode
			keyer_mode = eeprom.defval.cw_keyer;
		else											// other beacon modes
			keyer_mode = KEYER_BEACON;

		// Measurements & basic calculations
		power_measurements();

	
	//---------------------------------------------------------------------------------------------
	// PTT IN
	//---------------------------------------------------------------------------------------------
	if (eeprom.defval.mode != MODE_REM && set.ptt != PTT_AUTO && keyer_mode == KEYER_BEACON)
	{
		if (alarms)
			set_pa_state(STATE_STBY, 1, 1, 1);				// if active alarms, always change to standby state
		else if (key && flag.ptt)
		{
			if (eeprom.defval.mode == MODE_SCRIPT)
				set_script_on_off(1, 1);
			else
				set_beacon_on_off(1, 1);
		}
		else if (!key && flag.ptt)
		{
			if (eeprom.defval.beacon_tx_on)
				set_beacon_on_off(0, 0);
			if (eeprom.defval.script_on)
				set_script_on_off(0, 0);
			beep(TONE_B, cal.calval.beep_len*10);		
		}
	}

	//*********************************************************************************************
	// ----------> Do front panel switches
	//*********************************************************************************************

		//-----------------------------------------------------------------------------------------
		// DISPLAY / CONFIG
		//-----------------------------------------------------------------------------------------
		if (DISP == 0)													// SW1
		{
			ms_delay(BUTTON_DEBOUNCE);
			counter.push = LONG_PUSH;									// set long push timer
	
			if (lcd_mode == 0 && (sub_page0 == MAX_SUB_PAGE0 || !(sub_page0_timer[eeprom.defval.mode] && sub_page0 == MAX_SUB_PAGE0-1)))
				beep(TONE_C, cal.calval.beep_len);						// C tone for basic display
			else
			{
				if (lcd_mode == 1 && (sub_page1 == MAX_SUB_PAGE1 || (board_type >= TX500_136_TYPE && sub_page1 == MAX_SUB_PAGE1-1) 
					|| (lcd_mode == 2 && sub_page2 == MAX_SUB_PAGE2)))
					beep(TONE_C, cal.calval.beep_len);					// C tone for basic display
				else
					beep(TONE_D, cal.calval.beep_len);					// D tone beep for other displays
			}

			while(DISP == 0)
				if (!counter.push && !eeprom.defval.beacon_tx_on && !eeprom.defval.script_on && !key) 	// key for mode REMOTE
				{
					beep(TONE_C, cal.calval.beep_len*10);				// long beep for major page change
					break;
				}

			if (!counter.push && !eeprom.defval.beacon_tx_on && !eeprom.defval.script_on && !key)		// major mode change
			{
				lcd_mode++;
				if (lcd_mode > MAX_LCD_MODE)
				{
					lcd_mode = 0;
					lcd_cursor_on(1, 1, 0);
					check_call();
					check_grid();
					//save_defaults();
					if (cw_beacon_flg) save_cw_beacon();
					if (beacon_flg) save_beacon();
					if (script_flg) save_script();
				}
				while(DISP == 0) {}										// wait until button released
			}
			else
			{
				switch (lcd_mode)										// select sub page to adjust
				{
					case 0:
						sub_page0++;
						if (sub_page0 == MAX_SUB_PAGE0 && !sub_page0_timer[eeprom.defval.mode])
							sub_page0++;
						if (sub_page0 > MAX_SUB_PAGE0)
							sub_page0 = 0;
					break;

					case 1:
						sub_page1++;
						if (sub_page1 == 1 && board_type < TX500_136_TYPE)	// select band for the optional bi-band board
							sub_page1++;
						if (sub_page1 == 2 && !sub_page0_timer[eeprom.defval.mode])
							sub_page1++;
						if (sub_page1 == 13 && board_type >= TX500_136_TYPE) // select spare io if no optional bi-band board
							sub_page1 = 0;
						if (sub_page1 > MAX_SUB_PAGE1)
							sub_page1 = 0;
					break;

					case 2:
						sub_page2++;
						if (sub_page2 > MAX_SUB_PAGE2)
							sub_page2 = 0;
						msg_idx = 0;
						cur_flg = 0;
						disp_idx = 0;
					break;
				}
			}
			encoder_get();												// clear encoder after display change
			ms_delay(BUTTON_DEBOUNCE);
		}


		//-----------------------------------------------------------------------------------------
		// OPER
		//-----------------------------------------------------------------------------------------
		// operating mode select if normal display, long push = beacon TX control
		if (OPER == 0 && lcd_mode == 0)
		{
			ms_delay(BUTTON_DEBOUNCE);
			counter.push = LONG_PUSH;					// set long push timer
			
			if (alarms)
				set_pa_state(STATE_STBY, 1, 1, 1);		// if active alarms, always change to standby state
			else
			{
				while(OPER == 0 && eeprom.defval.pa_state == STATE_OPER)		// long push in OPER mode only
					if (!counter.push)
						break;

				// major mode change
				if (!counter.push && keyer_mode == KEYER_BEACON)
				{
					if ((set.ptt != PTT_AUTO && key) || afp_ptt)	// force PTT shutdown
					{
						set_pa_state(STATE_STBY, 1, 0, 0);
						if (eeprom.defval.beacon_tx_on)
							set_beacon_on_off(0, 0);
						if (eeprom.defval.script_on)
							set_script_on_off(0, 0);
						if (eeprom.defval.mode == MODE_REM)
							stop_keyer();
						beep(TONE_B, cal.calval.beep_len*10);
					}
					else if (set.ptt == PTT_AUTO)
					{
						if (eeprom.defval.mode == MODE_SCRIPT)
							set_script_on_off(!eeprom.defval.script_on, 1);		// invert script state
						else
						{
							if (eeprom.defval.script_on)
							{
								set_beacon_on_off(0, 0);		// stop the beacon
								set_script_on_off(0, 1);		// stop the script
							}
							else set_beacon_on_off(!eeprom.defval.beacon_tx_on, 1);	// invert beacon state
						}
					}
				}
				else
					if (!eeprom.defval.beacon_tx_on && !eeprom.defval.script_on && !key)	// change state if beacon and script are off
					{
						set_pa_state(1, 0, 1, 1);
						if (eeprom.defval.mode == MODE_REM && eeprom.defval.pa_state == STATE_OPER)
							uart1_clear();
					}
			}					
			ms_delay(BUTTON_DEBOUNCE);
			while(OPER == 0) {}										// wait until button released
			clear_alarms();											// try to clear alarms
		}
		else if (OPER == 0 && lcd_mode == 2)						// delete character
		{
			if (key_x[sub_page2]) key_x[sub_page2](0, 3, 1);
			ms_delay(BUTTON_DEBOUNCE);
			while(OPER == 0) {}
		}

		//-----------------------------------------------------------------------------------------
		// FREQ +
		//-----------------------------------------------------------------------------------------
		if (!FREQ_UP && !lcd_mode && !eeprom.defval.beacon_tx_on && !eeprom.defval.script_on && !key)
		{
			if(RFPWR == 0)
				// speed tune
				set_frequency(100, 0, 1, 1);
			else
				// normal tune
				set_frequency(1, 0, 1, 1);
			ms_delay(BUTTON_DEBOUNCE);
		}
		else if (FREQ_UP == 0 && lcd_mode == 2)						// adjust character
		{
			if (key_x[sub_page2]) key_x[sub_page2](1, 1,  0);
            ms_delay(BUTTON_DEBOUNCE);
		}


		//-----------------------------------------------------------------------------------------
		// FREQ -
		//-----------------------------------------------------------------------------------------
		if (!FREQ_DN && !lcd_mode && !eeprom.defval.beacon_tx_on && !eeprom.defval.script_on && !key)
		{
			if(RFPWR == 0)
				// speed tune
				set_frequency(-100, 0, 1, 1);
			else
				// normal tune
				set_frequency(-1, 0, 1, 1);
			ms_delay(BUTTON_DEBOUNCE);
		}
		else if (FREQ_DN == 0 && lcd_mode == 2)						// adjust character
		{
			if (key_x[sub_page2]) key_x[sub_page2](-1, 1, 0);
			ms_delay(BUTTON_DEBOUNCE);
		}


		//-----------------------------------------------------------------------------------------
		// RF PWR button alone
		//-----------------------------------------------------------------------------------------
		if (!RFPWR && !lcd_mode && FREQ_UP && FREQ_DN && !eeprom.defval.beacon_tx_on && !eeprom.defval.script_on && !key) 
		{
			set_tx_power(1, 0, 1, 1);
			ms_delay(BUTTON_DEBOUNCE);
			while(RFPWR == 0) {}
		}
		else if (RFPWR == 0 && lcd_mode == 1 && sub_page1 == 7)
		{
			set_tx_power(1, 0, 1, 1);
			ms_delay(BUTTON_DEBOUNCE);
			while(RFPWR == 0) {}
		}
		else if (RFPWR == 0 && lcd_mode == 2)						// add character
		{
			if (key_x[sub_page2]) key_x[sub_page2](0, 2, 1);
			ms_delay(BUTTON_DEBOUNCE);
			while(RFPWR == 0) {}
		}


		//-----------------------------------------------------------------------------------------
		// POWER button
		//-----------------------------------------------------------------------------------------
		if(PWR_SW == 1)
		{
			switch (lcd_mode)
			{
				// display meter according to the mode
				case 0:
					do
					{
						sub_mode++;
						if (sub_mode == 7)
							sub_mode = 0;
					}
					while (!sub_mode_menu[eeprom.defval.mode][sub_mode]);
					beacon_lcd_idx = 0;
				break;

				// beacon configuration menu
				case 1:
					lcd_mode = 2;
					sub_page2 = sub_page2_init[eeprom.defval.mode];
					msg_idx = 0;
					cur_flg = 0;
					disp_idx = 0;
				break;

				case 2:
					lcd_mode = 1;
					lcd_cursor_on(1, 1, 0);
				break;
			}
			power_off();											// go shut down
		}

	//*********************************************************************************************
	// ----------> Script
	//*********************************************************************************************

		if (eeprom.defval.script_on)
			run_script();

	//*********************************************************************************************
	// ---------> Beacon
	//*********************************************************************************************
		
		if (eeprom.defval.beacon_tx_on)
			run_beacon();

	//*********************************************************************************************
	// ----------> Do LCD display and UP/DOWN buttons
	//*********************************************************************************************

		switch (lcd_mode)
		{
			//-------------------------------------------------------------------------------------
			// Normal display
			//
			// |A: mode parameters 8 char     |B: meter 7 char       |
			// |C:mode 4 char|D:pa state 6 char  |E: frequency 6 char|
			//-------------------------------------------------------------------------------------
			case 0: default:
	
				//-----> A
				// select beacon message to display
				if (keyer_mode != KEYER_BEACON)					// not in beacon mode
				{
					lcd_cursor(1, 1);
					lcd_s_meter(pwr_meter);						// show PWR meter bar graph
					lcd_putch(S_BAR);							// PWR-meter stopper bar
					if (eeprom.defval.pa_state == STATE_TUNE)	// Enable TX if TUNE mode
					{
						temp = encoder_get();
						if (temp > 0 && !key)					// TX on if UP and not keyer
						{
							if (eeprom.defval.cw_sidetone != CW_SIDETONE_OFF)	// no sound if sidetone off
								tone_on(set.sidetone);		// keep on starting side tone generator
							counter.busy = -1;
							set_tx_on(0);
						}
						else if (temp < 0)						// TX off if DOWN
						{
							old.pa_state = STATE_TUNE;		// mandatory if tune down after stopping script
							stop_keyer();
						}
					}
				}
				else
				{
					temp = encoder_get();
					// action only if beacon off, script off and remote mode not in oper
					if((eeprom.defval.beacon_tx_on || key) || eeprom.defval.script_on
						|| (eeprom.defval.mode == MODE_REM && eeprom.defval.pa_state == STATE_OPER))
						temp = 0;
					switch (sub_mode)
					{
						case 0:
							if(afp_ptt) 	// active only if AFP remote in TX
								disp_afp_tone();
							else
								if (set_sub_mode0[eeprom.defval.mode]) set_sub_mode0[eeprom.defval.mode](temp, 0, 1, 1);
						break;

						case 1:
							set_cw_shift(temp, 0, 1, 1);	// only DFCW mode
						break;

						case 2:
							set_frame(eeprom.defval.mode, temp, 0, 1, 1);
						break;

						case 3:
							disp_beacon_lcd(0);
						break;

						case 4:
							disp_beacon_in_progress();
						break;
				
						case 5:
							disp_beacon_lcd(MODE_SCRIPT);
						break;

						case 6:
							set_script_delay(0, 0, 1);
						break;
					}	
				}
			
				//-----> B
				// select meter to display
				switch (sub_page0)								// select meter
				{
					case 0: default:							// Power
						disp_fwd_pwr();
					break;

					case 1:										// SWR forward power
						disp_swr();
					break;

					case 2:										// battery voltage mean value, measure only when display selected
						disp_batt_volt();
					break;

					case 3:										// Drain current, measure only when display selected
						disp_id();
					break;

					case 4:										// synchronization timer
						disp_timer(0);
					break;
				}

				//-----> C and UP/DOWN
				switch (eeprom.defval.mode)
				{
					case MODE_CW:
						if (eeprom.defval.cw_keyer == 4)		// beacon mode
						{
							if (flag.cwid)
								lcd_display_at(2, 1 , "CWID ");
							else
								lcd_display_at(2, 1 , "CW   ");
						}
						else
						{
							temp = encoder_get();				// keyer modes
							set_cw_speed(temp, 0, 1, 1);
						}
					break;
				
					default:
						lcd_display_at(2, 1 , mode_display[eeprom.defval.mode]);
					break;
				}

				//-----> D
				// display PA state
				if (alarms)
					disp_alarms();
				else
				{
					set_pa_state(0, 0, 0, 1);
					if (eeprom.defval.script_on)	// display indication during script
					{
						if (lcd_blink != flag.blink)
						{	
							if (lcd_blink)
								lcd_display_at(2, 10 , "s");
							else
								lcd_display_at(2, 10 , " ");
							lcd_blink = flag.blink;
						}	
					}
					else if (flag.msg)				// display indication during message transmission
					{
						if (lcd_blink != flag.blink)
						{
							if (lcd_blink)
								lcd_display_at(2, 10 , "m");
							else
								lcd_display_at(2, 10 , " ");
							lcd_blink = flag.blink;	
						}
					}
					else
						lcd_display_at(2, 10 , " ");
				}

				//-----> E
				// display frequency
				set_frequency(0, 0, 0, 1);
			break;

			//-------------------------------------------------------------------------------------
			// User config display
			//
			// |Configuration type line 16 char                      |
			// |Configuration data Line 16 char                      |
			//-------------------------------------------------------------------------------------

			//-----> type & data line and UP/DOWN
			// select configuration to display and adjust if UP / DOWN buttons pressed
			case 1:
				switch(sub_page1)
				{
					case 0:
						if (set_mode(encoder_get(), 0, 1, 1))
						{
							init_sub_mode();
							if (!sub_page0_timer[eeprom.defval.mode] && sub_page0 == MAX_SUB_PAGE0)
								sub_page0 = 0;
							set_pa_state (0, 1, 0, 0);		// force standby state
						}
					break;

					case 1:
						set_band(encoder_get(), 0, 1, 1);	// only if bi-band board installed
					break;

					case 2:
						set_sync_timer(encoder_get(), 0, 0, 0, 1, 1);
					break;

					case 3:
						set_preamp(encoder_get(), 0, 1, 1);
					break;

					case 4:
						set_converter(encoder_get(), 0, 1, 1);
					break;

					case 5:
						set_cw_keyer(encoder_get(), 0, 1, 1);
					break;

					case 6:
						set_cw_sidetone(encoder_get(), 0, 1, 1);
					break;

					case 7:
						set_swr_limit(encoder_get(), 0, 1, 1);
					break;

					case 8: default:
						set_back_light(encoder_get() * 10, 0, 1, 1);
					break;

					case 9:
						set_contrast(encoder_get(), 0, 1, 1);
					break;

					case 10:
						set_serial_mode(encoder_get(), 0, 1, 1);
					break;

					case 11:
						set_baud_rate(encoder_get(), 0, 1, 1);
					break;

					case 12:
						if (set_mox(encoder_get(), 0, 1, 1))
							set_pa_state (0, 1, 0, 0);		// force standby state
					break;

					case 13:
						set_spare_io(encoder_get(), 0, 1, 1);	// only if bi-band board not installed
					break;
				}
			break;

			//-------------------------------------------------------------------------------------
			// Beacon setup display
			//
			// |Beacon setup type line 16 char                       |
			// |Beacon setup data Line 16 char                       |
			//-------------------------------------------------------------------------------------

			//-----> type & data line and UP/DOWN
			// select beacon message to display and move cursor or adjust if UP / DOWN buttons pressed
            case 2:
                switch (sub_page2)
                {
                    case 0:
						key_cw_beacon(encoder_get(), 0,  0);
					break;

					case 1:
						key_beacon(encoder_get(), 0,  0);
					break;

					case 2:
						key_call(encoder_get(), 0,  0);
					break;

					case 3:
						key_grid(encoder_get(), 0,  0);
					break;

					case 4:
						set_gps(encoder_get(),0, 1, 1);
					break;

					case 5:
						set_wspr_ndbm(encoder_get() * 3, 0, 1, 1);
					break;

					case 6:
						set_cwid(encoder_get(), 0, 1, 1);
					break;

					case 7:
						key_script(encoder_get(), 0, 0);
					break;
				}
			break;
		}

	//*********************************************************************************************
	// ----------> Do serial interface
	//*********************************************************************************************
		if (eeprom.defval.mode == MODE_REM && eeprom.defval.pa_state == STATE_OPER)
		{
			switch (eeprom.defval.rem_soft)
			{
				case REM_JASON_N: case REM_JASON_F:
					serial_jason(key);
				break;

				case REM_WSQ2:
					serial_wsq2(key);
				break;

				// call with 1ms IRQ to follow the data flow
				/*case REM_AFP:
					serial_afp();
				break;*/
			}
		}
		else
		{
			switch(eeprom.defval.serial_mode)
			{
				case 0:
					serial_tx500(0);			// TX500 / TX136 protocol
				break;

				case 1: default:
					if (eeprom.defval.mode != MODE_REM)
						serial_test();			// test commands
				break;

				// UART1 can be used for GPS if UART2 is not wired
				case 2:
					serial_gps(0);				// GPS NMEA protocol
				break;
			}
		}

		// UART2 used for GPS by default - UART2 must be wired
		if (eeprom.defval.serial_mode != 2)
			serial_gps(1);						// GPS NMEA protocol
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Service & calibration functions, when tested move to own module
//=================================================================================================
void service(void)
{
	int cal_page;

	// display setup
	cal_page = 0;
	lcd_clear();

	// conditional start up text printout, print only if RS232 = Test
 	if(eeprom.defval.serial_mode == 1)
	{
		printf("\n\rService & calibration mode");
		printf("\n\rDISP = parameter select, OPER = save & exit");
	}

//*************************************************************************************************
// ----------> Service forever loop
//*************************************************************************************************
	for(;;)
	{
		// Make atomic copy of KEY(TX request) signal for this processing round
		if(PTT_OUT_1)						// 1 = active
			key = 1;						// copy I/O bit to status flag	
		else
			key = 0;

		// do measurements & check alarms
		power_measurements();
		check_alarms();


	//*********************************************************************************************
	// ----------> Do front panel switches
	//*********************************************************************************************

		//-----------------------------------------------------------------------------------------
		// DISPLAY / CONFIG
		//-----------------------------------------------------------------------------------------
		if(DISP == 0)							// select calibration function
		{
			cal_page++;
			if(cal_page > MAX_SERVICE_PAGES) 	// number of active pages
				cal_page = 0;
			beep(HZ392_01, 50);
			while(DISP == 0) {}
			ms_delay(BUTTON_DEBOUNCE);
			encoder_get();						// flush encoder
		}

		switch(cal_page)						// select major page to display
		{
			case 8:								// factory defaults, this must be last item in the list
				lcd_display_all("Push OPER long =", "factory defaults"); 
			break;

			default:
				set_cal_x[cal_page](encoder_get(), 0, 1, 1);
			break;
		}


		//-----------------------------------------------------------------------------------------
		// OPER
		//-----------------------------------------------------------------------------------------

		if(OPER == 0 && cal_page == MAX_SERVICE_PAGES)			// Restore defaults only when last cal_page
		{
			counter.push = LONG_PUSH;							// set long push timer
				
			while (OPER == 0)									// detect long push
			{
				if(counter.push == 0)							// detect long push, restore factory setup
				{
					set_factory_defaults();						// EEPROM empty, set factory defaults
					save_calval();								// save calibration values
					save_defaults();							// save user defaults
						
					beep(HZ466_85, cal.calval.beep_len*10);		// long beep for save
					service_mode = 0;							// back to normal operation
					lcd_clear();
					lcd_display_line(1, "Factory setup ok"); 
						
 					if(eeprom.defval.serial_mode == 1)			// conditional print only if RS232 = Test
						printf("\n\rFactory defaults restored");
					ms_delay(1500);								// show message
					while(OPER == 0) {}
					return;										// exit service mode
				}
			}
		}
		else if (OPER == 0)										// test SW2 (SET) when  cal_page != 8
		{
			save_calval();										// save changes
			beep(HZ466_85, cal.calval.beep_len);				// short beep for return to normal operation
			service_mode = 0;									// back to normal operation
			lcd_clear();
			lcd_display_line(1, "Calibr. Saved"); 
		
			if(eeprom.defval.serial_mode == 1)					// conditional print only if RS232 = Test
				printf("\n\rCalibration settings saved to EEPROM");
			while(OPER == 0) {}
			return;												// exit service mode
		}	


		//-----------------------------------------------------------------------------------------
		// POWER
		//-----------------------------------------------------------------------------------------
		if(PWR_SW == 1)
			power_off();			// go shut down, do not save changes

	}
}
//-------------------------------------------------------------------------------------------------

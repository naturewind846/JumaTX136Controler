//*************************************************************************************************
//
// JUMA-TX500/136 Transmitter Controller
// F4GCB 06.2016
//
// Microchip MPLAB + C30 compiler
// MCU dsPIC30F6014A
//
// Generates a WSQ message from string to a symbol/tone
//
// Acknowledgement :
// The WSQ message algorithm is derived from C files found in the ZL2AFP WSQ source code
//
// Some functions rewritten to save program memory space - F4GCB 10.2020
// Harmonization of timeslots control - F4GCB 10.2020
//
//*************************************************************************************************

#include <stdio.h>
#include <string.h>	
#include "timers_pwm.h"

// External functions -----------------------------------------------------------------------------
extern void play_wsq_tone(int);

// External variables -----------------------------------------------------------------------------
int wsq_shift;								// TX WSQ shift for DDS

// Local variables --------------------------------------------------------------------------------
static unsigned char wsq_varicode[][2] = {	// WSQ primary alphabet
	{ 0, 0}, { 0, 0}, { 0, 0}, { 0, 0}, { 0, 0}, { 0, 0}, { 0, 0}, { 0, 0},
	{27,31}, { 0, 0}, {28, 0}, { 0, 0}, { 0, 0}, { 0, 0}, { 0, 0}, { 0, 0},
	{ 0, 0}, { 0, 0}, { 0, 0}, { 0, 0}, { 0, 0}, { 0, 0}, { 0, 0}, { 0, 0},
	{ 0, 0}, { 0, 0}, { 0, 0}, { 0, 0}, { 0, 0}, { 0, 0}, { 0, 0}, { 0, 0},
	{ 0, 0}, {11,30}, {12,30}, {13,30}, {14,30}, {15,30}, {16,30}, {17,30},
	{18,30}, {19,30}, {20,30}, {21,30}, {27,29}, {22,30}, {27, 0}, {23,30},
	{10,30}, { 1,30}, { 2,30}, { 3,30}, { 4,30}, { 5,30}, { 6,30}, { 7,30},
	{ 8,30}, { 9,30}, {24,30}, {25,30}, {26,30}, { 0,31}, {27,30}, {28,29},
	{ 0,29}, { 1,29}, { 2,29}, { 3,29}, { 4,29}, { 5,29}, { 6,29}, { 7,29},
	{ 8,29}, { 9,29}, {10,29}, {11,29}, {12,29}, {13,29}, {14,29}, {15,29},
	{16,29}, {17,29}, {18,29}, {19,29}, {20,29}, {21,29}, {22,29}, {23,29},
	{24,29}, {25,29}, {26,29}, { 1,31}, { 2,31}, { 3,31}, { 4,31}, { 5,31},
	{ 9,31}, { 1, 0}, { 2, 0}, { 3, 0}, { 4, 0}, { 5, 0}, { 6, 0}, { 7, 0},
	{ 8, 0}, { 9, 0}, {10, 0}, {11, 0}, {12, 0}, {13, 0}, {14, 0}, {15, 0},
	{16, 0}, {17, 0}, {18, 0}, {19, 0}, {20, 0}, {21, 0}, {22, 0}, {23, 0},
	{24, 0}, {25, 0}, {26, 0}, { 6,31}, { 7,31}, { 8,31}, { 0,31}, {28,31},
	};
static char nibble_high;					// high_order niddle
static char nibble_low;						// low_order niddle
static int nibble_idx;						// currently playing start, high or low nibble
static int tone;							// tone value (1 to 33)
static int char_play;						// tone playing, 1=playing
static char b_buf[129];						// beacon test buffer
static char *b_buf_start;					// beacon text buffer start
static char *b_buf_ptr;						// beacon text buffer current pointer
static char b_buf_display[9];				// WSQ code display buffer


//=================================================================================================
// Clear transmitted WSQ characters buffer for display
//=================================================================================================
void wsq_clear_display(void)
{
	int i;

	for (i=0; i<8; i++)
		b_buf_display[i] = ' ';
	b_buf_display[i] = 0x00;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set transmitted WSQ characters buffer for display
//=================================================================================================
void wsq_set_display(unsigned char c)
{
	int i;

	// shift buffer left
	for (i=0; i<8; i++)
		b_buf_display[i] = b_buf_display[i+1];

	// insert new character
	b_buf_display[7] = c;
	b_buf_display[8] =  ' ';
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set lower-case character to have faster transmission
//=================================================================================================
char chr_lower_wsq(char bc) 
{
	char cc = bc;
	if (bc >= 0x41 && bc <= 0x5A) cc += 0x20;
 
  	return(cc);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Generate nibble(s) for a character
//=================================================================================================
void generate_nibbles_wsq(char chr)
{
	nibble_high = wsq_varicode[(int)chr][0];
	nibble_low = wsq_varicode[(int)chr][1];
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Init WSQ beacon
//=================================================================================================
void wsq_init_beacon(const char *str)
{
	strcpy(b_buf, str);
	b_buf_start = b_buf;				// save start address
	b_buf_ptr = b_buf;					// set current pointer
	wsq_clear_display();				// clear display text buffer
	char_play = 0;
	tone = 0;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// WSQ character generator
// 1ms IRQ function, feed character
//=================================================================================================
void wsq_char_irq(void)
{
	char c;

	// run logic only when play character active
	if (ts.on && char_play)
	{
		switch (nibble_idx)
		{
			// beginning frequency
			case 3:
				tone = 1;
			break;

			// high nibble
			case 2:
				tone = (tone + nibble_high + 1) % 33;
				if (nibble_low < 29) nibble_idx--;
			break;

			// low nibble
			case 1:
				tone = (tone + nibble_low + 1) % 33;
			break;

			case 0:
				char_play = 0;
				return;
			break;
		}
		if (nibble_idx)
		{
			play_wsq_tone(tone);
			nibble_idx --;
		}	
	}
	else if (ts.on)
	{
		// get character
		c = *b_buf_ptr;

		// test end of message
		if (c == 0 || c == 0x0D)
		{
			// start over
			b_buf_ptr = b_buf_start;
			char_play = 0;							// WSQ message finished
			ts.on = 0;
			ts.end = 1;
			wsq_clear_display();
		}
		else										// was not end of message, decode & play
		{
			if (b_buf_ptr == b_buf)
				nibble_idx = 3;						// play beginning frequency before the first character 
			else
				nibble_idx = 2;
			b_buf_ptr++;							// prepare for next character
			generate_nibbles_wsq(chr_lower_wsq(c));
			char_play = 1;
			wsq_set_display(c);						// run rolling characters for display
		}
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Return transmitted WSQ characters buffer for display 8 characters
//=================================================================================================
 char *wsq_get_display(char *string)
{
	if (ts.on)
		strcpy(string, b_buf_display);
	else
		sprintf(string, "%.2d:%.2d:%.2d ", (ts.wait / 3600), (ts.wait % 3600) / 60, (ts.wait % 3600) % 60);

	return string;
}
//-------------------------------------------------------------------------------------------------

//*************************************************************************************************
//
// dsPIC30 timers PWM DAC for JUMA-TX500
// Juha Niinikoski, OH2NLT 16.08.2009
//
// Microchip C30 compiler conversion
//
// JUMA-TX136/500 timer & pwm system
//
// Timer & PWM unit usage
//
// TMR1
// TMR2 is used for tone generation, IRQ driven system, RD1/OC2 = tone out
// TMR3 is used for 1ms timer tick IRQ and for LCD PWM dac timebase
// OC3 output is for LCD back light control
// OC4 output is for LCD contrast
// OC3 and OC4 are connected to TMR3
//
// TMR4
// TMR5 used for delays (separate module)
//
// encoder simulatot repeat logic added 13.08.2008
// hardware tone generator with TMR2 & OC2 18.08.2009
// Buzzer no tone play cleaned, no click 25.08.2009
// Add QRSS and DFCW modes - F4GCB 08.2014
// Add WSPR mode - F4GCB 10.2014
// Program structure modified to improve readability and maintenance - F4GCB 02-2015
// Add OPERA mode - F4GCB 05.2015
// Add JASON mode - F4GCB 08.2015
// Add CW identity option - F4GCB 04.2016
// Add SCRIPT mode - F4GCB 04.2016
// Add play carrier in CW message - F4GCB 05.2016
// Add WSQ mode - F4GCB 06.2016
// PTT management modified - F4GCB 06.2016
// Add JT9 mode - F4GCB 07.2016
// Add tune on/off with CW UP/DOWN buttons, SW 1.10 - F4GCB 11-2018
// Some functions rewritten to save program memory space - F4GCB 10.2020
// Add FST4W mode - F4GCB 10.2020
// Add AFP interface via REMOTE mode, SW 1.13 - F4GCB 12.2021
//
//*************************************************************************************************

#include <stdio.h>
#include "juma-tx500.h"
#include "eeprom_tx500.h"
#include "ad9833.h"
#include "gene_fst4w.h"
#include "gene_jason.h"
#include "gene_jt9.h"
#include "gene_morse.h"
#include "gene_opera.h"
#include "gene_wspr.h"
#include "gene_wsq.h"
#include "serial_tx500.h"
#include "timers_pwm.h"

// Global variables -------------------------------------------------------------------------------
struct counter counter;
struct flag flag;
struct set set;
struct old old;
struct ts ts;

// Local variables --------------------------------------------------------------------------------
static unsigned int up;				// UP button shift register			/
static unsigned int dn;				// DOWN button shift register		|
static int up_pushed;				// up pushed status					|
static int dn_pushed;				// dn pushed status					|
static int rep_up;					// repeat timers (ms)				|> encoder simulator
static int rep_dn;					//									|
static int rep_up_dly;				// repeat start delay (ms)			|
static int rep_dn_dly;				//									|
static int enc;						// encoder accu						/
static int key_down;				// key down flag for straight mode tone generator		/
static int iambic_flag;				// last played, 0=dot, 1=dash							|
static int dot;						// DOT RS flip flop, follow paddle logic, 0=pressed		|> paddle
static int dash;					// DASH RS flip flop									|
static int keyer_ptt;				// keyer generated PTT signal							/


//=================================================================================================
// Simulate encoder with UP / DN buttons - read encoder
//=================================================================================================
int encoder_get(void)
{
	int temp;

	temp = enc;
	enc = 0;
	return(temp);
}
//-------------------------------------------------------------------------------------------------


//*************************************************************************************************
// PWM set functions
//*************************************************************************************************

//=================================================================================================
// Init timer & PWM system
//=================================================================================================
void init_timers_pwm(void)
{
	keyer_ptt = 0;				// keyer generated PTT signal, 0 = false

	counter.ms = 1000;
	counter.ms_offset = 0;
	counter.sync = 3540;
	counter.script = 0;
	counter.blink = 0;
	flag.blink =0;
	counter.roll = 0;
	flag.roll = 0;

	OC3CON = 0;					// first turn off the module if it was on
	OC4CON = 0;

	// LCD PWM DAC setup
	OC3RS = 100;				// some small value for back light
	OC3R = 100;
	OC3CON = 0x000E;			// use TMR3, OC3 = PWM mode

	OC4RS = 2000;				// something for contrast to make display visible
	OC4R = 2000;
	OC4CON = 0x000E;			// use TMR3, OC4 = PWM mode

	//PR3 = TICK_PERIOD - 1;	// set PWM cycle, TMR3 period register, 1000Hz/1ms
	PR3 = TICK_PERIOD;			// set PWM cycle, TMR3 period register, 1000Hz/1ms
	T3CONbits.TON = 1;			// start TMR3
	_T3IE = 1;					// enable TMR3 tick irq

	// Hardware tone generator TMR2 & OC2
	TONE_TRIS = 0;				// enable output
	OC2RS = 2;					// something for contrast to make display visible
	OC2R = 2;
	OC2CON = 0x0006;			// use TMR2, OC2 = PWM mode
	T2CONbits.TON = 0;			// stop TMR2
	_T2IE = 0;					// disable TMR2 tick irq
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// LCD back light
//=================================================================================================
void set_pwm3_dac(unsigned int pwm)
{
	OC3RS = pwm;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// LCD contrast
//=================================================================================================
void set_pwm4_dac(unsigned int pwm)
{
	OC4RS = pwm;
}
//-------------------------------------------------------------------------------------------------


//*************************************************************************************************
// Tone set functions
//*************************************************************************************************

//=================================================================================================
// Start tone
//=================================================================================================
void tone_on(int tone)					// set tone, set value = 7,5MHz / tone(Hz) * 2
{
	//if(tone != NOTONE)				// do not start tone if no tone asked
	if(tone < LOWTONE)					// play only if pitch high enough
	{
		TMR2 = 0;
		PR2 = (tone << 1) - 1;			// set tone cycle period
		OC2RS = tone;					// set 50% PWM
		OC2R = tone;
		T2CONbits.TON = 1;				// start tone timer
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Stop tone
//=================================================================================================
void tone_off(void)						// stop tone generator
{
	T2CONbits.TON = 0;					// stop tone timer
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Generate beep
//=================================================================================================
void beep(int tone, unsigned long duration)
{
	if(counter.busy == 0 && duration > 0)	// start tone only if tone generator free & duration specified
	{
		counter.tone = duration;			// set tone length
		tone_on(tone);						// set tone pitch & start play
	}
}
//-------------------------------------------------------------------------------------------------


//*************************************************************************************************
// Transmitter functions
//*************************************************************************************************

//=================================================================================================
// Set PTT out handling
//=================================================================================================
void set_ptt_out(int ptt)
{
	switch (set.ptt)
	{
		case PTT_AUTO:				// auto PTT
			if(ptt)					// TX On
			{
				ANT_RLY	 = 1;		// switch antenna for TX
				PTT_OUT_1 = 1;
				PTT_OUT_2 = 1;		// activate PTT OUT signal (PA100 fan control transistors)
	 		}
			else					// TX off
			{
				ANT_RLY	 = 0;
				PTT_OUT_1 = 0;
				PTT_OUT_2 = 0;		// PTT OUT signal off
			}
		break;

		case PTT_MOX:				// manual (MOX) PTT
			if(PTT_IN)				// MOX TX On (high level)
			{
				ANT_RLY	 = 1;		// switch antenna for TX
				PTT_OUT_1 = 1;
				PTT_OUT_2 = 1;		// activate PTT OUT signal (PA100 fan control transistors)
			}
			else					// TX off
			{
				// off without any conditions
				ANT_RLY	 = 0;
				PTT_OUT_1 = 0;
				PTT_OUT_2 = 0;	// PTT OUT signal off

			}
		break;

		case PTT_RTS:				// remote (RTS) PTT
			if(!PTT_IN)				// RTS TX On (low level)
			{
				ANT_RLY	 = 1;		// switch antenna for TX
				PTT_OUT_1 = 1;
				PTT_OUT_2 = 1;		// activate PTT OUT signal (PA100 fan control transistors)
			}
			else					// TX off
			{
				// off without any conditions
				ANT_RLY	 = 0;
				PTT_OUT_1 = 0;
				PTT_OUT_2 = 0;	// PTT OUT signal off

			}
		break;
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set TX on sequence
//=================================================================================================
void set_tx_on(unsigned long shift)
{
	if (tword + shift > tword_hi)
	{
		stop_keyer();
		alarms = alarms | OUT_BD_AL;		// set alarm flag
		return;
	}

	keyer_ptt = 1;						// keyer generated PTT signal, 1 = true
	tune_ad9833(tword + shift);			// set / start DDS with possible shift
	BUFFER_ON = 1;						// DDS outbut buffer on
	CW = 1;								// carrier on (keying)
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set SPOT on
//=================================================================================================
void set_spot_on(unsigned long shift)
{
	tune_ad9833(tword + shift);			// set / start DDS with possible shift
	BUFFER_ON = 1;						// DDS outbut buffer on
	//CW = 1;							// carrier on (keying)
	CW = 0;								// carrier off (no keying)
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set TX or spot off
//=================================================================================================
void set_tx_off(void)
{
	keyer_ptt = 0;						// keyer generated PTT signal, 0 = false
	CW = 0;								// carrier off (no keying)
	BUFFER_ON = 0;						// DDS outbut buffer off
	tune_ad9833(0);						// stop DDS

	if(flag.beacon)		// beacon was on in "Transmit mode", restore TX500 state
	{
		set_pa_state(old.pa_state, 1, 0, 0);	// retore current state
		keyer_mode	= old.keyer;
		flag.beacon = 0;						// reset flag
	}
}
//-------------------------------------------------------------------------------------------------


//*************************************************************************************************
// Keyer functions
//*************************************************************************************************

//=================================================================================================
// Brute force stop all keyer activity
//=================================================================================================
void stop_keyer(void)
{
	ts.on = 0;								// stop code generator

	counter.tone = 0;						// reset irq timers
	__asm__ volatile ("disi #4");			// protect long word clear
	counter.busy = 0;
	tone_off();								// use irq functions to stop activity, not good practice
	__asm__ volatile ("disi #4");			// protect long word clear
	counter.cw_break = 0;
	set_tx_off();
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Turn TX on & play carrier during QRSS dot time
//=================================================================================================
void play_carrier(void)
{
	long carrier_period = morse_get_period(eeprom.defval.cw_dot_time, 1);

	counter.cw_break = set.cw_break * carrier_period;	// TX on break time
	
	if(eeprom.defval.pa_state)
		set_tx_on(0);									// RF out on
	else
		set_spot_on(0);									// DDS on, SPOT

	if(eeprom.defval.cw_sidetone != CW_SIDETONE_OFF)	// no sound if sidetone off
		beep(set.sidetone, carrier_period);				// start tone
	else
		beep(NOTONE, carrier_period); 					// start tone not audible tone
	counter.busy = carrier_period;						// set busy period
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Turn TX on & play MORSE dot
//=================================================================================================
void play_dot(void)
{
	iambic_flag = 0;									// remember last played
	counter.cw_break = set.cw_break * set.cw_period;	// TX on break time

	if(eeprom.defval.pa_state)
		set_tx_on(0);									// RF out on
	else
		set_spot_on(0);									// DDS on, SPOT

	if(eeprom.defval.cw_sidetone != CW_SIDETONE_OFF)	// no sound if sidetone off
		beep(set.sidetone, set.cw_period);				// start tone
	else
		beep(NOTONE, set.cw_period); 					// start tone not audible tone
	counter.busy = 2 * set.cw_period;					// set busy period
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Turn TX on & play MORSE dash
//=================================================================================================
void play_dash(void)
{
	iambic_flag = 1;									// remember last played
	counter.cw_break = set.cw_break * set.cw_period;	// TX on break time

	if(eeprom.defval.pa_state)
		set_tx_on(0);									// RF out on
	else
		set_spot_on(0);									// DDS on, SPOT

	if(eeprom.defval.cw_sidetone != CW_SIDETONE_OFF)	// no sound if sidetone off
		beep(set.sidetone, (3 * set.cw_period)); 		// start tone
	else
		beep(NOTONE, (3 * set.cw_period)); 				// start tone not audible tone
	counter.busy = 4 * set.cw_period;					// set busy period
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Turn TX on & play DFCW dot
//=================================================================================================
void play_dfcw_dot(void)
{
	iambic_flag = 0;									// remember last played
	counter.cw_break = set.cw_break * set.cw_period;	// TX on break time

	if(eeprom.defval.pa_state)
		set_tx_on(0);									// RF out on
	else
		set_spot_on(0);									// DDS on, SPOT

	if(eeprom.defval.cw_sidetone != CW_SIDETONE_OFF)	// no sound if sidetone off
		beep(set.sidetone, set.cw_period); 				// start tone
	else
		beep(NOTONE, set.cw_period); 					// start tone not audible tone

	counter.busy = 1.33 * set.cw_period;				// set busy period
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Turn TX on & play DFCW dash
//=================================================================================================
void play_dfcw_dash(void)
{
	iambic_flag = 1;									// remember last played
	counter.cw_break = set.cw_break * set.cw_period;	// TX on break time

	if(eeprom.defval.pa_state)
		set_tx_on(morse_shift);							// RF out on
	else
		set_spot_on(morse_shift);						// DDS on, SPOT

	if(eeprom.defval.cw_sidetone != CW_SIDETONE_OFF)	// no sound if sidetone off
		beep(set.sidetone + (2 * CW_SIDETONE_STEP), set.cw_period); // start tone
	else
		beep(NOTONE, set.cw_period); 					// start tone not audible tone

	counter.busy = 1.33 * set.cw_period;				// set busy period
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Play MORSE symbols
//=================================================================================================
void play_morse_sym(int symbol)
{
	switch (symbol)
	{
		case 0: default:								// end of mark
			if (eeprom.defval.mode == MODE_DFCW)
				counter.busy = set.cw_period;			// character space period
			else
				counter.busy = 2 * set.cw_period;		// character space period, note one unit is already included with dash or dot
		break;

		case ' ':										// space
			counter.cw_break = set.cw_break * set.cw_period;
			if (eeprom.defval.mode == MODE_DFCW)
				counter.busy = set.cw_period;
			else
				counter.busy =  4 * set.cw_period;		// word space period, note 3 units are already there from end of mark
		break;

		case '-':										// dash
			if (eeprom.defval.mode == MODE_DFCW)
				play_dfcw_dash();
			else
				play_dash();
		break;

		case '.':										// dot
			if (eeprom.defval.mode == MODE_DFCW)
				play_dfcw_dot();
			else
				play_dot();
		break;

		case 'C':										// carrier during QRSS dot time
				play_carrier();
		break;
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Play MORSE according to paddle
//=================================================================================================
void play_morse_paddle(void)
{
	//switch(get_cw_keyer())						// select keyer operation
	switch(keyer_mode)								// select keyer operation
	{
		case KEYER_DOT_PRI: 						// dot priority
			if (DOT == 0)
				play_dot();
			else if(DASH == 0)
				play_dash();
		break;

		case KEYER_IAMBIC_A: case KEYER_IAMBIC_B:	// iambic mode A & B, sample from dot/dash RS flip flop
			if (iambic_flag)							// last played was dash, test DOT contact first
			{
				if (dot == 0)
					play_dot();
				else if (dash == 0)
					play_dash();
			}
			else									// last played was dot, test DASH contact first
			{
				if (dash == 0)
					play_dash();
				else if (dot == 0)
					play_dot();
			}
		break;

		case KEYER_STRAIGHT:						// straight mode
			if (DOT == 0)							// key down, I/O bit
			{
				if (key_down == 0) 					// do this only if key was up
				{
					key_down = 1;					// set key down status
					if (eeprom.defval.cw_sidetone != CW_SIDETONE_OFF)	// no sound if sidetone off
						tone_on(set.sidetone);		// keep on starting side tone generator
				}
				if (eeprom.defval.pa_state)					// tx only if no standby
				{
					if (eeprom.defval.pa_state == STATE_TUNE)
						counter.cw_break = 10; 		// fast release 10 ms in tune mode
					else
						counter.cw_break = set.cw_break * set.cw_period;	// TX on break time
					set_tx_on(0);
				}
				else
				{
					counter.cw_break = set.cw_break * set.cw_period;		// TX on break time
					set_spot_on(0);						// DDS on, SPOT
				}
			}

			if (DOT != 0)							// key up
			{
				if (key_down != 0)					// do only if key was down
				{
					CW = 0;							// CW modulator off
					tone_off();						// stop side tone generator
					key_down = 0;					// remove key down flag
				}
			}
		break;

		default:									// beacon & unknown modes
		break;
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Turn TX on & play JASON tone
//=================================================================================================
void play_jason_tone(int tone)
{
	counter.cw_break = set.cw_period + 500;				// TX on break time
	
	if(eeprom.defval.pa_state)
		set_tx_on(jason_shift * tone);					// RF out on
	else
		set_spot_on(0);									// DDS on, SPOT

	beep(NOTONE, set.cw_period); 						// start tone not audible tone
	counter.busy = set.cw_period;						// set busy period
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Turn TX on & play WSQ tone
//=================================================================================================
void play_wsq_tone(int tone)
{
	counter.cw_break = set.cw_period + 500;				// TX on break time
	
	if(eeprom.defval.pa_state)
		set_tx_on(wsq_shift * tone);					// RF out on
	else
		set_spot_on(0);									// DDS on, SPOT

	beep(NOTONE, set.cw_period); 						// start tone not audible tone
	counter.busy = set.cw_period;						// set busy period
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Turn TX on & play OPERA symbols
//=================================================================================================
void play_opera_sym(int symbol)
{
	counter.cw_break = set.cw_period + 500;				// TX on break time

	if(eeprom.defval.pa_state && symbol)
		set_tx_on(0);									// RF out on
	else
		set_spot_on(0);									// DDS on, SPOT

	beep(NOTONE, set.cw_period); 						// start tone not audible tone
	counter.busy = set.cw_period;						// set busy period
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Turn TX on & play WSPR symbols
//=================================================================================================
void play_wspr_sym(int symbol)
{
	counter.cw_break = set.cw_period + 500;				// TX on break time

 	if(eeprom.defval.pa_state)
		set_tx_on(wspr_shift[symbol]);					// RF out on
	else
		set_spot_on(wspr_shift[symbol]);				// DDS on, SPOT

	beep(NOTONE, set.cw_period); 						// start tone not audible tone
	counter.busy = set.cw_period;						// set busy period
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Turn TX on & play FST4W symbols
//=================================================================================================
void play_fst4w_sym(int symbol)
{
	counter.cw_break = set.cw_period + 500;				// TX on break time

 	if(eeprom.defval.pa_state)
		set_tx_on(fst4w_shift[symbol]);					// RF out on
	else
		set_spot_on(fst4w_shift[symbol]);				// DDS on, SPOT

	beep(NOTONE, set.cw_period); 						// start tone not audible tone
	counter.busy = set.cw_period;						// set busy period
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Turn TX on & play JT9 symbols
//=================================================================================================
void play_jt9_sym(int symbol)
{
	counter.cw_break = set.cw_period + 500;				// TX on break time

 	if(eeprom.defval.pa_state)
		set_tx_on(jt9_shift[symbol]);					// RF out on
	else
		set_spot_on(jt9_shift[symbol]);					// DDS on, SPOT

	beep(NOTONE, set.cw_period); 						// start tone not audible tone
	counter.busy = set.cw_period;						// set busy period
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// IRQ code
// 1ms Tick timer
//=================================================================================================
void __attribute__((interrupt, no_auto_psv)) _T3Interrupt(void)
{
	IRQ_TEST = 1;		// timing test

	// AFP remote
	if (afp_serial)
		serial_afp();

	//*********************************************************************************************
	// Counters
	//*********************************************************************************************
	// ----> tone duration counter
	if (counter.tone)
	{
		counter.tone--;
		if (counter.tone == 0)
		{			
			tone_off();					// run stop with half cycle logic
			CW = 0;						// RF carrier off		
		}
	}

	// -----> run cw break timer
	if (counter.cw_break)
	{
		counter.cw_break--;
		if (counter.cw_break == 0)
			set_tx_off();				// RF off
	}

	// ----> decrement CW tone busy timer if active (value -1 = diseabled)
	if (counter.busy > 0)
	{
		counter.busy--;
		if (counter.busy == 0)			// mark ready
		{
			if (iambic_flag == 0)		// was DOT
				dot = 1;				// reset dot
			else						// was dash
				dash = 1;				// reset dash
		}
	}

	// -----> general timing
	counter.ms--;
	if (counter.ms == 0)
	{
		counter.s++;
		if (counter.s == 36000)			// max 10 hours
			counter.s = 0;
		if (counter.script)
			counter.script--;

		if (counter.gps)
			counter.gps--;
		set_sync_timer(1, 0, 0, 1, 1, 0);

		// offset for WSPR timer, add 1 clock pulse every calibration value in seconds
		// because TICK_PERIOD = 7372 instead 7372,8
		// accuracy is mandatory for WSPR modes
		counter.ms_offset++;
		if (counter.ms_offset == cal.calval.ms_offset)
		{
			counter.ms = 1001;
			counter.ms_offset = 0;
		}
		else
			counter.ms = 1000;
	}

	// -----> push button timer
	if (counter.push)						// decrement long push timer if active
		counter.push--;

	// -----> blink flag
	counter.blink--;
	if (counter.blink < 0)
	{
		counter.blink = BLINK_RATE;
		flag.blink = !flag.blink;
	}

	// -----> roll flag
	counter.roll--;
	if (counter.roll < 0)
	{
		counter.roll = ROLL_RATE;
		flag.roll = !flag.roll;
	}

	// -----> power meter decay counter
	if (counter.decay)
		counter.decay--;
	
	// read paddle switches, set dot/dash RS flip flops
	if (keyer_mode == KEYER_IAMBIC_B)		// Iambic B, flip set only
	{
		if (DOT == 0)						// Set RS/ flip flop
			dot = 0;
		if (DASH == 0)
			dash = 0;
	}
	else									// Iambic A or other mode, flip flop set/reset
	{
		if (DOT == 0)						// Set/Reset RS flip flop
			dot = 0;
		else
			dot = 1;
		if (DASH == 0)
			dash = 0;
		else
			dash = 1;
	}

	// -----> run paddle or beacon generator
	if (counter.busy == 0)
	{
		play_morse_paddle();
		switch (eeprom.defval.mode)
		{	
			case MODE_CW: case MODE_QRSS: case MODE_DFCW: default:
				morse_char_irq(); 
			break;

			case MODE_JASON:
				jason_char_irq();
			break;

			case MODE_WSQ:
				wsq_char_irq();
			break;

			case MODE_OPERA:
				opera_sym_irq();
			break;

			case MODE_WSPR:
				wspr_sym_irq();
			break;

			case MODE_FST4W:
				fst4w_sym_irq();
			break;

			case MODE_JT9:
				jt9_sym_irq();
			break;
		}
	}

	// set TX PTT signal depending on PTT mode, keyer or MOX
	set_ptt_out(keyer_ptt);

	// In the TX136/500 we do not have rotary encoder.
	// Encoder functions are simulated, with UP & DOWN buttons
	// do debounce shift registers
	up = up << 1;					// UP button, encoder ++
	if (UP == 0)
		up = up | 0x0001;
	else
		up = up & 0xFFFE;

	dn = dn << 1;					// DOWN button, encoder --
	if (DN == 0)
		dn = dn | 0x0001;
	else
		dn = dn & 0xFFFE;

	// test pushed condition
	// UP
	if (up_pushed == 0)				// not pushed
	{
		if (up == 0xFFFF)			// test if debounce shift register all ones
		{
			up_pushed = 1;			// set pushed
			rep_up_dly = REP_DLY;	// set repeat start timer
			enc++;					// increment encoder
		}
	}
	else							// pushed
	{
		if (up == 0x0000)			// test if debounce shift register all zeroes
		{
			up_pushed = 0;			// clear pushed
			rep_up_dly = 0;			// clear repeat
			rep_up = 0;
		}
	}

	// DOWN
	if (dn_pushed == 0)				// not pushed
	{
		if (dn == 0xFFFF)			// test if debounce shift register all ones
		{
			dn_pushed = 1;			// set pushed
			rep_dn_dly = REP_DLY;	// set repeat start timer
			enc--;					// increment encoder
		}
	}
	else							// pushed
	{
		if (dn == 0x0000)			// test if debounce shift register all zeroes
		{
			dn_pushed = 0;			// clear pushed
			rep_dn_dly = 0;			// clear repeat
			rep_dn = 0;
		}
	}

	// repeat start timers
	if (rep_up_dly != 0)				// check if UP button stsrt repeat timer is running
	{
		rep_up_dly--;
		if (rep_up_dly == 0)			// start repeat action
			rep_up = REP;
	}

	if (rep_dn_dly != 0)				// check if DN button stsrt repeat timer is running
	{
		rep_dn_dly--;
		if (rep_dn_dly == 0)			// start repeat action
			rep_dn = REP;
	}

	// repeat generator timers
	if (rep_up != 0)					// UP button rep counter going ?
	{
		rep_up--;
		if (rep_up == 0)
		{
			rep_up = REP;			// reload timer
			enc++;					// add encoder accu
		}
	}

	if (rep_dn != 0)					// DOWN button rep counter going ?
	{
		rep_dn--;
		if (rep_dn == 0)
		{
			rep_dn = REP;			// reload timer
			enc--;					// subtract encoder accu
		}
	}

	IRQ_TEST = 0;					// timing test
	_T3IF = 0;
}
//-------------------------------------------------------------------------------------------------

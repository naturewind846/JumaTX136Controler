//*************************************************************************************************
//
// JUMA-TX500 Transmitter Controller
// Juha Niinikoski, OH2NLT 06.07.2008
//
// Microchip MPLAB + C30 compiler
// MCU dsPIC30F6014A
//
// Generates a MORSE message from string
//
// Brute Force Morse Code "character generator" 01.09.2009
// More morse characters coded 15.09.2009
// very slow CW keyer speed, downto 0.1 wpm 20.09.2009
// Beacon end quick TX release 11.10.2009
// Added QRSS and DFCW modes - F4GCB 08.2014
// Program structure modified to improve readability and maintenance - F4GCB 02-2015
// Bug fixed: command frequency (6 numbers) and speed (2 numbers) - F4GCB 04.2016
// Add CW identity option - F4GCB 04.2016
// Add play carrier in CW message - F4GCB 05.2016
// Some functions rewritten to save program memory space - F4GCB 10.2020
// Harmonization of timeslots control - F4GCB 10.2020
// Mode change limited with the \g command of the CW beacon - F4GCB 12.2021
//
//*************************************************************************************************

#include <stdio.h>
#include <string.h>
#include "eeprom_tx500.h"
#include "timers_pwm.h"

// External functions -----------------------------------------------------------------------------
extern void play_morse_sym(int);

// External variables -----------------------------------------------------------------------------
int morse_shift;						// TX morse shift for DDS

// Local variables --------------------------------------------------------------------------------
static const char morse_char_table[69][8]={
	// Simple but not very memory efficient Morse code character storage
	// special
	{' ',0},						//   0x20 (space),  index 0x00
	{'-','.','-','.','-',0},		// ! 0x21 (start),  index 0x01
	{'.','-','.','.','-','.',0},	// " 0x22 
	{'.','-','.','-','.',0},		// # 0x23 (end of message AR)
	{'.','.','.','-','.','.','-',0}, // $ 0x24
	{' ',0},						// % 0x25
	{'.','-','.','.','.',0},		// & 0x26 (wait AS)
	{'.','-','-','-','-','.',0},	// ' 0x27
	{'-','.','-','-','.',0},		// ( 0x28
	{'-','.','-','-','.','-',0},	// ) 0x29
	{'.','.','.','-','.','-',0},	// * 0x2A (end of contact SK)
	{'.','-','.','-','.',0},		// + 0x2B
	{'-','-','.','.','-','-',0},	// , 0x2C comma
	{'-','.','.','.','.','-',0},	// - 0x2D minus / hyphen
	{'.','-','.','-','.','-',0},	// . 0x2E period
	{'-','.','.','-','.',0},		// / 0x2F slash
	// numbers
	{'-','-','-','-','-',0},		// 0 0x30
	{'.','-','-','-','-',0},		// 1 0x31
	{'.','.','-','-','-',0},		// 2 0x32
	{'.','.','.','-','-',0},		// 3 0x33
	{'.','.','.','.','-',0},		// 4 0x34
	{'.','.','.','.','.',0},		// 5 0x35
	{'-','.','.','.','.',0},		// 6 0x36
	{'-','-','.','.','.',0},		// 7 0x37
	{'-','-','-','.','.',0},		// 8 0x38
	{'-','-','-','-','.',0},		// 9 0x39
	// special
	{'-','-','-','.','.','.',0},	// : 0x3A
	{'-','.','-','.','-','.',0},	// ; 0x3B
	{' ',0},						// < 0x3C
	{'-','.','.','.','-',0},		// = 0x3D
	{' ',0},						// > 0x3E
	{'.','.','-','-','.','.',0},	// ? 0x3F
	{'.','-','-','.','-','.',0},	// @ 0x40
	// letters, only capitals are coded
	{'.','-',0},					// a 0x41, 0x65
	{'-','.','.','.',0},			// b
	{'-','.','-','.',0},			// c
	{'-','.','.',0},				// d
	{'.',0},						// e
	{'.','.','-','.',0},			// f
	{'-','-','.',0},				// g
	{'.','.','.','.',0},			// h
	{'.','.',0},					// i
	{'.','-','-','-',0},			// j
	{'-','.','-',0},				// k
	{'.','-','.','.',0},			// l
	{'-','-',0},					// m
	{'-','.',0},					// n
	{'-','-','-',0},				// o
	{'.','-','-','.',0},			// p
	{'-','-','.','-',0},			// q
	{'.','-','.',0},				// r
	{'.','.','.',0},				// s
	{'-',0},						// t
	{'.','.','-',0},				// u
	{'.','.','.','-',0},			// v
	{'.','-','-',0},				// w
	{'-','.','.','-',0},			// x
	{'-','.','-','-',0},			// y
	{'-','-','.','.',0},			// z 0x5A, 0x7A
	// not coded
	{' ',0},						// 0x5B, 0x7B
	{' ',0},						// 0x5C
	{' ',0},						// 0x5D
	{' ',0},						// 0x5E
	{'.','.','-','-','.','-',0},	// _ 0x5F, 0x7F, index 0x3F
	// North/West European characters according to ISO 8859-4 Latin Alphabet 4
	{'.','-','.','-',0},			// � 0xE4, � 0xC4, index 0x40
	{'-','-','-','.',0},			// � 0xF6, � 0xD6, index 0x41
	{'.','-','-','.','-',0},		// � 0xE5, � 0xC5, index 0x42
	{'.','.','-','-',0},			// � 0xFC, � 0xDC, index 0x43
	// special code
	{'C'}							// play carrier
	};

static int morse_chr_idx;				// currently playing morse character dash/dot list index
static int morse_table_idx;				// currently playing morse character morse code table index
static int char_play;					// symbol playing, keyer reserved, 1=playing
static char b_buf[256];					// beacon text buffer
static char *b_buf_start;				// beacon text buffer start
static char *b_buf_ptr;					// beacon text buffer current pointer
static int b_state;						// beacon state machine, special character processing
static char b_buf_display[9];			// MORSE code display buffer


//=================================================================================================
// Test the message validity
//=================================================================================================
int morse_message(char *msg, int len)
{
	int i;

	if (strlen(msg) > len)
		return 0;

	// characters which must be 20h to 5Fh
	for (i=0; i<strlen(msg); i++)
	{
		// convert lower case to upper case 
		if (msg[i] > 0x60 && msg[i] < 0x7B)
			msg[i] -= 0x20;
		if (msg[i] < 0x20 || msg[i] > 0x5F)
			return 0;
	}

	return 1;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Return the period in ms for one dot in function of the speed
//=================================================================================================
long morse_get_period(int speed, int unit)
{
	if (unit)						// speed in seconds
		return (long)1000 * speed;

	return 1200 / speed;			// speed in wpm
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Clear transmitted MORSE characters buffer for display
//=================================================================================================
void morse_clear_display(void)
{
	int i;

	for (i=0; i<8; i++)
		b_buf_display[i] = ' ';
	b_buf_display[i] = 0x00;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set transmitted MORSE characters buffer for display
//=================================================================================================
void morse_set_display(unsigned char c)
{
	int i;
	unsigned char cc;

	// convert Scandinavian characters for the LCD module
	switch(c)
	{
		case 0xC4: case 0xE4:				// �, �
			cc = 0xE1;						// �
		break;

		case 0xD6: case 0xF6:				// �, �
			cc = 0xEF;						// �
		break;

		case 0xC5: case 0xE5:				// �, �
			cc = 0x61;						// a
		break;

		case 0xDC: case 0xFC:				// �, �
			cc = 0xF5;						// �
		break;

		case 0x5C:							// in some LCD displays back slash is Yen sign
			cc =0x60;						// substitute with accent
		break;

		default:
			cc = c;							// no conversion
		break;
	}

	// shift buffer left
	for (i=0; i<8; i++)
		b_buf_display[i] = b_buf_display[i+1];

	// insert new character
	b_buf_display[7] = cc;
	b_buf_display[8] = ' ';
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Convert Ascii to morse code table index
//=================================================================================================
int convert_ascii2morse_idx(unsigned char c)
{
	int idx;

	switch (c)
	{
		// �, �
		case 0xC4: case 0xE4:
			idx = 0x40;
		break;

		// �, �
		case 0xD6: case 0xF6:
			idx = 0x41;
		break;

		// �, �
		case 0xC5: case 0xE5:
			idx = 0x42;
		break;

		// �, �
		case 0xDC: case 0xFC:
			idx = 0x43;
		break;

		// all other
		default:
			// convert all control characters to space
			if (c < 0x20)
				c = 0x20;

			// convert small letters to capital
			if (c > 0x5F)
				c = c - 0x20;

			// addjust table index range 0 ... 0x5F
			idx = c - 0x20;
		break;
	}

	return idx;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Convert number from beacon buffer
//=================================================================================================
static unsigned long get_number(int nb)
{
	unsigned long number = 0;
	int i;

	for (i=0; i<nb; i++)
	{
		if (*b_buf_ptr == 0 || *b_buf_ptr == 0x0D)
			return -1;
		number = (number * 10) + (*b_buf_ptr & 0x0F);
		b_buf_ptr++;;
	}

	return number;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Play one ascii character, blocking
//=================================================================================================
void morse_play_character(char chr)
{
	while (char_play);								// wait for free

	morse_table_idx = convert_ascii2morse_idx(chr);	// compute & set morse character table index
	morse_chr_idx = 0;								// start play
	char_play = 1;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Play string, NULL or CR terminate
//=================================================================================================
void morse_play_string(const char *str)
{
	while ((*str)!= 0 && (*str)!= 0x0D)
	{
		morse_set_display(*str);
		morse_play_character(*str);		// play
		str++;
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Init MORSE beacon
//=================================================================================================
void morse_init_beacon(const char *str)
{
	strcpy(b_buf, str);
	b_buf_start = b_buf;				// save start address
	b_buf_ptr = b_buf;					// set current pointer
	b_state = 0;						// expect printable characters
	morse_clear_display();				// clear display text buffer
	char_play = 0;						// no end of symbol if stop keyer beforehand
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Beacon MORSE character generator
// 1ms IRQ function, feed beacon character dash/dot info to the keyer code
//=================================================================================================
void morse_char_irq(void)
{
	char c;
	const char carrier[] = {" carrier"};

	// run logic only when play character active
	if (ts.on && char_play)
	{
		c = morse_char_table[morse_table_idx][morse_chr_idx];

		// action based on look up character
		switch (c)
		{
			// end of mark
			case 0: default:
				char_play = 0;
			break;

			// other
			case ' ': case '-': case '.':
				morse_chr_idx++;
			break;
		}
		play_morse_sym(c);
	}
	else if (ts.on)
	{
		// get character
		c = *b_buf_ptr;

		// test end of message
		if (c == 0 || c == 0x0D)
		{
			// start over
			b_buf_ptr = b_buf_start;
			char_play = 0;							// CW message finished
			ts.on = 0;
			ts.end = 1;
			morse_clear_display();
		}
		else										// was not end of message, decode & play
		{
			b_buf_ptr++;							// prepare for next character
			switch (b_state)
			{
				case 0: default:					// test if command sequence start character \ back slash
					if (c == 0x5C)
						b_state = 1;
					else
					{								// compute & set morse character table index
						morse_table_idx = convert_ascii2morse_idx(c);
						morse_chr_idx = 0;								
						char_play = 1;
						morse_set_display(c);					// run rolling characters for display
					}
				break;

				case 1:	
					switch (c)						// select command
					{
						case 'c': case 'C':
							morse_table_idx = 68;
							morse_chr_idx = 0;								
							char_play = 1;
							sprintf(b_buf_display, carrier);
						break;

						case 'd': case 'D':
							set_dot_time(get_number(3), 1, 0, 0);
						break;

						case 'f': case 'F':
							set_frequency(get_number(6), 1, 0, 1);
						break;
				
						case 'g': case 'G':
							
							set_mode(get_number(1), 2, 0, 0);
							if (flag.cwid)					// use for CW identity option
							{
								morse_clear_display();
								if (eeprom.defval.mode > 2)
								{
									b_buf_ptr = b_buf_start;
									char_play = 0;
									b_state = 0;
									ts.on = 0;
									ts.end = 1;
								}
							}
						break;

						case 'p': case 'P':
							set_tx_power(get_number(1), 1, 0, 0);
						break;

						case 'r': case 'R':
							set_cw_shift(get_number(2), 1, 0, 0);
						break;

						case 's': case 'S':
							set_cw_speed(get_number(3) / 10, 1, 0, 0);
						break;
					}
					b_state = 0;					// unknown, reset state machine
				break;
			}
		}
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Return transmitted MORSE characters buffer for display 8 characters
//=================================================================================================
 char *morse_get_display(char *string)
{
	if (ts.on)
		strcpy(string, b_buf_display);
	else
		sprintf(string, "%.2d:%.2d:%.2d ", (ts.wait / 3600), (ts.wait % 3600) / 60, (ts.wait % 3600) % 60);

	return string;
}
//-------------------------------------------------------------------------------------------------

//*************************************************************************************************
//
// JUMA-TX500 Transmitter Controller
// Juha Niinikoski, OH2NLT 06.07.2008
//
// Microchip MPLAB + C30 compiler
// MCU dsPIC30F6014A
//
// Generates a MORSE message from string
//
// Brute Force Morse Code "character generator" 01.09.2009
// More morse characters coded 15.09.2009
// very slow CW keyer speed, downto 0.1 wpm 20.09.2009
// Beacon end quick TX release 11.10.2009
// Added QRSS and DFCW modes - F4GCB 08.2014
// Program structure modified to improve readability and maintenance - F4GCB 02-2015
// Bug fixed: command frequency (6 numbers) and speed (2 numbers) - F4GCB 04.2016
// Add CW identity option - F4GCB 04.2016
// Add play carrier in CW message - F4GCB 05.2016
// Some functions rewritten to save program memory space - F4GCB 10.2020
// Harmonization of timeslots control - F4GCB 10.2020
//
//*************************************************************************************************

#ifndef MORSE_H
#define MORSE_H

	// Variables
	extern int morse_shift;							// TX morse shift for DDS

	extern int morse_message(char *, int);			// Test the message validity
	extern long morse_get_period(int, int);			// Return the period in ms for one dot in function of the speed
	extern void morse_clear_display(void);			// Clear transmitted MORSE characters buffer for display
	extern void morse_play_character(char);			// Play one ascii character, blocking
	extern void morse_play_string(const char *);	// Play string, NULL or CR terminate
	extern void morse_init_beacon(const char *);	// Init beacon logic
	extern void morse_char_irq(void);				// Beacon Morse character generator 1ms IRQ
	extern char *morse_get_display(char *);			// Return transmitted MORSE characters buffer for display

#endif

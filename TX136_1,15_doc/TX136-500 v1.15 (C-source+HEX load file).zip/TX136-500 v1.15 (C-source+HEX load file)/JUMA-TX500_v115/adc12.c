//*************************************************************************************************
//
// JUMA-TX500/136 30F6014A ADC12 routines
//
// Juha Niinikoski OH2NLT 25.11.2006
//
// Microchip C30 compiler version
//
// Program structure modified to improve readability and maintenance - F4GCB 02-2015
//
//*************************************************************************************************

#include <p30f6014A.h>

// External functions -----------------------------------------------------------------------------
extern void us_delay( unsigned int);	


//=================================================================================================
// Init ADC system for JUMA-TX500/136 board
// remember to set ADC pins as port input
// Reference from AVCC
//=================================================================================================
void init_adc12(void)
{
	ADCSSL = 0x0000;					// scan select
	ADPCFG = 0x81FF;					// AN9 to AN14 in use
	ADCHS = 0x000E;						// select CH14, Vref- for MUXA
	ADCON3 = 0x0080;					// internal RC clock
	ADCON2 = 0x0000;					// use MUXA, do not scan inputs
	ADCON1 = 0x8000;					// ADON, format = integer, manual sampling, manual start		
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Convert selected channel
//=================================================================================================
int convert_adc12(unsigned int adchs)
{
	ADCHS = (adchs & 0x000F);						// select CH, Vref- for MUXA
	ADCON1bits.SAMP = 1;							// start sampling
	us_delay(500);
	ADCON1bits.SAMP = 0;							// start conversion

	while(ADCON1bits.DONE == 0);					// wait for ready

	return(ADCBUF0);								// return with buff#0
}
//-------------------------------------------------------------------------------------------------


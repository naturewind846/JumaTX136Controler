//*************************************************************************************************
//
// dsPIC30 timers PWM DAC for JUMA-TX500
// Juha Niinikoski, OH2NLT 16.08.2009
//
// Microchip C30 compiler conversion
//
// JUMA-PATX500 timer & pwm system
//
// Timer & PWM unit usage
//
// TMR1
// TMR2 is used for tone generation, IRQ driven system, RD1/OC2 = tone out
// TMR3 is used for 1ms timer tick IRQ and for LCD PWM dac timebase
// OC3 output is for LCD back light control
// OC4 output is for LCD contrast
// OC3 and OC4 are connected to TMR3
//
// TMR4
// TMR5 used for delays (separate module)
//
// encoder simulatot repeat logic added 13.08.2008
// hardware tone generator with TMR2 & OC2 18.08.2009
// Buzzer notone play cleaned, no click 25.08.2009
// Add QRSS and DFCW modes - F4GCB 08.2014
// Add WSPR mode - F4GCB 10.2014
// Add OPERA mode and WSPR modifications - F4GCB 11.2014
// Program structure modified to improve readability and maintenance - F4GCB 12-2014
// Add JASON mode - F4GCB 05.2015
// Add CW identity option - F4GCB 04.2016
// Add SCRIPT mode - F4GCB 04.2016
// Add play carrier in CW message - F4GCB 05.2016
// Add WSQ mode - F4GCB 06.2016
// PTT management modified - F4GCB 06.2016
// Add JT9 mode - F4GCB 07.2016
// Add tune on/off with CW UP/DOWN buttons, SW 1.10 - F4GCB 11-2018
// Some functions rewritten to save program memory space - F4GCB 10.2020
// Harmonization of timeslots control - F4GCB 10.2020
// Add FST4W mode - F4GCB 10.2020
// Improvement of script management - F4GCB 12.2021
//
//*************************************************************************************************

#ifndef TIMERS_H
#define TIMERS_H

	struct counter
	{
		int ms;							// 1s divider, 1000ms counter
		long s;							// 36000s divider, 1s counter
		int sync;						// synchronization counter 0 to 3599s
		long script;					// script counter	
		int ms_offset;					// offset for WSPR counter
		long busy;						// tone generator busy(ms), busy if != 0
		long cw_break;					// CW break counter
		int blink;						// blink cycle (ms)		
		int roll;						// roll cycle (ms)
		long tone;						// beep tone length (ms)
		int decay;						// power meter slow decay
		long push;						// long push timer, count from set value to zero
		int gps;						// GPS synchronization timer, no synchro if = 0
		int gps_hour;					// GPS hour
	};
	extern struct counter counter;

	struct flag
	{
		int blink;						// display alarm blink flag
		int roll;						// display beacon roll flag
		int beacon;						// beacon transmit flag
		int cwid;						// CW identification flag for CW mode
		int ptt;						// ptt flag to run beacon or script once
		int msg;						// message from JUMA software flag
	};
	extern struct flag flag;

	struct set
	{
		long sidetone;					// calculated sidetone timer set value
		long cw_break;					// set value for the timer
		long cw_period;					// cw impulse period for the keyer code(ms)
		int ptt;						// type of PTT used (auto, mox or rts)
		int ts;							// timeslot period in s
	};
	extern struct set set;

	struct old
	{
		int mode;						// temporary storage for mode	
		int pa_state;					// temporary storage for pa state
		int keyer;						// temporary storage for keyer mode
		int key;						// temporay storage for ptt
		int ts;							// temporary storage for timeslot period in s
	};
	extern struct old old;

	struct ts
	{
		int period;						// timeslot period in s
		int on;							// timeslot available for TX
		int end;						// timeslot finished
		int next;						// next timeslot time available
		int wait;						// time waiting before tx
		int cwid;						// cwid in progress
	};
	extern struct ts ts;

	extern void init_timers_pwm(void);			// Init timer & PWM system
	extern void set_pwm3_dac(unsigned int);		// LCD back light
	extern void set_pwm4_dac(unsigned int);		// LCD contrast
	extern void tone_on(int tone);				// Start tone
	extern void tone_off(void);					// Stop tone
	extern void beep(int, unsigned long);		// Generate beep
	extern void set_ptt_out(int);				// Set PTT out handling
	extern void set_tx_on(unsigned long);		// Set TX on sequence
	extern void set_spot_on(unsigned long);		// Set SPOT on
	extern void set_tx_off(void);				// Set TX or spot off
	extern int encoder_get(void);				// Simulate encoder with UP / DN buttons - read encoder
	extern void stop_keyer(void);				// Brute force stop all keyer activity
	
#endif

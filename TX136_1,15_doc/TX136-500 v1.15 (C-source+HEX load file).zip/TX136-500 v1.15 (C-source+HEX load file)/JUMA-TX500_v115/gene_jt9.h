//*************************************************************************************************
//
// JUMA-TX500/136 Transmitter Controller
// F4GCB 07.2016
//
// Microchip MPLAB + C30 compiler
// MCU dsPIC30F6014A
//
// Generates a JT9 message from 13 characters string
//
// Acknowledgement :
// The JT9 message algorithm is derived from Fortran files found in the K1JT WSJTX source code.
// Portions of the JT9 message algorithm is the work of Andy Talbot, G4JNT
// Portions of this code is derived from the work of Jason Milldrum
//
// Some functions rewritten to save program memory space - F4GCB 10.2020
// Harmonization of timeslots control - F4GCB 10.2020
//
//*************************************************************************************************

#ifndef JT9_H
#define JT9_H

	// Variables
	extern int jt9_shift[9];						// TX JT9 shift for DDS

	// Functions
	extern void jt9_init_beacon(const char *);		// Init JT9 beacon
	extern void jt9_sym_irq(void);					// Beacon JT9 generator
	extern char *jt9_get_code(char *);				// Return transmitted JT9 symbol value

#endif

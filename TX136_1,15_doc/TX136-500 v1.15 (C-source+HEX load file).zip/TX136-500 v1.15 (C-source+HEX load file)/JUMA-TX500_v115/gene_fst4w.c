//*************************************************************************************************
//
// JUMA-TX500/136 Transmitter Controller
// F4GCB 10.2020
//
// Microchip MPLAB + C30 compiler
// MCU dsPIC30F6014A
//
// Generates a FST4W message from call locator and power to a symbol/tone
// The WSPR generator is used to check call, locator and power
//
// Acknowledgement :
// The FST4W message algorithm is derived from Fortran found in the K1JT, K9AN
// and G4WJS WSJT-X 2.3.0 source code. 
// CRC generation is derived from the work of Kay Gorontzi, GHSi.de
//
//*************************************************************************************************

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "gene_wspr.h"
#include "timers_pwm.h"

// External functions -----------------------------------------------------------------------------																
extern void play_fst4w_sym(int);		// play one FST4W symbol

// Local functions --------------------------------------------------------------------------------
static char chr_norm_fst4w(char, int);
static unsigned long fst4w_code_call(char *);
static unsigned long fst4w_code_grid(char *);
static void fst4w_code_50_bits(unsigned long, unsigned long, int, int *);
static void add_crc24(int *);
static void ldcp_240_74(int *, int *);
static void transmission_symbols(int *);


// External variables -----------------------------------------------------------------------------
int fst4w_shift[4];						// TX FST4W shift for DDS

// Local variables --------------------------------------------------------------------------------
const static char matrix[166][20] = {	// 240-74 LDCP matrix
	("de8b3201e3c59f55a14"),
  	("2e06d352ebc5b74c4fc"),
  	("2e16d6cf5a725c3244c"),
  	("84f5587edca6d777de4"),
  	("e152b1e2b5965093ecc"),
  	("244b4828a2ccf2b5f58"),
  	("5fbbaade810e123c730"),
  	("6b7e92a99a918df3d44"),
  	("bbcec6a63ab757a7278"),
  	("f5f3f0b89a21ceccdb0"),
  	("a248c5f1ec2bc816290"),
  	("c84bbad839a5fe76d0c"),
  	("ad724129bbf4c7f4570"),
  	("91adb56e7623a2575cc"),
  	("cbe995bdf156df2c9e4"),
  	("92ff6ea492c08c150e0"),
  	("c4ddbe5a02f6a933384"),
  	("d2e9befc131dc483858"),
  	("68567543d1eebcb080c"),
  	("21fa61d559f9baf6abc"),
  	("911c4fbbafc72e3db28"),
  	("7c0b534af4b7d583d50"),
  	("12ce371b90ee9dfe72c"),
  	("15a604148872e251ec4"),
  	("3a3c9f3eb0e0f96edc0"),
  	("705919ffb636f96b390"),
  	("43daaaa8163d6bc2bd4"),
  	("96e11ea798b74b10e98"),
  	("811150609c9dee8230c"),
  	("be713f85ab34380f4b0"),
  	("5a02c4abaaccb8f24c4"),
  	("67bdebb8863d04768cc"),
  	("5a449cd90c3dbdfe844"),
  	("9c7a54d1c4ef7418b84"),
  	("cd82fefaaf9cd28cd8c"),
  	("ca47e847fabb0054a38"),
  	("f0b30cef6aab9e37f98"),
  	("d948d912fbcc1708710"),
  	("cce1a7b355053d98270"),
  	("4cf227c225a9063dd48"),
  	("2db92612e9ba1418e24"),
  	("3d215c04c762c3d6a28"),
  	("77de65500b5624ceb0c"),
  	("fd1a1df99ded2fb9d88"),
  	("2a19392c71438410fb8"),
  	("a9b486a9d26ed579754"),
  	("b698d244ac78d97a498"),
  	("3d7975b74d727a5e704"),
  	("38094225a2bce0e1940"),
  	("3d3e58fae40fac342b0"),
  	("7732e839a066e337714"),
  	("69356c082b7753a47b0"),
  	("3e868a55dc403a802ac"),
  	("a0157a14a6bf7fdbbcc"),
  	("1ab628e11a7ab4a7c44"),
  	("9da3a2247d7449052f4"),
  	("199a8a7b114816b97f4"),
  	("b1c5cde2542061704cc"),
  	("432fa8d3a153eafbdc8"),
  	("c4ece7e400d8a89c448"),
  	("316ecf74e4b983f007c"),
  	("6a14fa8e713bb5e8adc"),
  	("da4b957ded8374e3640"),
  	("0a804dba7c7e4533300"),
  	("52c342ed033f86580e0"),
  	("1667da8d6fcf4272470"),
  	("da2f7038d550fa88d8c"),
  	("685bcbab1d9dd2c2a44"),
  	("4c93008b3156b3636bc"),
  	("726998d6327ac797c3c"),
  	("44ece7e400d8a8dc448"),
  	("01f9add00dfe823a948"),
  	("dbb95f5ce9e371ad720"),
  	("fc746ee5c76827a8728"),
  	("b25408029506467f4b4"),
  	("9b5c9219e21126b7cf8"),
  	("39ae9f48ba9d1a24f04"),
  	("7de2699623eb507f938"),
  	("b9c6e903ee91dd32934"),
  	("397510d2c6cb5e81de8"),
  	("20157a14aebf7fdbbec"),
  	("067f76ea5817a465980"),
  	("9248f3cea0869feb994"),
  	("23cde2678004ebe5f80"),
  	("5b81fe6848f58e3cfa8"),
  	("a9099ace96bff092904"),
  	("4afa4b0802b33215438"),
  	("f4f740396b030360858"),
  	("fc613f77a35ee1163b8"),
  	("1a4dc27d7e8cc835ff4"),
  	("e9b056f153b39def7ec"),
  	("b62eb777a2f953c7efc"),
  	("388ae4de514b62d238c"),
  	("891529af40e85317160"),
  	("474f1afeb724dbd2ba8"),
  	("11d70880fd88fdd307c"),
  	("29f26a3acb76e6a517c"),
  	("df3e902ff9cadcf776c"),
  	("e3c42da8445965c09f0"),
  	("ce277a6aeccc316dc58"),
  	("4d7841fb71543abd9b8"),
  	("e63230d2d465fb44750"),
  	("b6e11fa798b74b14e98"),
  	("05f189d37c5616547b4"),
  	("ebdb51a81d1e883baa8"),
  	("bf5bc736663bcd53ae0"),
  	("2f8d1cc0936142c08fc"),
  	("436b22fc36d917b6928"),
  	("044b482822ccf2b5f58"),
  	("37b2e839a066e3b7714"),
  	("2a9b4b765c581f0c51c"),
  	("10a7d44cecf8e6628dc"),
  	("ad95f02df6d5502dd4c"),
  	("bbd34f8afd63deaf564"),
  	("cabddfeb01fce632788"),
  	("66b57babeedd6124114"),
  	("7813e0454fbd462be8c"),
  	("b6105ed6f01ea621d04"),
  	("9f68bbcec679d1c088c"),
  	("673da96e414fc7a0f40"),
  	("5568adb935e11084abc"),
  	("f6dd308de5e5c4f6fb0"),
  	("3b49e80d40ae596c7b4"),
  	("a3cde2478004ebe5f80"),
  	("dd8e4f309e919d5ed94"),
  	("5a4020d387757d7bc28"),
  	("64f9e02ae32362a255c"),
  	("630d5942d392334b0dc"),
  	("0bd7e9f4229b2dee210"),
  	("bca549a9467d3a2550c"),
  	("2fef7b1f578c5e28d04"),
  	("f35e0fdda1be4b3b35c"),
  	("69ed575e7cc537d2394"),
  	("7dfdcfbfd5ef3093680"),
  	("b3b2921af97f251d328"),
  	("5622d0fe90363522364"),
  	("fcd4fc7fa04a69d2ac4"),
  	("1119ea451502ed9ab34"),
  	("970ee777ec969a41754"),
  	("688d14f8afec76783dc"),
  	("4d0b8a1028578407420"),
  	("d3d2138d9fa268da3e8"),
  	("df1bdbff898e006394c"),
  	("8ac478a916bb0b77684"),
  	("93881997428e2c17a94"),
  	("4aa510e746245e90c08"),
  	("e00cb8543f85a5d58b8"),
  	("9100d8eb74031073044"),
  	("38710e4235bd1e4003c"),
  	("6aef311cac4c4dccfd4"),
  	("58430f577f51c36b3e0"),
  	("12082fa5d4268a95b4c"),
  	("7a7435a0aca071e64d0"),
  	("cd8250ebadc95de15b0"),
  	("debad40c852e99d64dc"),
  	("4e6caa5e7c86efef748"),
  	("a5d4cbb97e726e3c580"),
  	("7e3a0a2c73ef8553640"),
  	("b60bfc2fd2bd8f530dc"),
  	("32dbef097a5f84b0318"),
  	("4cc7c1cf434300be380"),
  	("896840945be8eabf7f0"),
  	("36c9b10ec694819a0a0"),
  	("349f46a799ef95a47c8"),
  	("9bdcd4ce2563e560b74"),
  	("b19fcd7111a335c52ec")};
static const int syncword1[8] = {0,1,3,2,1,0,2,3};	// predefined synchronization symbols
static const int syncword2[8] = {2,3,1,0,3,2,0,1};	// predefined synchronization symbols 
static int symbol[160];		// final symbols
static int symbol_idx;		// currently playing FST4W symbol list index


//=================================================================================================
// Normalize characters space 0..9 A..Z in order 0..36
//=================================================================================================
char chr_norm_fst4w(char bc, int type) 
{
	//type = 0 for "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ" and "0123456789"
	//type = 1 for " 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
	//type = 2 for " ABCDEFGHIJKLMNOPQRSTUVWXYZ"
	//type = 3 for "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

	char cc = 0;
	int offsetdig = 0, offsetlet = 10;

	switch (type)
	{
		case 1:
			offsetdig = 1;
			offsetlet = 11;
		break;

		case 2:
			offsetlet = 1;
		break;

		case 3:
			offsetlet = 0;
		break;
	}

  	if (bc >= '0' && bc <= '9') cc = bc - '0' + offsetdig;
  	if (bc >= 'A' && bc <= 'Z') cc = bc - 'A' + offsetlet;
  	if (bc >= 'a' && bc <= 'z') cc = bc - 'a' + offsetlet;
  	if (bc == ' ' ) cc = 0;

  	return(cc);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Coding of callsign
//=================================================================================================
unsigned long fst4w_code_call(char *call)
{
	int i;
	unsigned long code, ntokens = 2063592, max22 = 4194304;

	// the third character must always be a number
  	if (chr_norm_fst4w(call[2], 0) > 9) 
  	{
		for (i=5; i>0; i--) 
    		call[i] = call[i-1];
    	call[0] = ' ';
  	}

  	code = chr_norm_fst4w(call[0], 1);
  	code = code * 36 + chr_norm_fst4w(call[1], 0);
  	code = code * 10 + chr_norm_fst4w(call[2], 0);
  	code = code * 27 + chr_norm_fst4w(call[3], 2);
  	code = code * 27 + chr_norm_fst4w(call[4], 2);
  	code = code * 27 + chr_norm_fst4w(call[5], 2);

	return code + ntokens + max22;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Coding of grid
//=================================================================================================
unsigned long fst4w_code_grid(char *grid)
{
	unsigned long code;

  	// coding of grid
	code = chr_norm_fst4w(grid[0], 3)*18*10*10;
  	code = code + chr_norm_fst4w(grid[1], 3)*10*10;
  	code = code + chr_norm_fst4w(grid[2], 0)*10;
	code = code + chr_norm_fst4w(grid[3], 0);

	return code;
}
//------------------------------------------------------------------------------------------------


//=================================================================================================
// Code1 (call), code2 (grid) and power level merged into 50 bits code
//=================================================================================================
void fst4w_code_50_bits(unsigned long code1, unsigned long code2, int ndbm, int *message)
{
	int i;
	unsigned long temp;

	// 28 bits callsign
	temp = code1;
	for (i=27; i>=0; i--)
	{
		message[i] = temp & 0x0001;
		temp = temp >> 1;
	}
  	// merge 15 bits grid
	temp = code2;
	for (i=42; i>=28; i--)
	{
		message[i] = temp & 0x0001;
		temp = temp >> 1;
	}

	// merge 5 bits ndbm
	temp = 0.3 * ndbm;
	for (i=47; i>=43; i--)
	{
		message[i] = temp & 0x01;
		temp = temp >> 1;
	}

	// the remaining byte-array elements set to 0
	for (i=48; i<74; i++) message[i] = 0;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Add a 24-bit CRC to the 50 bits callsign grid and power level compressed
//=================================================================================================
void add_crc24(int *message)
{
	int i, xor, crc[24]; 

	// Linear Feedback Shift Register implementation
	// polynomial 0x100065B (1000000000000011001011011) for 24-bit CRC
	for (i=0; i<24; i++)  crc[i] = 0;
	for (i=0; i<50; i++)
    {
		xor = message[i] ^ crc[23];
	  	crc[23] = crc[22];
      	crc[22] = crc[21];
      	crc[21] = crc[20];
      	crc[20] = crc[19];
      	crc[19] = crc[18];
      	crc[18] = crc[17];
     	crc[17] = crc[16];
      	crc[16] = crc[15];
      	crc[15] = crc[14];
      	crc[14] = crc[13];
      	crc[13] = crc[12];
      	crc[12] = crc[11];
     	crc[11] = crc[10];
      	crc[10] = crc[9] ^ xor;
      	crc[9] = crc[8] ^ xor;
      	crc[8] = crc[7];
      	crc[7] = crc[6];
      	crc[6] = crc[5] ^ xor;
      	crc[5] = crc[4];
      	crc[4] = crc[3] ^ xor;
      	crc[3] = crc[2] ^ xor;
      	crc[2] = crc[1];
      	crc[1] = crc[0] ^ xor;
      	crc[0] = xor;
	}
	 
	// Add CRC 24
	for (i=0; i<24; ++i) message[73-i] = crc[i];
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Forward error correction via a (240,74) LDPC code
//=================================================================================================
void ldcp_240_74(int *message, int *codeword)
{
	char hex[2];
	int i, j, k, str, bmax, col, sum, generator[74], paritychecks[166];

	// create the parity checks
	for (i=0; i<166; i++)
	{
		for (j=0; j<19; j++)
		{
			memcpy(hex, matrix[i]+j, 1);
			str = (int)strtol(hex, NULL, 16);	
			if (j==18) bmax = 2;
			else bmax = 4;
			for (k=0; k<bmax; k++)
			{
				col = (j*4) + k;
				if (str & (0x0001 << (3-k))) generator[col] = 1;
				else generator[col] = 0;
			}
		}
		sum = 0;
		for (j=0; j<74; j++)
			sum = sum + (message[j] * generator[j]);
		paritychecks[i] = sum % 2;		
	}
	
	// create the codeword
	for (i=0; i<74; i++) codeword[i] = message[i];
	for (i=74; i<240; i++) codeword[i] = paritychecks[i-74];
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Pairs of codeword bits mapping and synchronization symbols
//=================================================================================================
void transmission_symbols(int *codeword)
{
	int i, code, temp[120];

	// Grayscale mapping : 00->0, 01->1, 11->2, 10->3
	for (i=0; i<120; i++)
	{
		code = codeword[(2*i)+1]+ 2*codeword[2*i];
		if (code <= 1) temp[i] = code;
		if (code == 2) temp[i] = 3;
		if (code == 3) temp[i] = 2;
	}

	// interleave synchronization symbols
	for (i=0; i<8; i++) symbol[i] = syncword1[i];
	for (i=8; i<38; i++) symbol[i] = temp[i-8];
	for (i=38; i<46; i++) symbol[i] = syncword2[i-38];
	for (i=46; i<76; i++) symbol[i] = temp[i-16];
	for (i=76; i<84; i++) symbol[i] = syncword1[i-76];
	for (i=84; i<114; i++) symbol[i] = temp[i-24];
	for (i=114; i<122; i++) symbol[i] = syncword2[i-114];
	for (i=122; i<152; i++) symbol[i] = temp[i-32];
	for (i=152; i<160; i++) symbol[i] = syncword1[i-152];
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Init FST4W beacon
//=================================================================================================
void fst4w_init_beacon(const char *call_in, const char *grid_in, const int ndbm_in)
{
	int ndbm;
	char call[13], grid[7];
	int message[74];		// 74 bits messsage : 50 bits callsign grid and power level compressed and 24-bit CRC
	int codeword[240];		// 240-bit codeword

	strcpy(call, call_in);
	strcpy(grid, grid_in);
	ndbm = wspr_ndbm(ndbm_in);

	fst4w_code_50_bits(fst4w_code_call(call), fst4w_code_grid(grid), ndbm, message);
	add_crc24(message);
	ldcp_240_74(message, codeword);
	transmission_symbols(codeword);
  
	symbol_idx = 0;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Beacon FST4W generator
// 1ms IRQ function, feed beacon WSPR symbols to the keyer code
//=================================================================================================
void fst4w_sym_irq(void)
{
	// run logic only when play symbol
	if(ts.on)
	{
		if (symbol_idx == 160)				// end of timeslot
		{
			symbol_idx = 0;
			ts.on = 0;
			ts.end = 1;
		}
		else
		{
			play_fst4w_sym(symbol[symbol_idx]);
			symbol_idx++;
		}
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Return transmitted FST4W symbol value for display
//=================================================================================================
char *fst4w_get_code(char *code)
{
	int x;

	if (ts.on)
	{
		x = symbol_idx;
		code[0] = 'S';
		code[1] = ' ';
		code[2] = ((x/100)+'0');
		x-=(x/100)*100;
		code[3] = ((x/10)+'0');
		x-=(x/10)*10;
		code[4] = (x +'0');
		code[5] = ':';
		x = symbol[symbol_idx - 1];
		code[6] = (x +'0');
		code[7] = ' ';
		code[8] = ' ';
	}
	else
		sprintf(code, "%.2d:%.2d:%.2d ", (ts.wait / 3600), (ts.wait % 3600) / 60, (ts.wait % 3600) % 60);

	return code;
}
//-------------------------------------------------------------------------------------------------

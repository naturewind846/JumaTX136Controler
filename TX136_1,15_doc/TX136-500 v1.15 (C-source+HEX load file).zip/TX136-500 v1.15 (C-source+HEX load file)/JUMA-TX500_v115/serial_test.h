//*************************************************************************************************
//
// JUMA-TX136/500 serial I/O test command set
//
// Juha Niinikoski, OH2NLT 06.07.2006
//
//
// Add QRSS and DFCW modes - F4GCB 08.2014
// Program structure modified to improve readability and maintenance - F4GCB 02-2015
//
//*************************************************************************************************


#ifndef TEST
#define TEST

	extern void dump_eeprom(void);				// Dump the eeprom contents
	extern void serial_test(void);				// Serial test commands

#endif

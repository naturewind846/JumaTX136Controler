//*************************************************************************************************
//
// Simple UART interface for dsPIC30F6012
// Juha Niinikoski, OH2NLT 18.05.2005
//
// Below is the code to initialize the USART
// 8 bits, 1 start and 1 stop, no error handling
// kbhit and getch added 22.05.2005
// getche added 02.06.2005
// overrun error handling added 29.08.2005
// MPLAB C30 conversion, OH2GWE 2006.10.17
// Baud Rate setup & IRQ receiver for fast baud rates 14.01.2008
// Adaptation to JUMA-PA100 board, FCY = 7,3728MHz, 07.07.2008
// UART init sequence changed 30.10.2008
// rx buffer pointer cast corrections 18.11.2008
//
// Program structure modified to improve readability and maintenance - F4GCB 02-2015
// Used only to read GPS NMEA frames at 4800 or 9600 bauds - F4GCB 05-2015
//
//*************************************************************************************************

#include <p30f6014A.h>

// Definitions ------------------------------------------------------------------------------------
#define BAUD_DEFAULT  0								// 4800
 
// Local variables --------------------------------------------------------------------------------
static volatile unsigned char rx_buffer[256];      	// UART mod(256) RX queue, must be exactly 256 long
static volatile unsigned char rx_buf_out_idx = 0;  	// buffer output index, pointer behind in idx
static volatile unsigned char rx_buf_in_idx = 1;   	// buffer input index, pointer always "leading"
static const unsigned int baud_rates[2] = 			// Baud Rate divisors for 29,4912 MHz osc =  7,3728 MHz
	{95, 47};										// 4800>95, 9600>47
static int baud_sel = BAUD_DEFAULT;					// baud rate selected			


//=================================================================================================
// UART2 IRQ service
// put received character to RX queue
//=================================================================================================
void __attribute__((interrupt, no_auto_psv)) _U2RXInterrupt(void)
{
  	unsigned char rx;

  	rx = U2RXREG;                        							// data read
  	if((unsigned char)(rx_buf_in_idx + 1) != rx_buf_out_idx) 		// check overrun
  		rx_buffer[rx_buf_in_idx++] = rx;    						// place just received character in queue
 
	// check & handle possible errors
	if(U2STAbits.OERR == 1)											// OERR is blocking uart, should not happen but..
		U2STAbits.OERR = 0;											// reset overrun error if occured

	// this is not automatic in 30F6014 UART
	IFS1bits.U2RXIF = 0;											// reset irq flag
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// UART2 init
//=================================================================================================
void uart2_init(void)
{
	//U1BRG = ((FCY/16)/BAUD) - 1;   	// set baud rate
 	U1BRG = baud_rates[BAUD_DEFAULT];	// set intial baud rate to 4800

	U2MODE = 0x0000;
 	U2STA = 0x0400;						// IRQ on every character
 	IFS1bits.U2RXIF = 0;				// clear possible pending irq
 	IEC1bits.U2RXIE = 1;				// enable RX IRQs
 	U2MODEbits.UARTEN = 1;				// enable uart
 	U2STAbits.UTXEN = 1;				// enable transmitter
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Switch baud rate
//=================================================================================================
void uart2_set_baud(void)
{
	baud_sel = !baud_sel;		
	U2BRG = baud_rates[baud_sel];		// set baud rate
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Clear serial port, reset input buffer
//=================================================================================================
void uart2_clear(void)
{
	rx_buf_out_idx = 0;  				// buffer output index
	rx_buf_in_idx = 1;   				// buffer input index
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Print character
//=================================================================================================
void uart2_put_char(char c)
{
	while(U2STAbits.UTXBF == 1)	{}		// wait here if tx fifo full
	U2TXREG = (int)c &0x00FF;			// Tx reg is 16-bit long
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Get char from RX queue, IRQ RX system
//=================================================================================================
unsigned char uart2_get_char(void)
{
 	while(((unsigned char)(rx_buf_out_idx + 1)) == rx_buf_in_idx);   	// wait data if queue is empty 
  	return rx_buffer[++rx_buf_out_idx];             					// return with data
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Check if key pressed, data available from receive buffer
// Not pressed = 0, Pressed = number of characters
// IRQ based RX queue check
//=================================================================================================
unsigned char uart2_kbhit(void)
{
	// return with number of available characters
  	return(unsigned char)((rx_buf_in_idx  - (unsigned char)(rx_buf_out_idx + 1)));
	
}
//-------------------------------------------------------------------------------------------------




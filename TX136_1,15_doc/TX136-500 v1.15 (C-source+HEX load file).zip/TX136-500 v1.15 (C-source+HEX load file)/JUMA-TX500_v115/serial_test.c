//*************************************************************************************************
//
// JUMA-TX136/500 serial I/O test command set
//
// Juha Niinikoski, OH2NLT 06.07.2006
//
//
// Add QRSS and DFCW modes - F4GCB 08.2014
// Program structure modified to improve readability and maintenance - F4GCB 02-2015
//
//*************************************************************************************************

#include <stdio.h>
#include "ad9833.h"	
#include "juma-tx500.h"
#include "DataEEPROM.h"
#include "eeprom_tx500.h"
#include "lcd_tx500.h"
#include "gene_morse.h"
#include "timers_pwm.h"
#include "uart.h"


// External functions -----------------------------------------------------------------------------
extern void us_delay( unsigned int);			// delay routines
extern void ms_delay( unsigned int);

extern void init_adc12(void);					// ADC routines
extern int convert_adc12(unsigned int);


// External variables -----------------------------------------------------------------------------
extern const char ver[];						// system version
extern const char date[];						// version date


//=================================================================================================
// Dump the eeprom contents
//=================================================================================================
void dump_eeprom(void)
{
	int x;
	unsigned int y,w;

	printf("Dump EEPROM contents\n\r");	
	//for(x=0; x<256; x=x+2)								// byte address for EEPROM, but data is stored in words
	for (x=0; x<512; x=x+2)
	{
		y = ReadEE(EEPAGE, (x+EEDEF), (int*)&w, WORD);		// EEPROM Address 8 high bits, address + physical EEPROM start 16 low bits
		if ((x%16) == 0)
			printf("\n\r%5.4X", x);

			printf(" %4X", w);			
	}
	printf("\n\rLast success code = %X ", y);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Morse player test, 0 = repeat old buffer, 1 = ask new buffer
//=================================================================================================
void morse_test(int mode)
{
	char c;
	int idx;

	c = 0;
	idx = 0;

	printf("\n\rMorse Code player test, mode = %d\n\r",mode);

	if (mode !=0 )
	{
		printf("\n\rWrite message max %d char, terminate with CR\n\r", CW_BEACON_BUFFER_SIZE);

		while (c != 0x0D && idx < (CW_BEACON_BUFFER_SIZE))
		{
			c = uart1_get_checho();
			set_cw_beacon(&c, idx + 1, 0);
			idx++;
		}
	}

	morse_clear_display();						// clear LCD scroll buffer

	printf("\n\rPlay started\n\r");
	morse_play_string(cw_beacon_buffer);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Clear beacon string
//=================================================================================================
void clear_beacon_string(void)
{
	int x;

	for(x=0; x < CW_BEACON_BUFFER_SIZE; x++)
		set_cw_beacon(0, x + 1, 0);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Get beacon string from the terminal
//=================================================================================================
void get_beacon_string(void)
{
	char c;
	int idx;

	printf("\n\rWrite Beacon message max %d char, terminate with CR\n\r", CW_BEACON_BUFFER_SIZE);

	clear_beacon_string();						// clear, write nulls before new message
	idx = 0;

	while(c != 0x0D && idx < CW_BEACON_BUFFER_SIZE)
	{
		c = uart1_get_checho();
		set_cw_beacon(&c, idx + 1, 0);
		idx++;
	}

	morse_init_beacon(cw_beacon_buffer);		// init beacon logic, need this if beacon running
	printf("\n\r");	
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Send commands menu
//=================================================================================================
void print_menu(void)
{
	printf("\n\r--- Beacon control commands ---\n\r");
	printf("b Write Beacon message\n\r");
	printf("p Print Beacon message, no sound\n\r");
	printf("t Test play Beacon message\n\r");
	printf("s Start Beacon transmission\n\r");
	printf("q Stop Beacon transmission\n\r");

	printf("\n\r--- Test commands ---\n\r");
	printf("i system info\n\r");
	printf("e dump EEPROM\n\r");
	printf("c clear EEPROM factory reset counter\n\r");
	printf("a show all ADC values\n\r");
	printf("d DDS constants\n\r");
	printf("T play tone\n\r");
	printf("W write LCD test HEX\n\r");
	printf("w write LCD test ASCII\n\r");
	printf("B LCD bar graph test\n\r");
	printf("Z CPU error trap test\n\r");
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Serial test commands
//=================================================================================================
void serial_test(void)
{
	int x, z, temp;
	unsigned char c;

	if(uart1_kbhit())
	{
		c = uart1_get_char();
		switch(c)
		{
		//*****************************************************************************************
		// -----> Beacon commands
		//*****************************************************************************************
			case 'b':									// Get & save Save beacon string
				get_beacon_string();
				save_cw_beacon();
			break;

			case 'p':									// read beacon string from the EEPROM, print it, no sound
				printf("\n\r\n\rBeacon string from the EEPROM:");
				read_cw_beacon();
				printf("\n\r\n\r%s\n\r", cw_beacon_buffer);
			break;

			case 't':									// test play beacon string
				printf("\n\rTest Play Beacon string:\n\r");
			 	morse_play_string(cw_beacon_buffer);

				if(eeprom.defval.beacon_tx_on == 0)		// turn on only if beacon was off
				{
					set_pa_state(STATE_STBY, 1, 0, 0);	// force STBY
					set_cw_keyer(KEYER_BEACON, 1, 0, 0);// force keyer mode = Beacon
					morse_init_beacon(cw_beacon_buffer);// init beacon logic
					set_beacon_tx(1, 1);					// set Beacon on, one round
				}

			break;

			case 's':									// start Beacon TX
				printf("\n\rBeacon TX started\n\r");
				if(eeprom.defval.beacon_tx_on == 0)		// turn on only if beacon was off
				{
					set_pa_state(STATE_OPER, 1, 0, 0);	// force OPER
					set_cw_keyer(KEYER_BEACON, 1, 0, 0);// force keyer mode = Beacon
					morse_init_beacon(cw_beacon_buffer);// init beacon logic
					set_beacon_tx(-1, 1);				// set Beacon on, continous
				}
			break;

			case 'q':									// stop Beacon TX
				printf("\n\rBeacon TX stopped\n\r");
				set_beacon_tx(0, 1);					// turn it off
				stop_keyer();
			break;
		
		//*****************************************************************************************
		// -----> Info commands
		//*****************************************************************************************
			case 'I': case 'i':							// system info
				x = check_io_board_type();
				switch(x)
				{
					case TX500_TYPE:
						printf("\n\r\n\rJUMA-TX500 copyright OH7SV & OH2NLT\n\r");
					break;

					case TX136_TYPE:
						printf("\n\r\n\rJUMA-TX136 copyright OH7SV & OH2NLT\n\r");
					break;

					case UNKNOWN_TYPE: default:
						printf("\n\r\n\rUnknown Main Board type copyright OH7SV & OH2NLT\n\r");
					break;
				}
				printf("\n\rSoftware version ");
				printf(ver);
				printf(" / ");
				printf(date);
				printf(", copyright Juha Niinikoski OH2NLT\n\r");
			break;

			case 'a':									// Measure all ADC channels 9:14
				for(x=9; x<15; x++)
					printf("\n\rADC %i = %i", x, convert_adc12(x));
			break;

			case 'e':									// dump EEPROM
				dump_eeprom();
			break;

			case 'c':									// clear factory default reset counter
				printf("EEPROM reset counter cleared\n\r");
				temp = 0;
				EraseEE(EEPAGE, EE_FD_LOC, WORD);
				WriteEE(&temp, EEPAGE, EE_FD_LOC, WORD);
				dump_eeprom();
			break;

			case 'w':									// test LCD chgen, ASCII
				printf("LCD write ascii, ESC = end test, CR = clear LCD \n\r");
				lcd_clear();
				while(c != 0x1B)
				{
					while(uart1_kbhit() == 0);
						c = uart1_get_char();
					if(c == 0x0D)						// CR = clear screen
						lcd_clear();
					printf("char = %x\n\r", c);
					lcd_putch(c);
				}
			break;

			case 'W':									// test LCD chgen, HEX
				printf("LCD write hex, 0x1B = end test, 0x0D = clear LCD\n\r");
				lcd_clear();
				while(c != 0x1B)
				{
					c = uart1_get_2hex();
					if(c == 0x0D)						// CR = clear screen
						lcd_clear();
					printf(" = %c\n\r", c);
					lcd_putch(c);
				}
				break;

			case 'B':									// bar graph
				printf("bar graph test\n\r");
				for(;;)
				{
					for(x=0; x<96; x++)
					{
						lcd_clear();
						lcd_s_meter(x);
						ms_delay(50);
					}
					if(uart1_kbhit())
						break;
				}
			break;

			case 'Z':									// Trap / Error test
				printf("\n\rDiv by Zero");
				x = 0;
				temp = temp / x;						// generate error ==> trap
			break;

			case 'T':									// Buzer sound test, pitch = FCYMHz / tone(Hz) * 2
				printf("\n\rSound test, FCYMHz / tone(Hz) * 2, give pitch ");
				x = uart1_get_long();
				printf("\n\rSound test, give duration(ms) ");
				z = uart1_get_long();
				beep(x, z);
			break;

			case 'd':							// DDS test
				calc_hz_bit();					// calculate Hz/bit from ref osc actual value
				printf("\n\rRef osc %ld, hz_bit %f",cal.calval.ref_osc[board_type], (double)hz_bit);
			break;

#if 0
		//*****************************************************************************************
		// -----> Test commands
		//*****************************************************************************************
			case 'z':							// test
				printf("\n\rTest beacon primitives, give letter or number ");
				c = uart1_get_checho();
				morse_play_character(c);
				printf(", 0x%.2X\n\r", c);
			break;

			case 'o':							// set ref osc
				printf("\n\rSet Ref osc frequency > ");
				cal.calval.ref_osc[board_type] = uart1_get_long();
				calc_hz_bit();					// calculate Hz/bit from ref osc actual value
				printf("\n\rRef osc %ld, hz_bit %f",cal.calval.ref_osc[board_type], (double)hz_bit);
			break;

			case 'l':							// test, keyer timing
				printf("\n\rTest, keyer timing ");
				printf("\n\rbusy_counter   %ld", counter.busy);
				printf("\n\rcw_break_timer %d", counter.cw_break);
				printf("\n\rcw_break_time  %ld",set.cw_break);
				printf("\n\rcw_period      %ld",set.cw_period);
				printf("\n\rcw_active      %d",cw_active);
				printf("\n\r keyer_mode    %d", keyer_mode);
				printf("\n\rANT RLY %d, PTT %d, BUFFER %d, CW %d",ANT_RLY, PTT_OUT_1, BUFFER_ON, CW);
			break;
#endif
#if 0
		//*****************************************************************************************
		// Hardware debug commands
		//****************************************************************************************
			case 'S':							// Save beacon string
				save_beacon();
				printf("\n\rBeacon string saved to the EEPROM");
			break;

			case 'm':							// morse test, new input
				morse_test(1);
				save_beacon();
				printf("\n\rBeacon string saved to the EEPROM");
			break;

			case 'r':							// morse test, repeat
				morse_test(0);
			break;

			case 'D':							// DDS test
				printf("\n\rGive DDS control word value: ");
				l = uart1_get_long();

				printf("\n\rDDS set %ld", l);
				tune_ad9833(l);
				dds_test = l;
			break;

			case 'F':							// DDS test
				printf("\n\rGive DDS Freq: ");
				l = uart1_get_long();

				printf("\n\rFreq set %ld, DDS started", l);
				eeprom.defval.txfreq = l;
				calc_tword();
				tune_ad9833(tword);
			break;

			case 'T':							// Buzer sound test, pitch = FCYMHz / tone(Hz) * 2
				printf("\n\rTimer based Sound test, FCYMHz / tone(Hz) * 2, give pitch ");
				x = uart1_get_long();
				printf("\n\rSound test, give duration(ms) ");
				z = uart1_get_long();

				tone_on(x);
				ms_delay(z);
				tone_off();	
				ms_delay(z);

				beep(x, z);
			break;
#endif

			default:
				print_menu();					// if unknown command print mene
		}
	}
}
//-------------------------------------------------------------------------------------------------

//*************************************************************************************************
//
// JUMA-TX500/136 Transmitter Controller
// F4GCB 05.2015
//
// Microchip MPLAB + C30 compiler
// MCU dsPIC30F6014A
//
// Generates an OPERA message from call to a symbol/tone
//
// Acknowledgement :
// Portions of this OPERA code is derived from the work of EA5HVK
//
// Bug fixed: timer correction for waiting time to 0 - F4GCB 04.2016
// Some functions rewritten to save program memory space - F4GCB 10.2020
// Harmonization of timeslots control - F4GCB 10.2020
//
//*************************************************************************************************

#ifndef OPERA_H
#define OPERA_H

	extern void opera_init_beacon(const char *);				// Init OPERA beacon
	extern void opera_sym_irq(void);							// Beacon OPERA generator
	extern char *opera_get_code(char *);						// Return transmitted OPERA symbol value

#endif

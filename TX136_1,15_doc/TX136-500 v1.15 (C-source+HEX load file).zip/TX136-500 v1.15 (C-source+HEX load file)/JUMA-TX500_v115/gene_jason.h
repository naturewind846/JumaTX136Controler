//*************************************************************************************************
//
// JUMA-TX500/136 Transmitter Controller
// F4GCB 08.2015
//
// Microchip MPLAB + C30 compiler
// MCU dsPIC30F6014A
//
// Generates a JASON message from string
//
// Some functions rewritten to save program memory space - F4GCB 10.2020
// Harmonization of timeslots control - F4GCB 10.2020
//
//*************************************************************************************************


#ifndef JASON_H
#define JASON_H

	// Variables
	extern int jason_shift;							// TX JASON shift for DDS

	// Functions
	extern void jason_init_beacon(const char *);	// Init JASON beacon
	extern void jason_char_irq(void);				// JASON character generator 1ms IRQ
	extern char *jason_get_display(char *);			// Return transmitted JASON characters buffer for display

#endif

//*************************************************************************************************
//
// JUMA-TX1TX500/136 Transmitter Controller
// Juha Niinikoski, OH2NLT 06.07.2008
// F4GCB 01.2014
//
// Microchip MPLAB + C30 compiler
// MCU dsPIC30F6014A
//
// Set the datas stored in EEPROM - F4GCB 02-2015
// Add CW frame parameter - F4GCB 05.2015
// Add OPERA mode - F4GCB 05.2015
// Add JASON mode - F4GCB 08.2015
// Add CW identity option - F4GCB 04.2016
// Bug fixed: wrong default message in function set_cw_beacon - F4GCB 04.2016
// Bug fixed: add a character if the string is null dosn't work well - F4GCB 04.2016
// Add delay during scrolling of the character list to make the choice easier - F4GCB 04.2016
// Add SCRIPT mode - F4GCB 04.2016
// Limit EEPROM writing to preserve byte endurance - F4GCB 05.2016
// Add WSQ mode - F4GCB 06.2016
// PTT management modified - F4GCB 06.2016
// Add REMOTE mode - F4GCB 06.2016
// Improve JUMA software interface - F4GCB 06.2016
// Add JT9 mode - F4GCB 07.2016
// Alarm for unavailable call or grid - F4GCB 08.2016
// Add optional bi-band board control - F4GCB 11-2018
// Bug fixed: preamp 2O dB switching did not work - F4GCB 12-2018
// Some functions rewritten to save program memory space - F4GCB 10.2020
// Harmonization of timeslots control - F4GCB 10.2020
// Add FST4W mode - F4GCB 10.2020
// Mode change limited with the \g command of the CW beacon - F4GCB 12.2021
// Bug fixed : no TX FST4W shifts initialization, only when FST4W speed change, SW 1.12 - F4GCB 12.2020
// Improvement of script management - F4GCB 12.2021
// Add AFP interface via REMOTE mode, SW 1.13 - F4GCB 12.2021
//
//*************************************************************************************************

#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "DataEEPROM.h"
#include "eeprom_tx500.h"
#include "juma-tx500.h"	
#include "lcd_tx500.h"
#include "gene_fst4w.h"
#include "gene_jason.h"
#include "gene_jt9.h"
#include "gene_morse.h"
#include "gene_opera.h"
#include "gene_wspr.h"
#include "gene_wsq.h"
#include "serial_tx500.h"
#include "timers_pwm.h"
#include "uart.h"


// Gobal variables --------------------------------------------------------------------------------
eeprom_ eeprom;
cal_ cal;

char cw_beacon_buffer[CW_BEACON_BUFFER_SIZE + 1];		// CW beacon text buffer
char beacon_buffer[BEACON_BUFFER_SIZE + 1];				// beacon text buffer
char script_buffer[SCRIPT_BUFFER_SIZE + 1];				// script buffer

unsigned long tword;									// DDS tuning word
unsigned long tword_hi;									// DDS word for high TX frequency	
float hz_bit;											// DDS resolution
unsigned int fd_counter;								// counts how many times factory defaults have reloaded

int band = 0;											// optional bi-band board 0=TX136, 1=TX500
int msg_idx = 0;										// message index for keying
int cur_flg = 0;										// 0 for first display, 1 after
int disp_idx = 0;										// beacon message index for keying
int cw_beacon_flg = 0;									// CW beacon buffer to save if = 1
int beacon_flg = 0;										// beacon buffer to save if = 1
int script_flg = 0;										// script buffer to save if = 1

// Local variables --------------------------------------------------------------------------------
static int chr_idx = 0;									// character index for keying

static float jason_dds[6] = {							// JASON DDS shifts
	JASON_DDS/8,										// JASON slow
	JASON_DDS/8,										// JASON slow turbo
	JASON_DDS,											// JASON normal
	JASON_DDS,											// JASON normal turbo
	JASON_DDS*8,										// JASON fast
	JASON_DDS*8};										// JASON fast turbo
static long jason_period[6] = {							// JASON periods for each tone in ms
	(long)JASON_PERIOD*8,								// JASON slow
	(long)JASON_PERIOD*4,								// JASON slow turbo
	(long)JASON_PERIOD, 								// JASON normal
	(long)JASON_PERIOD/2, 								// JASON normal turbo
	(long)JASON_PERIOD/8,								// JASON fast
	(long)JASON_PERIOD/16};								// JASON fast turbo
 
static int opera_period[6] = {							// OPERA periods
	OPERA2_PERIOD,										// OPERA 2
	OPERA2_PERIOD*2,									// OPERA 4
	OPERA2_PERIOD*4,									// OPERA 8
	OPERA2_PERIOD*8,									// OPERA 16
	OPERA2_PERIOD*16,									// OPERA 32
	OPERA2_PERIOD*32};									// OPERA 65

static float wspr_dds[2] = {							// WPSR DDS shifts
	WSPR2_DDS,											// WPSR-2 DDS shift
	WSPR15_DDS};										// WPSR-2 DDS shift
static int wspr_period[2] = {							// WSPR periods for each symbol
	WSPR2_PERIOD,										// WSPR-2 period
	WSPR15_PERIOD};										// WSPR-15 period

static float fst4w_dds[4] = {							// FST4W DDS shifts
	FST4W_120_DDS,										// FST4W-120 DDS shift
	FST4W_300_DDS,										// FST4W-300 DDS shift
	FST4W_900_DDS,										// FST4W-900 DDS shift
	FST4W_1800_DDS};									// FST4W-1800 DDS shift
static int fst4w_period[4] = {							// FST4W periods for each symbol						
	FST4W_120_PERIOD,									// FST4W-120 period
	FST4W_300_PERIOD, 									// FST4W-300 period
	FST4W_900_PERIOD,									// FST4W-900 period
	FST4W_1800_PERIOD};									// FST4W-1800 period

static float jt9_dds[5] = {								// JT9 DDS shifts
	JT9_1_DDS,											// JT9-1 DDS shift
	JT9_2_DDS,											// JT9-2 DDS shift
	JT9_5_DDS,											// JT9-5 DDS shift
	JT9_10_DDS,											// JT9-10 DDS shift
	JT9_30_DDS};										// JT9-30 DDS shift
static int jt9_period[5] = {							// JT9 periods for each symbol						
	JT9_1_PERIOD,										// JT9-1 period
	JT9_2_PERIOD, 										// JT9-2 period
	JT9_5_PERIOD,										// JT9-5 period
	JT9_10_PERIOD,										// JT9-10 period
	JT9_30_PERIOD};										// JT9-30 period
static int opera_ts[6] = {
	OPERA2_TS,											// OPERA 2 timeslot period in s
	OPERA4_TS,											// OPERA 4 timeslot period in s
	OPERA8_TS,											// OPERA 8 timeslot period in s
	OPERA16_TS,											// OPERA 16 timeslot period in s
	OPERA32_TS,											// OPERA 32 timeslot period in s 
	OPERA65_TS};										// OPERA 65 timeslot period in s
static int wspr_ts[2] = {
	WSPR2_TS,											// WSPR-2 timeslot period in s
	WSPR15_TS};											// WSPR-15 timeslot period in s
static int fst4w_ts[4] = {
	FST4W_120_TS, 										// FST4W-120 timeslot period in s
	FST4W_300_TS, 										// FST4W-300 timeslot period in s
	FST4W_900_TS,	 									// FST4W-900 timeslot period in s
	FST4W_1800_TS}; 									// FST4W-1800 timeslot period in s
static int jt9_ts[5] = {
	JT9_1_TS, 											// JT9-1 timeslot period in s
	JT9_2_TS, 											// JT9-2 timeslot period in s
	JT9_5_TS,	 										// JT9-5 timeslot period in s
	JT9_10_TS, 											// JT9-10 timeslot period in s
	JT9_30_TS};											// JT9-30 timeslot period in s

// External functions -----------------------------------------------------------------------------
extern void ms_delay( unsigned int);
extern char *get_gps_grid6(char *);						// Get GPS grid 6		


//*************************************************************************************************
// EEPROM storage functions
//*************************************************************************************************

//=================================================================================================
// Save defaults in EEPROM
//=================================================================================================
void save_defaults(void)
{
	int x, y;

	eeprom.defval.d_csum = 0;
	for(x=0; x<(sizeof(struct defval)/2); x++)
	{
		if(x < ((sizeof(struct defval)/2) - 1))
			// calculate mod 0xFFFF checksum
			eeprom.defval.d_csum = eeprom.defval.d_csum + eeprom.storage[x];
		else
			// last round, invert checksum
			eeprom.defval.d_csum = 0 - eeprom.defval.d_csum;

 		y = EraseEE(EEPAGE, (2*x+EEDEF), WORD);
		// EEPROM Address 8 high bits, address + physical EEPROM start 16 low bits
		y = WriteEE((int*)&(eeprom.storage[x]), EEPAGE, (2*x+EEDEF), WORD);
	}

	// conditional print only if RS232 = Test
 	if(eeprom.defval.serial_mode == 1)
		printf("\n\rWords = %d, Sucess = %d, Checksum = %X", x, y, eeprom.defval.d_csum);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Read defaults in EEPROM
//=================================================================================================
unsigned int read_defaults(void)
{
	int x, y;
	unsigned int csum;

	csum = 0;
	for(x=0; x<(sizeof(struct defval)/2); x++)
	{
		// EEPROM Address 8 high bits, address + physical EEPROM start 16 low bits
		y = ReadEE(EEPAGE, (2*x+EEDEF), (int*)&(eeprom.storage[x]), WORD);
		// add error checking ?  y = success code
		csum = csum + eeprom.storage[x];
	}

	// read factory defaults reset counter
	ReadEE(EEPAGE, EE_FD_LOC, (int*)&fd_counter, WORD);

	return csum;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Save calibration values in EEPROM
//=================================================================================================
void save_calval(void)
{
	int x, y;

	cal.calval.c_csum = 0;
	for(x=0; x<(sizeof(struct calval)/2); x++)
	{
		if(x < ((sizeof(struct calval)/2) - 1))
			// calculate mod 0xFFFF checksum
			cal.calval.c_csum = cal.calval.c_csum + cal.ee[x];
		else
			cal.calval.c_csum = 0 - cal.calval.c_csum;

		y = EraseEE(EEPAGE, (2*x+EECAL), WORD);
		// EEPROM Address 8 high bits, address + physical EEPROM start 16 low bits
		y = WriteEE((int*)&(cal.ee[x]), EEPAGE, (2*x+EECAL), WORD);
	}

	// conditional print only if RS232 = Test
 	if(eeprom.defval.serial_mode == 1)
		printf("\n\rWords = %d, Success = %d, Checksum = %X", x, y, cal.calval.c_csum);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Read calibration values
//=================================================================================================
unsigned int read_calval(void)
{
	int x, y;
	unsigned int csum;

	csum = 0;
	// EEPROM Address 8 high bits, address + physical EEPROM start 16 low bits
	for(x=0; x<(sizeof(struct calval)/2); x++)
	{
		y = ReadEE(EEPAGE, (2*x+EECAL), (int*)&(cal.ee[x]), WORD);
		csum = csum + cal.ee[x];
	}

	return csum;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Save CW beacon string, one byte / address
//=================================================================================================
void save_cw_beacon(void)
{
	int x, y, temp;

	for(x=0; x<(sizeof cw_beacon_buffer); x++)
	{
		temp = (char)cw_beacon_buffer[x];
		y = EraseEE(EEPAGE, (2*x+EECWBEACON), WORD);
		// EEPROM Address 8 high bits, address + physical EEPROM start 16 low bits
		y = WriteEE(&temp, EEPAGE, (2*x+EECWBEACON), WORD);
	}
	cw_beacon_flg = 0;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Read CW beacon string, one byte / address
//=================================================================================================
void read_cw_beacon(void)
{
	int x, y, temp;

	for(x=0; x<(sizeof cw_beacon_buffer); x++)
	{
		// EEPROM Address 8 high bits, address + physical EEPROM start 16 low bits
		y = ReadEE(EEPAGE, (2*x+EECWBEACON), &temp, WORD);
		cw_beacon_buffer[x] = (char)temp;
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Save beacon string, one byte / address
//=================================================================================================
void save_beacon(void)
{
	int x, y, temp;

	for(x=0; x<(sizeof beacon_buffer); x++)
	{
		temp = (char)beacon_buffer[x];
		y = EraseEE(EEPAGE, (2*x+EEBEACON), WORD);
		// EEPROM Address 8 high bits, address + physical EEPROM start 16 low bits
		y = WriteEE(&temp, EEPAGE, (2*x+EEBEACON), WORD);
	}
	beacon_flg = 0;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Read beacon string, one byte / address
//=================================================================================================
void read_beacon(void)
{
	int x, y, temp;

	for(x=0; x<(sizeof beacon_buffer); x++)
	{
		// EEPROM Address 8 high bits, address + physical EEPROM start 16 low bits
		y = ReadEE(EEPAGE, (2*x+EEBEACON), &temp, WORD);
		beacon_buffer[x] = (char)temp;
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Save script, one byte / address
//=================================================================================================
void save_script(void)
{
	int x, y, temp;

	for(x=0; x<(sizeof script_buffer); x++)
	{
		temp = (char)script_buffer[x];
		y = EraseEE(EEPAGE, (2*x+EESCRIPT), WORD);
		// EEPROM Address 8 high bits, address + physical EEPROM start 16 low bits
		y = WriteEE(&temp, EEPAGE, (2*x+EESCRIPT), WORD);
	}
	script_flg = 0;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Read script, one byte / address
//=================================================================================================
void read_script(void)
{
	int x, y, temp;

	for(x=0; x<(sizeof script_buffer); x++)
	{
		// EEPROM Address 8 high bits, address + physical EEPROM start 16 low bits
		y = ReadEE(EEPAGE, (2*x+EESCRIPT), &temp, WORD);
		script_buffer[x] = (char)temp;
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set factory defaults for EEPROM storage
//=================================================================================================
void set_factory_defaults(void)
{
	int x;

	eeprom.defval.txfreq[0] = U_DEFAULT_TX_FREQ;		// set default TX frequency
	eeprom.defval.txfreq[1] = TX500_DEFAULT_TX_FREQ;
	eeprom.defval.txfreq[2] = TX136_DEFAULT_TX_FREQ;

	eeprom.defval.rfpwr = 0;							// RF power level
	eeprom.defval.mode = MODE_CW;						// mode type: CW, QRSS, DFCW, JASON, OPERA, WSPR, FST4W, JT9, SCRIPT, REMOTE
	eeprom.defval.cwid = 0;								// CW identiy 0=off, 1=12 wpm, 2=24 wpm
	eeprom.defval.preamp = 0;							// preamp setting, off, 10dB, 20dB
	eeprom.defval.converter = 0;						// 3,5MHz up converter off, on

	eeprom.defval.cw_speed = DEFAULT_CW_SPEED;			// CW speed (wpm * 10)
	eeprom.defval.cw_frame = DEFAULT_CW_FRAME;			// CW frame 0 (one play), 1 to 5 (one TX timeslot / n timeslots)
	eeprom.defval.cw_dot_time = DEFAULT_DOT_TIME;		// QRSS and DFCW dot time (s)
	eeprom.defval.cw_shift = DEFAULT_CW_SHIFT;			// DFCW shift
	eeprom.defval.cw_sidetone = CW_SIDETONE;			// set default side tone
	eeprom.defval.cw_keyer = KEYER;						// set default keyer type, , 0=dot pri, 1=iambic A, 2=iambic B, 3=straight, 4=beacon

	eeprom.defval.jason_speed = DEFAULT_JASON_SPEED;	// JASON speed 0=fast turbo, 1=fast, 2=normal turbo, 3=normal, 4=slow turbo, 5=slow
	eeprom.defval.jason_frame = MIN_MODE_FRAME;			// JASON frame 0 (one play), 1 to 5 (one TX timeslot / n timeslots)

	eeprom.defval.opera_speed = MIN_OPERA_SPEED;		// OPERA speed OP2=0 to OP65=5
	eeprom.defval.opera_frame = MIN_MODE_FRAME;			// OPERA frame 0 (one play), 1 to 5 (one TX timeslot / n timeslots)

	eeprom.defval.wsq_frame = MIN_MODE_FRAME;			// WSQ frame 0 (one play), 1 to 5 (one TX timeslot / n timeslots)

	eeprom.defval.wspr_speed = MIN_WSPR_SPEED;			// WSPR speed WSPR-2=0 or WSPR-15=1
	eeprom.defval.wspr_frame = MIN_MODE_FRAME;			// WSPR frame 0 (one play), 1 to 5 (one TX timeslot / n timeslots)
	eeprom.defval.wspr_ndbm = 30;						// WSPR power in dBm for max power, steps (steps {0,3,7,10,13,...,60)

	eeprom.defval.fst4w_speed = MIN_FST4W_SPEED;		// FST4W speed FST4W-120=0, FST4W-300=1, FST4W-900=2, FST4W-1800=3
	eeprom.defval.fst4w_frame = MIN_FST4W_FRAME;		// FST4W frame 0 (one play), 1 to 5 (one TX timeslot / n timeslots)

	eeprom.defval.jt9_speed = MIN_JT9_SPEED;			// JT9 speed 0=JT9-1, 1=JT9-2, 2=JT9-5, 3=JT9-10, 4=JT9-30
	eeprom.defval.jt9_frame = MIN_MODE_FRAME;			// JT9 frame 0 (one play), 1 to 5 (one TX timeslot / n timeslots)

	eeprom.defval.script_frame = MIN_SCRIPT_FRAME;		// script frame 0 (one play), 1 to 5 (one TX timeslot / n timeslots)

	eeprom.defval.rem_soft = MIN_REM_SOFT;				// software for serial remote (0=JASON normal, 1= JASON fast, 2=WSQ2, 3=AFP)

	eeprom.defval.cwid = 0;								// CW identiy 0=off, 1=12 wpm, 2=24 wpm
	strcpy(eeprom.defval.call, "N0CAL");				// callsign
	strcpy(eeprom.defval.grid, "JJ00AA");				// locator
	eeprom.defval.gps = 0;								// GPS locator priority 0=off, 1=on

	eeprom.defval.contrast = DEFAULT_CONTRAST;
	eeprom.defval.back_light = DEFAULT_BL;

	eeprom.defval.serial_mode = SERIAL_MODE;			// serial interface operating mode 0=TX500, 1=Terminal, 2=GPS, 3=AFP
	eeprom.defval.br = DEFAULT_BAUD_RATE;				// initial baud rate = 9600

	eeprom.defval.swr_limit[0] = SWR_LIMIT_MIN;			// SWR alarm trip points
	eeprom.defval.swr_limit[1] = SWR_LIMIT_LOW;
	eeprom.defval.swr_limit[2] = SWR_LIMIT_HI;
	eeprom.defval.swr_limit[3] = SWR_LIMIT_MAX;

	eeprom.defval.pa_state = STATE_STBY;				// Amplifier state, 0 = standby, 1 = oper, 2 = tune
	eeprom.defval.mox = PTT_AUTO;						// auto PTT
	eeprom.defval.spare_io = 0;							// spare digital I/O state or optional bi-band board 0=TX136, 1=TX500

	eeprom.defval.beacon_tx_on = 0;						// beacon transmit on, 0=off, -1=continuous, positive number=rounds
	eeprom.defval.script_on = 0;						// script on, 0=off, -1=continuous, positive number=rounds

	// default calibration constant values
	cal.calval.ref_osc[0] = REF_OSC_U;
	cal.calval.ref_osc[1] = REF_OSC_6;					// TX500
	cal.calval.ref_osc[2] = REF_OSC_20;					// TX136
	cal.calval.ref_osc[3] = REF_OSC_6;					// TX500 with bi-band board
	cal.calval.ref_osc[4] = REF_OSC_20;					// TX136 with bi-band board

	cal.calval.id_mult = ID_MULT;
	cal.calval.batt_mult = BATT_MULT;
	cal.calval.rev_pwr_mult = REV_PWR_MULT;
	cal.calval.fwd_pwr_mult = FWD_PWR_MULT;
	cal.calval.beep_len = DEFAULT_BEEP_LEN;
	cal.calval.cw_break_time = CW_BREAK_TIME;			// default CW break timer value
	cal.calval.ms_offset = MS_OFFSET;					// offset for WSPR timer
	cal.calval.power_q4 = 0;							// jumper Q4 value (off)

	// cw_beacon message
	for(x=0; x < CW_BEACON_BUFFER_SIZE; x++)			// first write nulls
		cw_beacon_buffer[x] = 0;
	//sprintf(cw_beacon_buffer, "vvv vvv de JUMA Beacon # \r");
	sprintf(cw_beacon_buffer, "TEST DE JUMA BEACON ");
	save_cw_beacon();

	// beacon message
	for(x=0; x < BEACON_BUFFER_SIZE; x++)				// first write nulls
		beacon_buffer[x] = 0;
	sprintf(beacon_buffer, "TEST ");
	save_beacon();

	// script
	for(x=0; x < SCRIPT_BUFFER_SIZE; x++)				// first write nulls
		script_buffer[x] = 0;
	sprintf(script_buffer, "=G1=D1=B1=SD10");
	save_script();

	// increment factory default reset counter
	ReadEE(EEPAGE, EE_FD_LOC, (int*)&fd_counter, WORD);
	fd_counter++;

	// save factory defaults reset counter
	EraseEE(EEPAGE, EE_FD_LOC, WORD);
	WriteEE((int*)&fd_counter, EEPAGE, EE_FD_LOC, WORD);
}
//-------------------------------------------------------------------------------------------------


//*************************************************************************************************
// Utility functions
//*************************************************************************************************

//=================================================================================================
// Set generic value (eeprom.defval.xxx)
//=================================================================================================
void set_value(int *value, int new_value, int new_val)
{
	// set value
	if (new_val)
		*value = new_value;
	else
		*value += new_value;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Round the value
//=================================================================================================
int round_val(float x)
{
	if (x - floorf(x) > 0.5)
		return floorf(x) + 1;
	else
		return floorf(x);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Keep within loop for setting configuration values
//=================================================================================================
void keep_within_loop(int *value, int min, int max)
{
	if(*value < min)
		*value = max;
	if(*value > max)
		*value = min;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Keep within limits for setting configuration values
//=================================================================================================
int keep_within_lim(int *value, int min, int max)
{
	if(*value < min)
	{
		*value = min;
		return 0;
	}
	if(*value > max)
	{
		*value = max;
		return 0;
	}

	return 1;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Keep within limits for setting configuration long values
//=================================================================================================
int keep_within_lim_long(long *value, long min, long max)
{
	if(*value < min)
	{
		*value = min;
		return 0;
	}
	if(*value > max)
	{
		*value = max;
		return 0;
	}

	return 1;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Up/down beep
//=================================================================================================
void beep_up_down(int *value)
{
	const int tone_up = TONE_D, tone_down = TONE_C;

	if (*value > 0)
		beep(tone_up, cal.calval.beep_len);
	else if (*value < 0)
		beep(tone_down, cal.calval.beep_len);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Add character into message
//=================================================================================================
int add_char(char *string, int idx, int len, char *insert)
{
	int i;

	if (strlen(string) == 0)
	{
		string[idx] = *insert;
		return 1;
	}
	if (strlen(string) < len)
	{	
		for (i=strlen(string)+1; i>idx+1; i--)
			string[i] = string[i-1];
		string[idx+1] = *insert;
		return 1;
	}

	return 0;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Delete character into message
//=================================================================================================
int del_char(char *string, int idx)
{
	int i;

	if (strlen(string) > 0)
	{
		for (i=idx; i<strlen(string); i++)
			string[i] = string[i+1];
		return 1;
	}

	return 0;
}
//-------------------------------------------------------------------------------------------------


//*************************************************************************************************
// Calculate and define news values in function eeprom values
//*************************************************************************************************

//=================================================================================================
// Calculate Hz/bit from ref osc actual value
//=================================================================================================
void calc_hz_bit(void)
{
	hz_bit = cal.calval.ref_osc[board_type] / DDS_RESOLUTION;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Calculate DDS tuning word
//=================================================================================================
void calc_tword(void)
{
	tword = ((float)(2 * eeprom.defval.txfreq[band])) / hz_bit;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Calculate DDS word for high TX frequency
//=================================================================================================
void calc_tword_hi(void)
{
	const long hi_tx_freq[3] = {U_HI_TX_FREQ, TX500_HI_TX_FREQ, TX136_HI_TX_FREQ};

	tword_hi = ((float)(2 * hi_tx_freq[band])) / hz_bit;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Define frequency according to the band (useful for optional bi-band board)
//=================================================================================================
void freq_band(void)
{	
	switch (board_type)
	{
		case TX500_TYPE:
		case TX136_TYPE:
			band = board_type;
		break;

		case TX500_136_TYPE:
		case TX136_500_TYPE:
			if (eeprom.defval.spare_io == BAND_136)
				band = TX136_TYPE;
			else
				band = TX500_TYPE;
		break;
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Calculate time value for the keyer logic and timeslot period in s
//=================================================================================================
void calc_cw_period(void)
{
	// calculate & set period(ms) for the irq system
	switch (eeprom.defval.mode)
	{
		case MODE_CW:
			set.cw_period = morse_get_period(eeprom.defval.cw_speed, 0);		// unit in wpm
			set.ts = 0;															// no timeslot
		break;

		case MODE_QRSS:
		case MODE_DFCW:
			set.cw_period = morse_get_period(eeprom.defval.cw_dot_time, 1);		// unit in seconds
			set.ts = 0;															// no timeslot
		break;

		case MODE_JASON:
			set.cw_period = jason_period[eeprom.defval.jason_speed];
			set.ts = 0;															// no timeslot
		break;

		case MODE_WSQ:
			set.cw_period = WSQ_PERIOD;
			set.ts = 0;															// no timeslot
		break;

		case MODE_OPERA:
			set.cw_period = opera_period[eeprom.defval.opera_speed];
			set.ts = opera_ts[eeprom.defval.opera_speed];
		break;

		case MODE_WSPR:
			set.cw_period = wspr_period[eeprom.defval.wspr_speed];
			set.ts = wspr_ts[eeprom.defval.wspr_speed];
		break;

		case MODE_FST4W:
			set.cw_period = fst4w_period[eeprom.defval.fst4w_speed];
			set.ts = fst4w_ts[eeprom.defval.fst4w_speed];
		break;

		case MODE_JT9:
			set.cw_period = jt9_period[eeprom.defval.jt9_speed];
			set.ts = jt9_ts[eeprom.defval.jt9_speed];
		break;
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Calculate TX MORSE shift for DDS
//=================================================================================================
void calc_morse_shift(void)
{
	morse_shift = round_val(0.2 * eeprom.defval.cw_shift / hz_bit);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Calculate the TX JASON shift for DDS
//=================================================================================================
void calc_jason_shift(int speed)
{
	jason_shift = round_val(jason_dds[speed] / hz_bit);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Calculate the TX WSQ shift for DDS
//=================================================================================================
void calc_wsq_shift(void)
{
	wsq_shift = round_val(WSQ_DDS / hz_bit);	
}
//------------------------------------------------------------------------------------------------


//=================================================================================================
// Calculate the TX WSPR shifts for DDS
//=================================================================================================
void calc_wspr_shifts(void)
{
	int i;

	for (i=0; i<4; i++)
		wspr_shift[i] = round_val(i * wspr_dds[eeprom.defval.wspr_speed] / hz_bit);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Calculate the TX FST4W shifts for DDS
//=================================================================================================
void calc_fst4w_shifts(void)
{
	int i;

	for (i=0; i<4; i++)
		fst4w_shift[i] = round_val(i * fst4w_dds[eeprom.defval.fst4w_speed] / hz_bit);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Calculate the TX JT9 shifts for DDS
//=================================================================================================
void calc_jt9_shifts(void)
{
	int i;

	for (i=0; i<9; i++)
		jt9_shift[i] = round_val(i * jt9_dds[eeprom.defval.jt9_speed] / hz_bit);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Calculate sideone
//=================================================================================================
void calc_sidetone(void)
{
	set.sidetone = 	FCY / (eeprom.defval.cw_sidetone * 2);
}
//-------------------------------------------------------------------------------------------------


//*************************************************************************************************
// System configuration functions
//*************************************************************************************************

//=================================================================================================
// Set frequency (eeprom.defval.txfreq)
//=================================================================================================
void set_frequency(long value, int new_val, int beep_on, int display_on)
{
	const int tone_ok = TONE_D, tone_nok = TONE_A;
	const char freq[] = {"%.6ld"};
	const long low_tx_freq[3] = {U_LOW_TX_FREQ, TX500_LOW_TX_FREQ, TX136_LOW_TX_FREQ};
	const long hi_tx_freq[3] = {U_HI_TX_FREQ, TX500_HI_TX_FREQ, TX136_HI_TX_FREQ};
	char buffer[7];

	// set frequency value
	if (new_val)
		eeprom.defval.txfreq[band] = value;
	else
		eeprom.defval.txfreq[band] += value;

	if ((value || new_val)  || !(value + new_val + beep_on + display_on))
	{
		// check the value
		keep_within_lim_long(&eeprom.defval.txfreq[band], low_tx_freq[band], hi_tx_freq[band]);

		// calculate new DDS set value
		calc_tword();

		// ok beep or under/over beep
		if (beep_on)
		{
			if (eeprom.defval.txfreq[band] == low_tx_freq[band] || eeprom.defval.txfreq[band] == hi_tx_freq[band])
				beep(tone_nok, cal.calval.beep_len);
			else
				beep(tone_ok, cal.calval.beep_len);
		}
	}

	// display frequency
	if (display_on)
	{
		sprintf(buffer, freq, eeprom.defval.txfreq[band]);
		lcd_display_at(2, 11, buffer);
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set TX power (eeprom.defval.rfpwr)
//=================================================================================================
void set_tx_power(int value, int new_val, int beep_on, int display_on)
{
	const int tone[4] = {TONE_A, TONE_B, TONE_C, TONE_D};
	const char power[4][9] = {
		{"PWR MIN"},
		{"PWR LOW"},
		{"PWR  HI"},
		{"PWR MAX"}};

	set_value(&eeprom.defval.rfpwr, value, new_val);
	if ((value || new_val)  || !(value + new_val + beep_on + display_on))
	{
		// check TX power value
		keep_within_loop(&eeprom.defval.rfpwr, 0, MAX_RFPWR);

		// set RF power relays
		PWR0 = eeprom.defval.rfpwr & 0x01;
		PWR1 = (eeprom.defval.rfpwr & 0x02) >> 1;

		// sound different tone for each power level
		if (beep_on)
			beep(tone[eeprom.defval.rfpwr], cal.calval.beep_len);
	}

	// display TX power value
	if (display_on)
		lcd_display_at(1, 10, power[eeprom.defval.rfpwr]);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set operating mode (eeprom.defval.pa_state)
//=================================================================================================
void set_pa_state(int value, int new_val, int beep_on, int display_on)
{
	const int tone[3] = {TONE_C, TONE_D, TONE_B};
	const char op_mode[3][7] = {
		{"STBY"},
		{"OPER"},
		{"TUNE"}};
	const char op_mode_tx[] = {" TX "};
	const char op_mode_wait[] = {"WAIT"};

	set_value(&eeprom.defval.pa_state, value, new_val);
	if (value || new_val)
	{
		// check operating mode value
		keep_within_loop(&eeprom.defval.pa_state, 0, 2);

		// sound different tone for each operating state
		if (beep_on)
			beep(tone[eeprom.defval.pa_state], cal.calval.beep_len);

		// AFP remote
		if (eeprom.defval.mode == MODE_REM && eeprom.defval.rem_soft == REM_AFP && eeprom.defval.pa_state == STATE_OPER)
		{
			uart1_set_baud(7);					// force to 115200 baud
			uart1_clear();
			afp_ptt = 0;
			clear_buffer();
			afp_serial = 1;						// IRQ 1ms to read the buffer
		}
		else if (afp_serial == 1)
		{
			afp_serial = 0;
			afp_ptt = 0;
			uart1_init();						// wake up again because sometimes double CR required for a command
			uart1_set_baud(eeprom.defval.br);	// return to baud rate selected
		}	
	}

	// display operating mode
	if (display_on)
	{
		if (key && !CW && eeprom.defval.mode == MODE_REM)
			lcd_display_at(2, 6, op_mode[eeprom.defval.pa_state]);
		if (key)
			lcd_display_at(2, 6, op_mode_tx);
		else if ((eeprom.defval.pa_state == STATE_OPER && eeprom.defval.beacon_tx_on) || counter.script)
			lcd_display_at(2, 6, op_mode_wait);
		else
			lcd_display_at(2, 6, op_mode[eeprom.defval.pa_state]);
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set RF preamp state (eeprom.defval.preamp)
//=================================================================================================
void set_preamp(int value, int new_val, int beep_on, int display_on)
{
	const char line1[] = {"Pre Amplifier   "};
	const char line2[3][17] = {
		{"Select = OFF    "},
		{"Select = 10dB   "},
		{"Select = 20dB   "}};

	set_value(&eeprom.defval.preamp, value, new_val);
	if ((value || new_val)  || !(value + new_val + beep_on + display_on))
	{
		// check value and sound tone for each RX preamp state
		if (keep_within_lim(&eeprom.defval.preamp, 0, 2) && beep_on)
			beep_up_down(&value);

		// set RF preamp relays
		if (eeprom.defval.preamp)
			PREAMP_ON = 1;
		else 
			PREAMP_ON = 0;
		PREAMP_GAIN = (eeprom.defval.preamp & 0x02) >> 1;
	}

	// display RX preamp state
	if (display_on)
		lcd_display_all(line1, line2[eeprom.defval.preamp]);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set RX converter state (eeprom.defval.converter)
//=================================================================================================
void set_converter(int value, int new_val, int beep_on, int display_on)
{
	const char line1[5][17] = {
		{"???MHz Converter"},
		{"3.5MHz Converter"},
		{"10MHz Converter "},
		{"3.5MHz Converter"},
		{"10MHz Converter "}};
	const char line2[2][17] = {
		{"Select = OFF    "},
		{"Select = ON     "}};

	set_value(&eeprom.defval.converter, value, new_val);
	if ((value || new_val)  || !(value + new_val + beep_on + display_on))
	{
		// check value and sound tone for each RX converter state
		if (keep_within_lim(&eeprom.defval.converter, 0, 1) && beep_on)
			beep_up_down(&value);

		// set RX converter relay
		MIXER_CLK_ON = eeprom.defval.converter;
	}

	// display RX converter state
	if (display_on)
		lcd_display_all(line1[board_type], line2[eeprom.defval.converter]);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set mode (eeprom.defval.mode)
//=================================================================================================
int set_mode(int value, int new_val, int beep_on, int display_on)
{
	int mod = 0, mode_max = MODE_REM;
	const char line1[] = {"TX Mode         "};
	const char line2[11][17] = {
		{"Mode = CW       "},
		{"Mode = QRSS     "},
		{"Mode = DFCW     "},
		{"Mode = JASON    "},
		{"Mode = WSQ2     "},
		{"Mode = OPERA    "},
		{"Mode = WSPR     "},
		{"Mode = FST4W    "},
		{"Mode = JT9      "},
		{"Mode = SCRIPT   "},
		{"Mode = REMOTE   "}};

	set_value(&eeprom.defval.mode, value, new_val);
	if (value || new_val)
	{
		// mode change limited if command with CW beacon text
		if (new_val == 2)
			mode_max = MODE_DFCW;

		// mode change limited if script on
		if (eeprom.defval.script_on)
			mode_max = MODE_JT9;

		// check value and sound tone for each mode state
		if (keep_within_lim(&eeprom.defval.mode, MODE_CW, mode_max) && beep_on)
			beep_up_down(&value);
		
		// calculate new values for the keyer logic
		calc_cw_period();

		// mode is modified
		mod = 1;			
	}

	// display mode
	if (display_on)
		lcd_display_all(line1, line2[eeprom.defval.mode]);

	return mod;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set band (eeprom.defval.spare_io)
//=================================================================================================
void set_band(int value, int new_val, int beep_on, int display_on)
{
	const char line1[] = {"TX Band         "};
	const char line2[2][17] = {
		{"Band = 2200 m   "},
		{"Band = 630 m    "}};

	set_value(&eeprom.defval.spare_io, value, new_val);
	if (value || new_val)
	{
		// check value and sound tone for each mode state
		if (keep_within_lim(&eeprom.defval.spare_io, BAND_136, BAND_500) && beep_on)
			beep_up_down(&value);
		
		// frequency is modified
		freq_band();

		// calculate new DDS set value
		calc_tword();

		// calculate new DDS high TX frequency
		calc_tword_hi();			

		// set SPARE relay
		SPARE = eeprom.defval.spare_io;
	}

	// display mode
	if (display_on)
		lcd_display_all(line1, line2[eeprom.defval.spare_io]);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set mode frame (eeprom.defval.xxx_frame)
//=================================================================================================
void set_frame(int mode, int value, int new_val, int beep_on, int display_on)
{
	const char frame[6][10] = {
		{"TX x1    "},
		{"TX 1/1   "},
		{"TX 1/2   "},
		{"TX 1/3   "},
		{"TX 1/4   "},
		{"TX 1/5   "}};
	int *mode_frame[10] = {
		&eeprom.defval.cw_frame,
		&eeprom.defval.cw_frame,
		&eeprom.defval.cw_frame,
		&eeprom.defval.jason_frame,
		&eeprom.defval.wsq_frame,
		&eeprom.defval.opera_frame,
		&eeprom.defval.wspr_frame,
		&eeprom.defval.fst4w_frame,
		&eeprom.defval.jt9_frame,
		&eeprom.defval.script_frame};

	set_value(mode_frame[mode], value, new_val);
	if (value || new_val)
		// check the value and sound tone for each OPERA frame
		if (keep_within_lim(mode_frame[mode], MIN_MODE_FRAME, MAX_MODE_FRAME) && beep_on)
			beep_up_down(&value);

	// display  frame
	if (display_on)
		lcd_display_line(1, frame[*mode_frame[mode]]);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set CW speed (eeprom.defval.cw_speed)
//=================================================================================================
void set_cw_speed(int value, int new_val, int beep_on, int display_on)
{
	const char speed_beacon[] = {"Spd %.2d   "};
	const char speed_keyer[] = {"CW%.2d "};
	char buffer[10];

	set_value(&eeprom.defval.cw_speed, value, new_val);
	if (value || new_val)
	{
		// check the value and sound tone for each CW speed value
		if (keep_within_lim(&eeprom.defval.cw_speed, MIN_CW_SPEED, MAX_CW_SPEED) && beep_on)
			beep_up_down(&value);
	
		// calculate new values for the keyer logic
		calc_cw_period();
	}

	// display CW sspeed value
	if (display_on)
	{
		// beacon mode
		if (eeprom.defval.cw_keyer == KEYER_BEACON)
		{
			sprintf(buffer, speed_beacon, eeprom.defval.cw_speed);
			lcd_display_line(1, buffer);
		}

		// keyer modes
		else
		{
			sprintf(buffer, speed_keyer, eeprom.defval.cw_speed);
			lcd_display_line(2, buffer);
		}
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set dot time for QRSS and DFCW (eeprom.defval.cw_dot_time)
//=================================================================================================
void set_dot_time(int value, int new_val, int beep_on, int display_on)
{
	const char dot_time[] = {"Dot %.3d  "};
	char buffer[10];

	set_value(&eeprom.defval.cw_dot_time, value, new_val);
	if (value || new_val)
	{
		// check the value and sound tone for each dot time speed value
		if (keep_within_lim(&eeprom.defval.cw_dot_time, MIN_DOT_TIME, MAX_DOT_TIME) && beep_on)
			beep_up_down(&value);

		// calculate new values for the keyer logic
		calc_cw_period();
	}

	// display dot time value
	if (display_on)
	{
		sprintf(buffer, dot_time, eeprom.defval.cw_dot_time);
		lcd_display_line(1, buffer);
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set CW shift for DFCW (eeprom.defval.cw_shift)
//=================================================================================================
void set_cw_shift(int value, int new_val, int beep_on, int display_on)
{
	const char shift[]= {"Fsk %.1f  "};
	char buffer[10];

	set_value(&eeprom.defval.cw_shift, value, new_val);
	if (value || new_val)
	{
		// check the value and sound tone for each dot CW shift value
		if (keep_within_lim(&eeprom.defval.cw_shift, MIN_CW_SHIFT, MAX_CW_SHIFT) && beep_on)
			beep_up_down(&value);

		// convert CW shift to DDS steps
		calc_morse_shift();
	}

	// display CW shift value
	if (display_on)
	{
		sprintf(buffer, shift, (double)eeprom.defval.cw_shift/10);
		lcd_display_line(1, buffer);
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set JASON speed (eeprom.defval.jason_speed)
//=================================================================================================
void set_jason_speed(int value, int new_val, int beep_on, int display_on)
{
	const char speed[6][10] = {
		{"Slow     "},
		{"Slow+    "},
		{"Normal   "},
		{"Normal+  "},
		{"Fast     "},
		{"Fast+    "}};

	set_value(&eeprom.defval.jason_speed, value, new_val);	
	if (value || new_val)
	{
		// check the value and sound tone for each JASON speed
		if (keep_within_lim(&eeprom.defval.jason_speed, MIN_JASON_SPEED, MAX_JASON_SPEED) && beep_on)
			beep_up_down(&value);

		// calculate new values for the keyer logic
		calc_cw_period();
		calc_jason_shift(eeprom.defval.jason_speed);
	}

	// display JASON speed
	if (display_on)
		lcd_display_line(1, speed[eeprom.defval.jason_speed]);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set OPERA speed (eeprom.defval.opera_speed)
//=================================================================================================
void set_opera_speed(int value, int new_val, int beep_on, int display_on)
{
	const char speed[6][10] = {
		{"Spd 2    "},
		{"Spd 4    "},
		{"Spd 8    "},
		{"Spd 16   "},
		{"Spd 32   "},
		{"Spd 65   "}};

	set_value(&eeprom.defval.opera_speed, value, new_val);
	if (value || new_val)
	{
		// check the value and sound tone for each OPERA speed
		if (keep_within_lim(&eeprom.defval.opera_speed, MIN_OPERA_SPEED, MAX_OPERA_SPEED) && beep_on)
			beep_up_down(&value);

		// calculate new values for the keyer logic
		calc_cw_period();
	}

	// display OPERA speed
	if (display_on)
		lcd_display_line(1, speed[eeprom.defval.opera_speed]);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set WSPR speed (eeprom.defval.wspr_speed)
//=================================================================================================
void set_wspr_speed(int value, int new_val, int beep_on, int display_on)
{
	const char speed[2][10] = {
		{"Spd 2    "},
		{"Spd 15   "}};

	set_value(&eeprom.defval.wspr_speed, value, new_val);
	if (value || new_val)
	{
		// check the value and sound tone for each WSPR speed
		if (keep_within_lim(&eeprom.defval.wspr_speed, MIN_WSPR_SPEED, MAX_WSPR_SPEED) && beep_on)
			beep_up_down(&value);

		// calculate new values for the keyer logic and frequency shift
		calc_cw_period();
		calc_wspr_shifts();
	}

	// display WSPR speed
	if (display_on)
		lcd_display_line(1, speed[eeprom.defval.wspr_speed]);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set WSPR power in dBm (eeprom.defval.wspr_ndbm)
//=================================================================================================
void set_wspr_ndbm(int value, int new_val, int beep_on, int display_on)
{
	const char line1[] = {"WSPR Power      "};
    const char line2[] = {"%.2d dBm   PWR MAX"};
	char buffer[17];

	set_value(&eeprom.defval.wspr_ndbm, value, new_val);
	if (value || new_val)
	{
		// check and normalize value and sound tone for each WSPR power
		if (keep_within_lim(&eeprom.defval.wspr_ndbm, 0, 60) && beep_on)
			beep_up_down(&value);
		eeprom.defval.wspr_ndbm = wspr_ndbm(eeprom.defval.wspr_ndbm);
	}

	// display WSPR power
	if (display_on)
	{
		sprintf(buffer, line2, eeprom.defval.wspr_ndbm);
		lcd_display_all(line1, buffer);
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set FST4W speed (eeprom.defval.fst4w_speed)
//=================================================================================================
void set_fst4w_speed(int value, int new_val, int beep_on, int display_on)
{
	const char speed[4][10] = {
		{"Spd 120  "},
		{"Spd 300  "},
		{"Spd 900  "},
		{"Spd 1800 "}};

	set_value(&eeprom.defval.fst4w_speed, value, new_val);
	if (value || new_val)
	{
		// check the value and sound tone for each FST4W speed
		if (keep_within_lim(&eeprom.defval.fst4w_speed, MIN_FST4W_SPEED, MAX_FST4W_SPEED) && beep_on)
				beep_up_down(&value);

		// calculate new values for the keyer logic and frequency shift
		calc_cw_period();
		calc_fst4w_shifts();
	}

	// display FST4W speed
	if (display_on)
		lcd_display_line(1, speed[eeprom.defval.fst4w_speed]);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set JT9 speed (eeprom.defval.jt9_speed)
//=================================================================================================
void set_jt9_speed(int value, int new_val, int beep_on, int display_on)
{
	const char speed[5][10] = {
		{"Spd 1    "},
		{"Spd 2    "},
		{"Spd 5    "},
		{"Spd 10   "},
		{"Spd 30   "}};

	set_value(&eeprom.defval.jt9_speed, value, new_val);
	if (value || new_val)
	{
		// check the value and sound tone for each JT9 speed
		if (keep_within_lim(&eeprom.defval.jt9_speed, MIN_JT9_SPEED, MAX_JT9_SPEED) && beep_on)
			beep_up_down(&value);

		// calculate new values for the keyer logic and frequency shift
		calc_cw_period();
		calc_jt9_shifts();
	}

	// display JT9 speed
	if (display_on)
		lcd_display_line(1, speed[eeprom.defval.jt9_speed]);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set script frame (eeprom.defval.script_frame)
//=================================================================================================
void set_script_frame(int value, int new_val, int beep_on, int display_on)
{
	const char frame[2][10] = {
		{"TX x1    "},
		{"TX Loop  "}};

	set_value(&eeprom.defval.script_frame, value, new_val);
	if (value || new_val)
		// check the value and sound tone for each script frame
		if (keep_within_lim(&eeprom.defval.script_frame, MIN_SCRIPT_FRAME, MAX_SCRIPT_FRAME) && beep_on)
			beep_up_down(&value);

	// display script frame
	if (display_on)
		lcd_display_line(1, frame[eeprom.defval.script_frame]);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set script delay time (counter.script)
//=================================================================================================
int set_script_delay(int value, int mode, int display_on)
{
	const char timer[] = "%.2ld:%.2ld:%.2ld ";
	char buffer[10];
	long delay, gps;

	switch (mode)
	{
		case 0:				// nothing
		break;

		case 1: default:	// delay in s (1 to 3600)
			keep_within_lim(&value, 1, 3600);
			counter.script = value;
		break;

		case 2:				// delay according to a timeslot in min
			keep_within_lim(&value, 0, 59);
			value = (value * 60) + 1;
			if (value >= counter.sync)
				counter.script = value - counter.sync;
			else
				counter.script = (3600 - counter.sync) + value;
		break;

		case 3:				// delay according to a gps time (0 to 2359)
			if (counter.gps)
			{
				keep_within_lim(&value, 0, 2359);
				delay = value / 100;
				value = value - (delay * 100);
				if (value > 59) value = 59;
				delay = (delay * 3600) + (value * 60);
				gps = ((long)counter.gps_hour * 3600) + counter.sync;
				if (delay >= gps)
					counter.script = delay - gps;
				else
					counter.script = (86400 - gps) + delay;
			}
			else			// no gps available
				return 1;
		break;
	}

	if (mode)		// timeslot restarting
		old.ts = -1;
	
	// display script delay time
	if (display_on)
	{
		sprintf(buffer, timer, (counter.script / 3600), (counter.script % 3600) / 60, (counter.script % 3600) % 60);
		lcd_display_line(1, buffer);
	}

	return 0;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// set software for serial remote (eeprom.defval.rem_soft)
//=================================================================================================
void set_rem_soft(int value, int new_val, int beep_on, int display_on)
{
	const char mode[4][10] = {
		{"JASON n  "},
		{"JASON f  "},
		{"WSQ2     "},
		{"AFP      "}};

	set_value(&eeprom.defval.rem_soft, value, new_val);
	if (value || new_val)
	{
		// check value and sound tone for each remote soft state
		if (keep_within_lim(&eeprom.defval.rem_soft, MIN_REM_SOFT, MAX_REM_SOFT) && beep_on)		
			beep_up_down(&value);

		// define the DDS shift for tone step
		switch (eeprom.defval.rem_soft)
		{
			case REM_JASON_N:
				calc_jason_shift(2);		// JASON normal
			break;

			case REM_JASON_F:
				calc_jason_shift(4);		// JASON fast
			break;

			case REM_WSQ2:
				calc_wsq_shift();
			break;
		}
	}

	// display mode
	if (display_on)
		lcd_display_line(1, mode[eeprom.defval.rem_soft]);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// set CW identification option (eeprom.defval.cwid)
//=================================================================================================
void set_cwid(int value, int new_val, int beep_on, int display_on)
{
	const char line1[] = {"CW Identity     "};
	const char line2[3][17] = {
		{"Select = OFF    "},
		{"Select = 12 WPM "},
		{"Select = 24 WPM "}};

	set_value(&eeprom.defval.cwid, value, new_val);
	if (value || new_val)
		// check value and sound tone for each cw identity
		if (keep_within_lim(&eeprom.defval.cwid, MIN_CWID, MAX_CWID) && beep_on)		
			beep_up_down(&value);

	// display cw identity
	if (display_on)
		lcd_display_all(line1, line2[eeprom.defval.cwid]);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set callsign (eeprom.defval.call)
//=================================================================================================
void set_call(char *value, int error)
{
	// check the wspr callsign validity
	if (wspr_check_call(value, 1))
		strcpy(eeprom.defval.call, value);
	else
	{
		strcpy(eeprom.defval.call, "N0CAL");
		if (error)
			alarms = alarms | CALL_AL;
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Key callsign (eeprom.defval.call)
//=================================================================================================
void key_call(int value, int chr_sel,  int beep_on)
{
	const char line1[] = {"Callsign        "};
    const char line2[] = {"%-13s%s"};
    const char chr[] = {"0123456789/ABCDEFGHIJKLMNOPQRSTUVWXYZ"};
	const char test[2][4] = {{"nok"}, {" ok"}}; 
	char buffer[17];

	// set callsign character
	// add or delete character
	switch (chr_sel)
	{
		case 2:								// add character after cursor
			beep_on = beep_on && add_char(eeprom.defval.call, msg_idx, 10, "A");
			value = 1;
		break;

		case 3:								// delete character present cursor
			beep_on = beep_on && del_char(eeprom.defval.call, msg_idx);
			value = -1;
		break;
	}
	// select and modify character
	switch (chr_sel)
	{
		case 0: default:					// move cursor
			if (strlen(eeprom.defval.call) == 0)
				break;
			msg_idx += value;
			keep_within_lim(&msg_idx, 0, strlen(eeprom.defval.call)-1);
			chr_idx = strchr(chr, eeprom.defval.call[msg_idx]) - chr;
		break;

		case 1:								// modify character
			chr_idx += value;
			keep_within_loop(&chr_idx, 0, strlen(chr)-1);
			if (strlen(eeprom.defval.call) > 0)
				eeprom.defval.call[msg_idx] = chr[chr_idx];
			ms_delay(BUTTON_LIST);
		break;
	}

	// sound tone for each callsign character modification
	if (value && beep_on)
		beep_up_down(&value);

	// display callsign
	if (value || !cur_flg)
	{
		sprintf(buffer, line2, eeprom.defval.call, test[wspr_check_call(eeprom.defval.call, 1)]);
		lcd_display_all(line1, buffer);
		if (strlen(eeprom.defval.call) > 0)
			lcd_cursor_on(2, msg_idx + 1, 1);
		cur_flg = 1;	
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Check callsign (eeprom.defval.call)
//=================================================================================================
void check_call(void)
{
	// check the wspr callsign validity
	if (!wspr_check_call(eeprom.defval.call, 1))
	{
		strcpy(eeprom.defval.call, "N0CAL");
		alarms = alarms | CALL_AL;
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set locator (eeprom.defval.grid)
//=================================================================================================
void set_grid(char *value, int error)
{
	// check the grid validity
	if (wspr_check_grid(value, 1))
		strcpy(eeprom.defval.grid, value);
	else
	{
		strcpy(eeprom.defval.grid, "JJ00AA");
		if (error)
			alarms = alarms | LOC_AL;
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Key locator (eeprom.defval.grid)
//=================================================================================================
void key_grid(int value, int chr_sel,  int beep_on)
{
	const char line1[] = {"Locator         "};
    const char line2[] = {"%-13s%s"};
    const char chr[] = {"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"};
	const char test[2][4] = {{"nok"}, {" ok"}}; 
	char buffer[17];

	// set locator character
	// add or delete character
	switch (chr_sel)
	{
		case 2:								// add character after cursor
			beep_on = beep_on && add_char(eeprom.defval.grid, msg_idx, 6, "A");
			value = 1;
		break;

		case 3:								// delete character present cursor
			beep_on = beep_on && del_char(eeprom.defval.grid, msg_idx);
			value = -1;
		break;
	}
	// select and modify character
	switch (chr_sel)
	{
		case 0: default:					// move cursor
			if (strlen(eeprom.defval.grid) == 0)
				break;
			msg_idx += value;
			keep_within_lim(&msg_idx, 0, strlen(eeprom.defval.grid)-1);
			chr_idx = strchr(chr, eeprom.defval.grid[msg_idx]) - chr;
		break;

		case 1:								// modify character
			chr_idx += value;
			keep_within_loop(&chr_idx, 0, strlen(chr)-1);
			if (strlen(eeprom.defval.grid) > 0)
				eeprom.defval.grid[msg_idx] = chr[chr_idx];
			ms_delay(BUTTON_LIST);
		break;
	}

	// sound tone for each locator character modification
	if (value && beep_on)
		beep_up_down(&value);

	// display locator
	if (value || !cur_flg)
	{
		sprintf(buffer, line2, eeprom.defval.grid, test[wspr_check_grid(eeprom.defval.grid, 1)]);
		lcd_display_all(line1, buffer);
		if (strlen(eeprom.defval.grid) > 0)
			lcd_cursor_on(2, msg_idx + 1, 1);
		cur_flg = 1;	
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Check locator (eeprom.defval.grid)
//=================================================================================================
void check_grid(void)
{
	// check the grid validity
	if (!wspr_check_grid(eeprom.defval.grid, 1))
	{
		strcpy(eeprom.defval.grid, "JJ00AA");
		alarms = alarms | LOC_AL;
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set GPS locator (eeprom.defval.gps)
//=================================================================================================
void set_gps(int value, int new_val, int beep_on, int display_on)
{
	const char line1[] = {"GPS Loc"};
	const char line2[2][17] = {
		{"Select = OFF    "},
		{"Select = ON     "}};
	char buffer[16], grid6[7];

	set_value(&eeprom.defval.gps, value, new_val);
	if (value || new_val)
		// check value and sound tone for each GPS locator type
		if (keep_within_lim(&eeprom.defval.gps, 0, 1) && beep_on)
			beep_up_down(&value);

	// display GPS locator
	if (display_on && counter.gps)
	{
		sprintf(buffer, "%s: %s  ", line1, get_gps_grid6(grid6));
		lcd_display_all(buffer, line2[eeprom.defval.gps]);
	}
	else if (display_on)
	{
		sprintf(buffer, "%sator     ", line1);
		lcd_display_all(buffer, line2[eeprom.defval.gps]);
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set CW side tone (eeprom.defval.cw_sidetone)
//=================================================================================================
void set_cw_sidetone(int value, int new_val, int beep_on, int display_on)
{
	const char line1[] = {"CW Sidetone     "};
	const char line2a[] = {"Tone = OFF      "};
	const char line2b[] = {"Tone = %iHz      "};
	char buffer[17];

	// set CW side tone value
	if (new_val)
		eeprom.defval.cw_sidetone = (value / CW_SIDETONE_STEP) * CW_SIDETONE_STEP;
	else
		eeprom.defval.cw_sidetone += (value * CW_SIDETONE_STEP);

	if ((value || new_val)  || !(value + new_val + beep_on + display_on))
	{
		// check value and sound CW side tone value
		if (keep_within_lim(&eeprom.defval.cw_sidetone, CW_SIDETONE_LOW, CW_SIDETONE_HI) && beep_on)
			beep(set.sidetone, cal.calval.beep_len);

		// calculate new timer value
		calc_sidetone();
	}

	// display CW side tone value
	if(display_on)
	{
		if (eeprom.defval.cw_sidetone == CW_SIDETONE_OFF)
			sprintf(buffer, line2a);
		else
			sprintf(buffer, line2b, eeprom.defval.cw_sidetone);
		lcd_display_all(line1, buffer);
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set keyer mode (eeprom.defval.cw_keyer)
//=================================================================================================
void set_cw_keyer(int value, int new_val, int beep_on, int display_on)
{
	const char line1[] = {"CW Keyer Type   "};
	const char line2[5][17] = {
		{"Keyer = Dot pri."},
		{"Keyer = Iambic A"},
		{"Keyer = Iambic B"},
		{"Keyer = Straight"},
		{"Keyer = Beacon  "}};

	set_value(&eeprom.defval.cw_keyer, value, new_val);
	if (value || new_val)
	{
		// check value and sound tone for each keyer mode value
		if (keep_within_lim(&eeprom.defval.cw_keyer, 0, 4) && beep_on)
			beep_up_down(&value);

		// stop beacon TX if it was on if any other type than beacon selected
		if(eeprom.defval.cw_keyer != 4)
			eeprom.defval.beacon_tx_on = 0;
	}

	// display keyer mode value
	if (display_on)
		lcd_display_all(line1, line2[eeprom.defval.cw_keyer]);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set LCD contrast (eeprom.defval.contrast)
//=================================================================================================
void set_contrast(int value, int new_val, int beep_on, int display_on)
{
	const char line1[] = {"Display Contrast"};
	const char line2[] = {"Contrast = %i    "};
	char buffer[17];

	// set LCD contrast value
	if (new_val)
		eeprom.defval.contrast = value;
	else
		eeprom.defval.contrast += (value * 50);

	if ((value || new_val)  || !(value + new_val + beep_on + display_on))
	{
		// check value and sound tone for each LCD contrast value
		if (keep_within_lim(&eeprom.defval.contrast, 0, MAX_CONTRAST) && beep_on)
			beep_up_down(&value);

		// set PWM for LCD contrast
		set_pwm4_dac(eeprom.defval.contrast);
	}

	// display LCD contrast value
	if(display_on)
	{
		sprintf(buffer, line2, eeprom.defval.contrast);
		lcd_display_all(line1, buffer);
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set LCD back light (eeprom.defval.back_light)
//=================================================================================================
void set_back_light(int value, int new_val, int beep_on, int display_on)
{
	const char line1[] = {"Displ Brightness"};
	const char line2[] = {"LCD BL = %i      "};
	char buffer[17];

	set_value(&eeprom.defval.back_light, value, new_val);
	if ((value || new_val)  || !(value + new_val + beep_on + display_on))
	{
		// check value and sound tone for each LCD back light value
		if (keep_within_lim(&eeprom.defval.back_light, 0, MAX_BL) && beep_on)
			beep_up_down(&value);

		// set PWM for LCD back light
		set_pwm3_dac(eeprom.defval.back_light);
	}

	// display LCD back light value
	if(display_on)
	{
		sprintf(buffer, line2, eeprom.defval.back_light);
		lcd_display_all(line1, buffer);
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set UART1 serial mode (eeprom.defval.serial_mode)
//=================================================================================================
void set_serial_mode(int value, int new_val, int beep_on, int display_on)
{
	const char line1[] = {"Serial Protocol "};
	const char line2[3][17] = {
		{"RS232 =TX136/500"},
		{"RS232 = Terminal"},
		{"RS232 = GPS NMEA"}};

	set_value(&eeprom.defval.serial_mode, value, new_val);
	if (value || new_val)
		// check value and sound tone for each serial mode
		if (keep_within_lim(&eeprom.defval.serial_mode, 0, 2) && beep_on)
			beep_up_down(&value);

	// display serial mode
	if (display_on)
		lcd_display_all(line1, line2[eeprom.defval.serial_mode]);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set UART1 baud rate(eeprom.defval.br)
//=================================================================================================
void set_baud_rate(int value, int new_val, int beep_on, int display_on)
{
	const char line1[] = {"Serial Speed    "};
	const char line2[8][17] = {
		{"Baud Rate=1200  "},
		{"Baud Rate=2400  "},
		{"Baud Rate=4800  "},
		{"Baud Rate=9600  "},
		{"Baud Rate=19200 "},
		{"Baud Rate=38400 "},
		{"Baud Rate=57600 "},
		{"Baud Rate=115200"}};

	set_value(&eeprom.defval.br, value, new_val);
	if ((value || new_val)  || !(value + new_val + beep_on + display_on))
	{
		// check value and sound tone for each baud rate
		if (keep_within_lim(&eeprom.defval.br, 0, 7) && beep_on)
			beep_up_down(&value);

		// set new baud rate
		uart1_set_baud(eeprom.defval.br);
	}

	// display baud rate value
	if(display_on)
		lcd_display_all(line1, line2[eeprom.defval.br]);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set SWR alarm trip points (eeprom.defval.swr_limit[])
//=================================================================================================
void set_swr_limit(int value, int new_val, int beep_on, int display_on)
{
	const char line1[] = {"SWR Prot "};
	const char line2[] = {"Limit = %3.1f    "};
	char buffer [17];

	// set SWR alarm trip point value
	if (new_val)
		eeprom.defval.swr_limit[eeprom.defval.rfpwr] = value;
	else
		eeprom.defval.swr_limit[eeprom.defval.rfpwr] += (value * 10);

	if (value || new_val)
		// check value and ound tone for each SWR alarm trip point
		if (keep_within_lim(&eeprom.defval.swr_limit[eeprom.defval.rfpwr], 100, MAX_SWR) && beep_on)
			beep_up_down(&value);

	// display SWR alarm trip point
	if(display_on)
	{
		sprintf(buffer, line2, (double)eeprom.defval.swr_limit[eeprom.defval.rfpwr] / 100);
		lcd_display_all(line1, buffer);
		set_tx_power(0, 0, 0, 1);
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================-
// Set auto or PTT operated TX (eeprom.defval.mox)
//=================================================================================================
int set_mox(int value, int new_val, int beep_on, int display_on)
{
	int mod = 0;
	const char line1[17] = {"TX Control      "};
	const char line2[3][17] = {
		{"Select = Auto   "},
		{"Select = MOX    "},
		{"Select = RTS    "}};

	set_value(&eeprom.defval.mox, value, new_val);
    if (value || new_val)
	{
        // check value and sound tone for each auto or PTT state
        if (keep_within_lim(&eeprom.defval.mox,  PTT_AUTO,  PTT_RTS) && beep_on)
			beep_up_down(&value);

		// PTT is modified
		mod = 1;
	}

	// display auto or PTT state
	if (display_on)
		lcd_display_all(line1, line2[eeprom.defval.mox]);

	return mod;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set SPARE I/O (eeprom.defval.spare_io)
//=================================================================================================
void set_spare_io(int value, int new_val, int beep_on, int display_on)
{
	const char line1[17] = {"SPARE I/O Signal"};
	const char line2[2][17] = {
		{"Select = OFF    "},
		{"Select = ON     "}};

	set_value(&eeprom.defval.spare_io, value, new_val);
    if ((value || new_val)  || !(value + new_val + beep_on + display_on))
	{
        // check value and sound tone for each SPARE digital I/O state
        if (keep_within_lim(&eeprom.defval.spare_io, 0, 1) && beep_on)
			beep_up_down(&value);

        // set SPARE digital I/O relay
        SPARE = eeprom.defval.spare_io;
	}

	// display SPARE digital I/O
	if (display_on)
		lcd_display_all(line1, line2[eeprom.defval.spare_io]);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set beacon transmit (eeprom.defval.beacon_tx_on)
//=================================================================================================
void set_beacon_tx(int value, int new_val)
{
	set_value(&eeprom.defval.beacon_tx_on, value, new_val);   
    // check value
   	keep_within_lim(&eeprom.defval.beacon_tx_on, -1, 99);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set script on (eeprom.defval.script_on)
//=================================================================================================
void set_script_on(int value, int new_val)
{
	set_value(&eeprom.defval.script_on, value, new_val);    
    // check value
   	keep_within_lim(&eeprom.defval.script_on, -1, MAX_SCRIPT_FRAME);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set CW beacon message (beacon_buffer)
//=================================================================================================
void set_cw_beacon(char *value, int idx, int error)
{
	if (idx > 0 && idx < CW_BEACON_BUFFER_SIZE)
		cw_beacon_buffer[idx-1] = *value;
	else if (morse_message(value, CW_BEACON_BUFFER_SIZE))
		strcpy(cw_beacon_buffer, value);
	else
	{	
		strcpy(cw_beacon_buffer, "TEST DE JUMA BEACON ");
		if (error)
			alarms = alarms | MSG_AL;
	}
	// reset display
	msg_idx = 0;
	disp_idx = 0;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Key CW beacon message (beacon_buffer)
//=================================================================================================
void key_cw_beacon(int value, int chr_sel,  int beep_on)
{
	int i, j;
	const char line1[] = {"CW Beacon text  "};
	char beacon_display[17], line2[17];

	// set CW beacon message character
	// add or delete character
	switch (chr_sel)
	{
		case 2:								// add character after cursor
			beep_on = beep_on && add_char(cw_beacon_buffer, msg_idx, CW_BEACON_BUFFER_SIZE, " ");
			value = 1;
			cw_beacon_flg = 1;
		break;

		case 3:								// delete character present cursor
			beep_on = beep_on && del_char(cw_beacon_buffer, msg_idx);
			value = -1;
			cw_beacon_flg = 1;
		break;
	}

	// select and modify character
	switch (chr_sel)
	{
		case 0: default:					// move cursor
			if (strlen(cw_beacon_buffer) == 0)
				break;
			msg_idx += value;
			if (keep_within_lim(&msg_idx, 0, strlen(cw_beacon_buffer)-1))
			{
				disp_idx += value;
				keep_within_lim(&disp_idx, 0, 15);
			}
			chr_idx = cw_beacon_buffer[msg_idx] - 0x20;
		break;

		case 1:								// modify character
			chr_idx += value;
			keep_within_loop(&chr_idx, 0, 63);
			if (strlen(cw_beacon_buffer) > 0)
				cw_beacon_buffer[msg_idx] = chr_idx + 0x20;
			ms_delay(BUTTON_LIST);
			cw_beacon_flg = 1;
		break;
	}

	// sound tone for each CW beacon message modification
	if (value && beep_on)
		beep_up_down(&value);

	// display CW beacon message
	if (value || !cur_flg)
	{
		for (i=0; i<16; i++)
			beacon_display[i] = cw_beacon_buffer[i + msg_idx - disp_idx];
		for (i=0; i<strlen(beacon_display); i++)
			line2[i] = beacon_display[i];
		for (j=i; j<16; j++)
			line2[j] = ' ';
		lcd_display_all(line1, line2);
		if (strlen(cw_beacon_buffer) > 0)
			lcd_cursor_on(2, disp_idx + 1, 1);
		cur_flg = 1;
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set beacon message (beacon_buffer)
//=================================================================================================
void set_beacon(char *value, int idx, int error)
{
	if (idx > 0 && idx < BEACON_BUFFER_SIZE)
		beacon_buffer[idx-1] = *value;
	else if (morse_message(value, BEACON_BUFFER_SIZE))
		strcpy(beacon_buffer, value);
	else
	{	
		strcpy(beacon_buffer, "TEST ");
		if (error)
			alarms = alarms | MSG_AL;
	}
	// reset display
	msg_idx = 0;
	disp_idx = 0;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Key beacon message (beacon_buffer)
//=================================================================================================
void key_beacon(int value, int chr_sel,  int beep_on)
{
	int i, j;
	const char line1[] = {"Beacon text     "};
	char beacon_display[17], line2[17];

	// set beacon message character
	// add or delete character
	switch (chr_sel)
	{
		case 2:								// add character after cursor
			beep_on = beep_on && add_char(beacon_buffer, msg_idx, BEACON_BUFFER_SIZE, " ");
			value = 1;
			beacon_flg = 1;
		break;

		case 3:								// delete character present cursor
			beep_on = beep_on && del_char(beacon_buffer, msg_idx);
			value = -1;
			beacon_flg = 1;
		break;
	}

	// select and modify character
	switch (chr_sel)
	{
		case 0: default:					// move cursor
			if (strlen(beacon_buffer) == 0)
				break;
			msg_idx += value;
			if (keep_within_lim(&msg_idx, 0, strlen(beacon_buffer)-1))
			{
				disp_idx += value;
				keep_within_lim(&disp_idx, 0, 15);
			}
			chr_idx = beacon_buffer[msg_idx] - 0x20;
		break;

		case 1:								// modify character
			chr_idx += value;
			keep_within_loop(&chr_idx, 0, 63);
			if (strlen(beacon_buffer) > 0)
				beacon_buffer[msg_idx] = chr_idx + 0x20;
			ms_delay(BUTTON_LIST);
			beacon_flg = 1;
		break;
	}

	// sound tone for each CW beacon message modification
	if (value && beep_on)
		beep_up_down(&value);

	// display CW beacon message
	if (value || !cur_flg)
	{
		for (i=0; i<16; i++)
			beacon_display[i] = beacon_buffer[i + msg_idx - disp_idx];
		for (i=0; i<strlen(beacon_display); i++)
			line2[i] = beacon_display[i];
		for (j=i; j<16; j++)
			line2[j] = ' ';
		lcd_display_all(line1, line2);
		if (strlen(beacon_buffer) > 0)
			lcd_cursor_on(2, disp_idx + 1, 1);
		cur_flg = 1;
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set message from JUMA software
//=================================================================================================
void set_message(char *value, int error)
{
	// check the message validity
	if (morse_message(value, MSG_BUFFER_SIZE))
		strcpy(message, value);
	else
		if (error)
			alarms = alarms | MSG_AL;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set script (script_buffer)
//=================================================================================================
void set_script(char *value, int idx)
{
	if (idx > 0 && idx < SCRIPT_BUFFER_SIZE)
		script_buffer[idx-1] = *value;
	else
		strcpy(script_buffer, value);
	
	// reset display
	msg_idx = 0;
	disp_idx = 0;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Key script (script_buffer)
//=================================================================================================
void key_script(int value, int chr_sel,  int beep_on)
{
	int i, j;
	const char line1[] = {"Script          "};
	//const char chr[] = {"0123456789=ABCDEFGHIJKLMNOPQRSTUVWXYZ"};
	char script_display[17], line2[17];

	// set script character
	// add or delete character
	switch (chr_sel)
	{
		case 2:								// add character after cursor
			beep_on = beep_on && add_char(script_buffer, msg_idx, SCRIPT_BUFFER_SIZE, "=");
			value = 1;
			script_flg = 1;
		break;

		case 3:								// delete character present cursor
			beep_on = beep_on && del_char(script_buffer, msg_idx);
			value = -1;
			script_flg = 1;
		break;
	}

	// select and modify character
	switch (chr_sel)
	{
		case 0: default:					// move cursor
			if (strlen(script_buffer) == 0)
				break;
			msg_idx += value;
			if (keep_within_lim(&msg_idx, 0, strlen(script_buffer)-1))
			{
				disp_idx += value;
				keep_within_lim(&disp_idx, 0, 15);
			}
			chr_idx = script_buffer[msg_idx] - 0x20;
		break;

		case 1:								// modify character
			chr_idx += value;
			keep_within_loop(&chr_idx, 0, 63);
			if (strlen(script_buffer) > 0)	
				script_buffer[msg_idx] = chr_idx + 0x20;
			ms_delay(BUTTON_LIST);
			script_flg = 1;
		break;
	}

	// sound tone for each script modification
	if (value && beep_on)
		beep_up_down(&value);

	// display script
	if (value || !cur_flg)
	{
		for (i=0; i<16; i++)
			script_display[i] = script_buffer[i + msg_idx - disp_idx];
		for (i=0; i<strlen(script_display); i++)
			line2[i] = script_display[i];
		for (j=i; j<16; j++)
			line2[j] = ' ';
		lcd_display_all(line1, line2);
		if (strlen(script_buffer) > 0)
			lcd_cursor_on(2, disp_idx + 1, 1);
		cur_flg = 1;
	}
}
//-------------------------------------------------------------------------------------------------


//*************************************************************************************************
// System calibration values
//*************************************************************************************************

//=================================================================================================
// Set local oscillator calibration value (cal.calval.ref_osc)
//=================================================================================================
void set_cal_oscillator(int value, int new_val, int beep_on, int display_on)
{
	const long ref_osc[5] = {REF_OSC_U, REF_OSC_6, REF_OSC_20, REF_OSC_6, REF_OSC_20};
	const char line1[] = {"Set Ref Osc Freq"};
	const char line2[] = {"Osc %li Hz  "};
	char buffer[17];

	// set local oscillator value
    if (new_val)
        cal.calval.ref_osc[board_type] = value;
    else
        cal.calval.ref_osc[board_type] += (value * 10);
        
    if (value || new_val)
        // check value and sound tone for local oscillator value change
        if (keep_within_lim_long(&cal.calval.ref_osc[board_type], ref_osc[board_type] - 1000, ref_osc[board_type] + 1000) && beep_on)
			beep_up_down(&value);

	// display local oscillator value
	if (display_on)
	{
		sprintf(buffer, line2, cal.calval.ref_osc[board_type]);
		lcd_display_all(line1, buffer); 
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set drain current scaling calibration value (cal.calval.id_mult)
//=================================================================================================
void set_cal_id(int value, int new_val, int beep_on, int display_on)
{
	const char line1[] = {"Drain Current   "};
	const char line2[] = {"Cal mult = %i   "};
	char buffer[17];

	set_value(&cal.calval.id_mult, value, new_val);        
    if (value || new_val)
        // check value and sound tone for drain current scaling calibration change
        if (keep_within_lim(&cal.calval.id_mult, 3000, 5000) && beep_on)
			beep_up_down(&value);

	// display drain current scaling calibration
	if (display_on)
	{
		sprintf(buffer, line2, cal.calval.id_mult);
		lcd_display_all(line1, buffer); 
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set battery voltage calibration value (cal.calval.batt_mult)
//=================================================================================================
void set_cal_batt(int value, int new_val, int beep_on, int display_on)
{
	const char line1[] = {"Supply   %2.2f V"};
	const char line2[] = {"Cal mult = %i   "};
	char buffer1[17], buffer2[17];

	set_value(&cal.calval.batt_mult, value, new_val);     
    if (value || new_val)
        // check value and sound tone for battery voltage calibration change
       	if (keep_within_lim(&cal.calval.batt_mult, 100, 200) && beep_on)
			beep_up_down(&value);

	// display battery voltage calibration
	if (display_on)
	{
		sprintf(buffer1, line1, (double)meas_batt_volt() / 100);
		sprintf(buffer2, line2, cal.calval.batt_mult);
		lcd_display_all(buffer1, buffer2); 
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set forward power scaling calibration value (cal.calval.fwd_pwr_mult)
//=================================================================================================
void set_cal_fwr_pwr(int value, int new_val, int beep_on, int display_on)
{
	const char line1[] = {"Forward Power   "};
	const char line2[] = {"Cal mult = %i   "};
	char buffer[17];

	set_value(&cal.calval.fwd_pwr_mult, value, new_val);         
    if (value || new_val)
        // check value and sound tone for forward power scaling calibration change
        if (keep_within_lim(&cal.calval.fwd_pwr_mult, 0, 100) && beep_on)
			beep_up_down(&value);

	// display forward power scaling calibration
	if (display_on)
	{
		sprintf(buffer, line2, cal.calval.fwd_pwr_mult);
		lcd_display_all(line1, buffer); 
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set beep length calibration value (cal.calval.beep_len)
//=================================================================================================
void set_cal_beep(int value, int new_val, int beep_on, int display_on)
{
	const char line1[] = {"Beep time 0=OFF "};
	const char line2[] = {"Beep = %i ms    "};
	char buffer[17];

	set_value(&cal.calval.beep_len, value, new_val);          
    if (value || new_val)
        // check value and sound tone for beep length calibration change
        if (keep_within_lim(&cal.calval.beep_len, 0, 100) && beep_on)
			beep_up_down(&value);

	// display beep length calibration
	if (display_on)
	{
		sprintf(buffer, line2, cal.calval.beep_len);
		lcd_display_all(line1, buffer); 
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set CW break period calibration value (cal.calval.cw_break_time)
//=================================================================================================
void set_cal_cw_break(int value, int new_val, int beep_on, int display_on)
{
	const char line1[] = {"CW break period "};
	const char line2[] = {"%.2d Units        "};
	char buffer[17];

	set_value(&cal.calval.cw_break_time, value, new_val);        
    if (value || new_val)
        // check value and sound tone for CW break period calibration change
        if (keep_within_lim(&cal.calval.cw_break_time, MIN_CW_BREAK_TIME, MAX_CW_BREAK_TIME) && beep_on)
			beep_up_down(&value);

	// display CW break period calibration
	if (display_on)
	{
		sprintf(buffer, line2, cal.calval.cw_break_time);
		lcd_display_all(line1, buffer); 
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set milliseconds counter offset calibration value (cal.calval.ms_offset)
//=================================================================================================
void set_cal_ms_offset(int value, int new_val, int beep_on, int display_on)
{
	const char line1[] = {"WSPR timer Cal  "};
	const char line2[] = {"%.2d Units        "};
	char buffer[17];

	set_value(&cal.calval.ms_offset, value, new_val);        
    if (value || new_val)
        // check value and sound tone for WSPR timer offset calibration change
        if (keep_within_lim(&cal.calval.ms_offset, MIN_MS_OFFSET, MAX_MS_OFFSET) && beep_on)
			beep_up_down(&value);

	// display WSPR timer offset calibration
	if (display_on)
	{
		sprintf(buffer, line2, cal.calval.ms_offset);
		lcd_display_all(line1, buffer); 
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set jumper Q4 (automatic power on) value (cal.calval.power_q4)
//=================================================================================================
void set_cal_power_q4(int value, int new_val, int beep_on, int display_on)
{
	const char line1[] = {"Auto Power On   "};
	const char line2[2][17] = {
		{"Jumper Q4 = OFF "},
		{"Jumper Q4 = ON  "}};
	char buffer[17];

	set_value(&cal.calval.power_q4, value, new_val);         
    if (value || new_val)
        // check value and sound tone for jumper Q4 (automatic power on) value
        if (keep_within_lim(&cal.calval.power_q4, 0, 1) && beep_on)
			beep_up_down(&value);

	// display jumper Q4 (automatic power on) value
	if (display_on)
	{
		sprintf(buffer, line2[cal.calval.power_q4]);
		lcd_display_all(line1, buffer); 
	}
}
//-------------------------------------------------------------------------------------------------

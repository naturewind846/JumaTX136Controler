//*************************************************************************************************
//
// Cheap DSP dsPICradio board LCD routines
// This is polling driver with 8-bit interface
//
// Juha Niinikoski OH2NLT 26.08.2005
//
// Modified for Digital RX hardware 12.09.2006
// MPLAB C30 version, OH2GWE, 2006.10.17
//
// IRQ mask added to LCD I/O port operations. IRQ tone output needs this protection.
// S-meter roll over corrected, interface changed to int 02.12.2006
// LCD HEX output added 09.07.2007
// PA100 temp meter degree sign added to the soft fonts #4 16.11.2008
// TX500 frequency display format added 18.08.2009
//
// Frequency display in Hz - F4GCB 08.2014
// Program structure modified to improve readability and maintenance - F4GCB 02-2015
// Add display and blink cursor - F4GCB 02-2015
// Due to some LCD displays convert Yen sign conversion to accent sign (to display back slash)
// in display null terminated string function - F4GCB 08-2015
//
//*************************************************************************************************

#include <p30f6014A.h>

// Definitions ------------------------------------------------------------------------------------
#define LINE1     	0x00         			// line 1 start address
#define LINE2     	0x40         			// line 2 start address

#define CURSET    	0x80         			// set memory cursor
#define	CLEAR	  	0x01					// clear display
#define ADRSET		0x40					// set cgram address

#define CURON		0x0E					// underline cursor on
#define CUROFF		0x0C					// underline cursor off
#define CURBLKON	0x0D					// blinking cursor on
#define CURBLKOFF	0x0C					// blinking cursor off

#define LCD_E		_LATD5					// LCD E signal
#define LCD_RW		_LATD6					// LCD R/W signal
#define LCD_RS		_LATD7					// LCD RS signal
#define LCD_DATA	LATD					// LCD 8-bit data bus out register
#define LCD_BUS		PORTD					// LCD 8-bit data bus state
#define LCD_TRIS	TRISD					// LCD data direction
#define LCD_SHIFT 8							// LCD bits shifted from D0
#define LCD_MASK	(0x00FF<<LCD_SHIFT)		// LCD data lines at port

// External functions ----------------------------------------------------------------------------
extern void us_delay( unsigned int);
extern void ms_delay( unsigned int);


//=================================================================================================
// Set data & clock both lcd controllers
//=================================================================================================
void lcd_clk(unsigned char ldata)
{
	__asm__ volatile ("disi #9");			// protect IRQ tone output to RD1 I/O
	LCD_DATA = (LCD_DATA & ~LCD_MASK) | ((ldata<<LCD_SHIFT) & LCD_MASK);	// set LCD data lines
	us_delay(1);							// extra delay for filter board latch wires
	LCD_E = 1;
	us_delay(1);
	LCD_E = 0;
	us_delay(1); 							// some delay
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Wait until lcd module is ready
//=================================================================================================
void wait_lcd_rdy(void)
{
	unsigned int BF_AC;						// BF flag & address counter

	BF_AC = (0x80<<LCD_SHIFT);				// set busy for first round
	__asm__ volatile ("disi #4");			// protect IRQ tone output to RD1 I/O
	LCD_TRIS = LCD_TRIS | LCD_MASK;			// make data port input, LCD bus direction bits = 1
	LCD_RW = 1;								// read
	LCD_RS = 0;								// command mode
	while(BF_AC & (0x80<<LCD_SHIFT))
	{
		us_delay(1);;						// 18.01.2004 for slow display
		LCD_E = 1;
		us_delay(2);
		BF_AC = LCD_BUS & LCD_MASK;			// read from port pins
		LCD_E = 0;
	}
	LCD_RW = 0;
	LCD_RS = 1;
	__asm__ volatile ("disi #4");			// protect IRQ tone output to RD1 I/O
	LCD_TRIS = LCD_TRIS & (~LCD_MASK);		// return to write mode
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set cursor position at selected display
//=================================================================================================
void lcd_set_cur(unsigned char cur)
{
	wait_lcd_rdy();
	LCD_RS = 0;								// switch command mode
	lcd_clk(cur | CURSET);					// set cursor command + cursor position
	LCD_RS = 1;								// back to data mode
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Clear selected display
//=================================================================================================
void lcd_clear(void)
{
	wait_lcd_rdy();
	LCD_RS = 0;								// switch command mode
	lcd_clk(CLEAR);							// clear display. Display going to be busy 1,6 mS
	LCD_RS = 1;								// back to data mode
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Init selected LCD controller
//=================================================================================================
void lcd_init(void)
{
	LCD_RS = 0;								// set command mode
	LCD_RW = 0;
	ms_delay(15);							// start delay
	lcd_clk(0x38);							// write init data with delays
	ms_delay(5);
	lcd_clk(0x38);
	ms_delay(1);
	lcd_clk(0x38);							//8-bit, 2 rows, 5x7 matrix, display on
	ms_delay(1);
	lcd_clk(0x0C);							//cursor off, no blink
	ms_delay(1);
	lcd_clk(0x01);
	ms_delay(2);
	lcd_clk(0x06);							// increment, no display shift
	ms_delay(1);
	LCD_RS = 1;								// set data mode
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Output character to selected display
//=================================================================================================
void lcd_outch(unsigned char lcd_char)
{
	wait_lcd_rdy();
	lcd_clk(lcd_char);
}
//-------------------------------------------------------------------------------------------------


//*************************************************************************************************
// HD44780 character generator routines
// modified for SOLOMON LM1125SYLU1 display
//*************************************************************************************************

const char Blockslr[6] = {0x20, 0x00, 0x00, 0x01, 0x01, 0x02};	// blocks for L to R bar graph
const char Blocksrl[6] = {0x20, 0x03, 0x03, 0x04, 0x04, 0x02};	// R to L


//=================================================================================================
// Set cgram address & data
//=================================================================================================
void set_cgram(unsigned char adr, unsigned char dta)
{
	wait_lcd_rdy( );
	LCD_RS = 0;								// switch command mode
	adr = adr & 0x3F;
	lcd_clk(adr | ADRSET);					// set cgram address command + address
	LCD_RS = 1;								// back to data mode
	wait_lcd_rdy();
	lcd_clk(dta);
	lcd_clear();							// back to normal mode (clear LCD)
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set chgen bits. Data, number of sets
//=================================================================================================
void set_ch_bits(char dta, char cnt)
{
	char x;
	for(x=0; x<cnt; x++)
	{
		wait_lcd_rdy();
		lcd_clk(dta);
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Write bar symbols to HD44780 RAM chgen
//=================================================================================================
void lcd_set_chgen(void)
{
	wait_lcd_rdy( );
	LCD_RS = 0;								// switch command mode
	lcd_clk(0 | ADRSET);					// set cgram address command + address
	LCD_RS = 1;								// back to data mode

	set_ch_bits(0, 1);
	set_ch_bits(0x10, 5);					// CGRAM 00 Blocks L > R
	set_ch_bits(0, 2);

	set_ch_bits(0, 1);
	set_ch_bits(0x14, 5);					// CGRAM 01
	set_ch_bits(0, 2);

	set_ch_bits(0, 1);
	set_ch_bits(0x15, 5);					// CGRAM 02 "Full block"
	set_ch_bits(0, 2);

	set_ch_bits(0, 1);
	set_ch_bits(0x01, 5);					// CGRAM 03 Blocks R > L
	set_ch_bits(0, 2);

	//set_ch_bits(0, 1);
	//set_ch_bits(0x05, 5);					// CGRAM 04
	//set_ch_bits(0, 2);

	set_ch_bits(0x1C, 1);					// CGRAM 04, PA100 Temp meter degree sign
	set_ch_bits(0x14, 1);
	set_ch_bits(0x1C, 1);
	set_ch_bits(0, 5);

	set_ch_bits(0, 2);						// CGRAM 05 S-meter S9 marker
	set_ch_bits(0x10, 1);
	set_ch_bits(0, 1);
	set_ch_bits(0x10, 1);
	set_ch_bits(0, 3);

	set_ch_bits(0, 3);						// CGRAM 06 S-meter scale dot
	set_ch_bits(0x10, 1);
	set_ch_bits(0, 4);

	set_ch_bits(0, 2);						// CGRAM 07 S-meter scale bar
	set_ch_bits(0x10, 3);
	set_ch_bits(0, 3);

	lcd_clear();							// back to normal mode (clear LCD)
}
//-------------------------------------------------------------------------------------------------


//*************************************************************************************************
// Bar graph functions
//*************************************************************************************************

#define DISP_LEN 8							// display lemgth (char)
#define FONT_W 6							// font width
#define MAX_GRAPH (DISP_LEN * FONT_W)		// graph length in pixels (5*16 = 80)

//const char scale_dots[16] = {6,32,6,32,6,32,6,32,7,32,7,32,7,32,7,32}; 	// for 16 char long graph
//const char scale_dots[8] = {6,32,6,32,7,32,7,32}; 						//for 8 long graph, standard
//const char scale_dots[8] = {6,6,6,6,7,7,7,7}; 							//4 dots, 4 dash
const char scale_dots[8] = {6,6,6,6,5,7,7,7}; 								//4 dots, S9 marker, 3 dash


//=================================================================================================
// Draw 16 long S-meter, scale = 0...96 (48 visible steps)
// Draw 8 long S-meter, scale = 0...48 (24 visible steps)
// Buffer is used to avoid LCD flicker
//=================================================================================================
void lcd_s_meter(int len)
{
	int x, whole, part, idx;
	char bar_buffer[DISP_LEN];				// display buffer

	if(len > MAX_GRAPH)						// cut to max
		len = MAX_GRAPH;

	whole = len / FONT_W;					// calculate graph
	part = len % FONT_W;

	idx = 0;
	for(x=0; x<DISP_LEN; x++)				// copy scale dots to buffer
	{
		bar_buffer[idx] = scale_dots[x];
		idx++;
	}

	idx = 0;								// draw graph to buffer
	while(whole > 0)
	{
		bar_buffer[idx] = 0x02;				// draw full blocks
		idx++;
		whole--;
	}

	if(part > 0)
		bar_buffer[idx] = Blockslr[part]; 	// draw partial block to buffer

	for(x=0; x<DISP_LEN; x++)				// print meter buffer to LCD
		lcd_outch(bar_buffer[x]);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Draw bar graph
// 0 = left to right, 1 = right to left
//=================================================================================================
void lcd_bar_graph(int len, int dir)
{
	int x, whole, part, l, idx;
	char bar_buffer[DISP_LEN];				// display buffer

	if(len > MAX_GRAPH)						// cut to max
		len = MAX_GRAPH;

	l =  DISP_LEN;
	whole = len / FONT_W;					// calculate graph
	part = len % FONT_W;

	if(dir == 0)							// L to R
	{
		idx = 0;
		while(whole > 0)
		{
			bar_buffer[idx] = 0x02;			// draw full blocks
			idx++;
			whole--;
			l--;
		}
		if(part > 0)
		{
			bar_buffer[idx] = Blockslr[part]; // draw partial block
			idx ++;
			l--;
		}
		for(x=0; x<l; x++)					// clear rest of the line
		{
			bar_buffer[idx] = 0x20;
			idx++;
		}
	}
	else									// draw from R to L
	{
		idx = DISP_LEN - 1;
		while(whole > 0)
		{
			bar_buffer[idx] = 0x02;			// draw full blocks
			idx--;
			whole--;
			l--;
		}
		if(part > 0)
		{
			bar_buffer[idx] = Blocksrl[part]; // draw partial block
			idx --;
			l--;
		}
		for(x=0; x<l; x++)					// clear rest of the line
		{
			bar_buffer[idx] = 0x20;
			idx--;
		}
	}

	for(x=0; x<DISP_LEN; x++)				// print buffer
		lcd_outch(bar_buffer[x]);
}
//-------------------------------------------------------------------------------------------------


//*************************************************************************************************
// General I/O functions
//*************************************************************************************************

//=================================================================================================
// Display character
//=================================================================================================
void lcd_putch(unsigned char c)
{
	lcd_outch(c);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Display character in HEX format
//=================================================================================================
void lcd_putchhex(unsigned char c)
{
	unsigned char temp;
	temp=c;

	c=(c >> 4);
	if (c<10) c+=48; else c+=55;
	lcd_outch(c);
	c=temp;
	c=(c & 0x0F);
	if (c<10) c+=48; else c+=55;
	lcd_outch(c);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Display null terminated string
//=================================================================================================
void lcd_putst(register const char *str)
{
	while((*str)!=0)
	{
		if (*str == 0x5C) lcd_outch(0x60);					// in some LCD displays back slash is Yen sign
		else lcd_outch(*str);
		//if (*str==13) lcd_outch(10);
		//if (*str==10) lcd_outch(13);
		str++;
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Display long in decimal format
// if mode !=0 do "short" display
//=================================================================================================
void lcd_putlong( long x, char mode )
{
	if(mode == 0)							// full display
	{
		//giga
		lcd_outch((x/1000000000)+'0');
		x-=(x/1000000000)*1000000000;
		lcd_outch('.');

		//100_million
		lcd_outch((x/100000000)+'0');
		x-=(x/100000000)*100000000;
	}

	//10_million
	if(mode !=0 && x/10000000 == 0)
		lcd_outch(' ');						// lead sign zero blanc for frequency display
	else
		lcd_outch((x/10000000)+'0');
	x-=(x/10000000)*10000000;

	//million
	lcd_outch((x/1000000)+'0');
	x-=(x/1000000)*1000000;
	lcd_outch('.');

	//100_thousands
	lcd_outch((x/100000)+'0');
	x-=(x/100000)*100000;

	//10_thousands
	lcd_outch((x/10000)+'0');
	x-=(x/10000)*10000;

	//thousands
	lcd_outch((x/1000)+'0');
	x-=(x/1000)*1000;
	lcd_outch('.');

	//hundreds
	lcd_outch((x/100)+'0');
	x-=(x/100)*100;

	//tens
	lcd_outch((x/10)+'0');
	x-=(x/10)*10;

	//ones
	if(mode == 0)							// full display
		lcd_outch((x/1)+'0');
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Display frequency format
//=================================================================================================
void lcd_freq(long x)
{
	lcd_putlong(x, 1);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// TX500 frequency display format
//=================================================================================================
void lcd_tx500_freq(long x)
{
	if (x > 999999)
		x = 999999;

	//100_thousands
	lcd_outch((x/100000)+'0');
	x-=(x/100000)*100000;

	//10_thousands
	lcd_outch((x/10000)+'0');
	x-=(x/10000)*10000;

	//thousands
	lcd_outch((x/1000)+'0');
	x-=(x/1000)*1000;

	//lcd_outch('.'); // old display in KHz

	//hundreds
	lcd_outch((x/100)+'0');
	x-=(x/100)*100;

	//tens
	lcd_outch((x/10)+'0');
	x-=(x/10)*10;

	//ones
	lcd_outch((x/1)+'0');
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Display RIT format
//=================================================================================================
void lcd_rit(int x)
{
	// display sign
	if(x > 0)
		lcd_outch('+');

	if(x == 0)
		lcd_outch(' ');

	if(x < 0)
	{
		lcd_outch('-');
		x = 0 - x;							// complement for display
	}

	//thousands
	lcd_outch((x/1000)+'0');
	x-=(x/1000)*1000;
	lcd_outch('.');

	//hundreds
	lcd_outch((x/100)+'0');
	x-=(x/100)*100;

	//tens
	lcd_outch((x/10)+'0');
	x-=(x/10)*10;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Display PA100 meter formats
//=================================================================================================
void lcd_meter(int x, int dp)
{
	int lz;
	lz = 0;

	if(x > 9999)
		x = 9999;							// limit to max displayable

	//thousands
	if(dp != 't')
	{
		if(x/1000 == 0)
		{
			lcd_outch(' ');					// leading zero suppress
			lz = 1;							// first zero suppressed
		}
		else
			lcd_outch((x/1000)+'0');
	}
	else
		lz = 1;
	x-=(x/1000)*1000;

	//hundreds
	if((lz == 1) && (x/100 == 0) && (dp != 2))
		lcd_outch(' ');						// leading zero suppress
	else
		lcd_outch((x/100)+'0');
	x-=(x/100)*100;
	if(dp == 2)								// PA100 meter
		lcd_outch('.');						// select decimal point place

	//tens
	lcd_outch((x/10)+'0');
	x-=(x/10)*10;
	if(dp == 1)
		lcd_outch('.');

	// units
	if(dp == 'w')
		lcd_outch('W');						// Watt meter display
	else
		lcd_outch((x/1)+'0');
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Display one BCD digit
//=================================================================================================
void lcd_putbcd(char c)
{
	if(c > 9)
		c = 9;
	lcd_outch( c + 0x30);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Display both lines
//=================================================================================================
void lcd_display_all(const char *line1, const char *line2)
{
	//lcd_clear();
	lcd_set_cur(LINE1);
	lcd_putst(line1);
	lcd_set_cur(LINE2);
	lcd_putst(line2);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Display one line
//=================================================================================================
void lcd_display_line(int row, const char *line)
{
    switch (row)
	{
		case 1: default:
			lcd_set_cur(LINE1);
		break;

		case 2:
			lcd_set_cur(LINE2);
		break;
    }
	lcd_putst(line);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set cursor according to row and column
//=================================================================================================
int cursor_row_col(int row, int col)
{
	if (col < 1) col = 1;
	if (col > 16) col = 16;

	switch (row)
	{
		case 1: default:
			return LINE1 + col - 1;
		break;

		case 2:
			return LINE2 + col - 1;
		break;
    }
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Display with set cursor
//=================================================================================================
void lcd_display_at(int row, int col, const char *line)
{
	lcd_set_cur(cursor_row_col(row, col));
	lcd_putst(line);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set cursor position according to line and row
//=================================================================================================
void lcd_cursor(int row, int col)
{
	lcd_set_cur(cursor_row_col(row, col));
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Display underline cursor
//=================================================================================================
void lcd_cursor_on(int row, int col, int on)
{
	lcd_set_cur(cursor_row_col(row, col));
	wait_lcd_rdy();
	LCD_RS = 0;								// switch command mode
	if (on)
		lcd_clk(CURON);						// display underline cursor
	else
		lcd_clk(CUROFF);					// clear underline cursor
	LCD_RS = 1;								// back to data mode
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Blink underline cursor
//=================================================================================================
void lcd_cursor_blink(int row, int col, int on)
{
	lcd_set_cur(cursor_row_col(row, col));
	wait_lcd_rdy();
	LCD_RS = 0;								// switch command mode
	if (on)
		lcd_clk(CURBLKON);					// blink underline cursor
	else
		lcd_clk(CURBLKOFF);					// no blink underline cursor
	LCD_RS = 1;								// back to data mode
}
//-------------------------------------------------------------------------------------------------

//*************************************************************************************************
//
// AD9833 DDS Driver for JUMA-TX500/136
//
// OH2NLT, Juha Niinikoski 14.01.2005
//
// Phase reg definitions corrected 19.01.2005
// Filter select flip-flop drive added 03.07.2005
// AUX output added 06.10.2005
// Flip-flop control corrected 13.10.2005
// TX500 version 09.06.2009
// Program structure modified to improve readability and maintenance - F4GCB 02-2015
//
//*************************************************************************************************

#ifndef AD9833_H
#define AD9833_H

	extern void tune_ad9833(unsigned long);		// Send tuning word to AD9833 chip
	extern void init_ad9833(void);				// Setup & start AD9833 chip

#endif

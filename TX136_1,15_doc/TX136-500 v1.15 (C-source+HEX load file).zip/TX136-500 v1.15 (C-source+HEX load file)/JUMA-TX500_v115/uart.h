///*************************************************************************************************
//
// Simple UART interface for dsPIC30F6012
// Juha Niinikoski, OH2NLT 18.05.2005
//
// Below is the code to initialize the USART
// 8 bits, 1 start and 1 stop, no error handling
// kbhit and getch added 22.05.2005
// getche added 02.06.2005
// overrun error handling added 29.08.2005
// MPLAB C30 conversion, OH2GWE 2006.10.17
// Baud Rate setup & IRQ receiver for fast baud rates 14.01.2008
// Adaptation to JUMA-PA100 board, FCY = 7,3728MHz, 07.07.2008
// UART init sequence changed 30.10.2008
// rx buffer pointer cast corrections 18.11.2008
//
// Program structure modified to improve readability and maintenance - F4GCB 02-2015
//
//*************************************************************************************************

#ifndef UART_H
#define UART_H

	extern void uart1_init(void);						// UART1 init
	extern void uart1_set_baud(int);					// Set baud rate
	extern void uart1_clear(void);						// Clear serial port, reset input buffer
	extern void uart1_put_char(char c);					// Print character
	extern unsigned char uart1_get_char(void);			// Get char from RX queue, IRQ RX system
	extern unsigned char uart1_kbhit(void);				// Return with number of available characters
	extern unsigned char uart1_get_checho(void);		// Receive character with echo
	extern unsigned long uart1_get_long(void);			// Get unsigned long
	extern unsigned char uart1_get_2hex(void);			// Get byte (2 hex characters)

#endif

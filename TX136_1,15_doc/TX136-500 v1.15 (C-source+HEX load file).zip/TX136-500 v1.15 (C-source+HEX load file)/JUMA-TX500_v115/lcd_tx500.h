//*************************************************************************************************
//
// Cheap DSP dsPICradio board LCD routines
// This is polling driver with 8-bit interface
//
// Juha Niinikoski OH2NLT 26.08.2005
//
// Modified for Digital RX hardware 12.09.2006
// MPLAB C30 version, OH2GWE, 2006.10.17
//
// IRQ mask added to LCD I/O port operations. IRQ tone output needs this protection.
// S-meter roll over corrected, interface changed to int 02.12.2006
// LCD HEX output added 09.07.2007
// PA100 temp meter degree sign added to the soft fonts #4 16.11.2008
// TX500 frequency display format added 18.08.2009
//
// Frequency display in Hz - F4GCB 08.2014
// Program structure modified to improve readability and maintenance - F4GCB 02-2015
// Add display and blink cursor - F4GCB 02-2015
// Due to some LCD displays convert Yen sign conversion to accent sign (to display back slash)
// in display null terminated string function - F4GCB 08-2015
//
//*************************************************************************************************

#ifndef LCD_H
#define LCD_H

	extern void lcd_clear(void);								// Clear selected display
	extern void lcd_init(void);									// Init selected LCD controller
	extern void lcd_set_chgen(void);							// Write bar symbols to HD44780 RAM chgen
	extern void lcd_s_meter(int);								// Draw S-meter
	extern void lcd_putch(unsigned char);						// Output character to selected display
	extern void lcd_putst(register const char *);				// Display null terminated string
	extern void lcd_display_all(const char *, const char *);	// Display both lines
    extern void lcd_display_line(int, const char *);	        // Display one line
	extern void lcd_display_at(int, int, const char *);			// Display with set cursor
	extern void lcd_cursor(int, int);							// Set cursor positiin according to line and row
	extern void lcd_cursor_on(int, int, int);					// Display underline cursor
	extern void lcd_cursor_blink(int, int, int);				// Blink underline cursor

#endif

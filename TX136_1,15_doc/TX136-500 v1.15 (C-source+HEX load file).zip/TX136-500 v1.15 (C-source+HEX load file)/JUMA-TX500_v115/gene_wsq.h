//*************************************************************************************************
//
// JUMA-TX500/136 Transmitter Controller
// F4GCB 06.2016
//
// Microchip MPLAB + C30 compiler
// MCU dsPIC30F6014A
//
// Generates a WSQ message from string
//
// Some functions rewritten to save program memory space - F4GCB 10.2020
// Harmonization of timeslots control - F4GCB 10.2020
//
//*************************************************************************************************


#ifndef WSQ_H
#define WSQ_H

	// Variables
	extern int wsq_shift;							// TX WSQ shift for DDS

	// Functions
	extern void wsq_init_beacon(const char *);		// Init WSQ beacon
	extern void wsq_char_irq(void);					// WSQ character generator 1ms IRQ
	extern char *wsq_get_display(char *);			// Return transmitted WSQ characters buffer for display

#endif

//*************************************************************************************************
//
// JUMA-TX1TX500/136 Transmitter Controller
// F4GCB 05.2015
//
// Microchip MPLAB + C30 compiler
// MCU dsPIC30F6014A
//
// Generates an OPERA message from call to a symbol/tone
//
// Acknowledgement :
// Portions of this OPERA code is derived from the work of EA5HVK
//
// Bug fixed: timer correction for waiting time to 0 - F4GCB 04.2016
// Some functions rewritten to save program memory space - F4GCB 10.2020
// Harmonization of timeslots control - F4GCB 10.2020
//
//*************************************************************************************************

#include <stdio.h>
#include <string.h>	
#include <math.h>
#include "timers_pwm.h"


// External functions -----------------------------------------------------------------------------
extern void play_opera_sym(int);				// play one OPERA symbol

// Local variables --------------------------------------------------------------------------------
static const short int pseudo_sequence[51] = {
	1,1,1,0,0,0,0,1,0,1,0,1,0,1,1,1,1,1,1,0,0,1,1,0,1,1,0,1,0,0,0,0,0,0,0,1,1,0,0,1,0,0,0,1,0,1,0,1,0,1,1
	};	
static const short int walsh_matrix[8][7] = {
	{0,0,0,0,0,0,0},{1,0,1,0,1,0,1},{0,1,1,0,0,1,1},{1,1,0,0,1,1,0},
	{0,0,0,1,1,1,1},{1,0,1,1,0,1,0},{0,1,1,1,1,0,0},{1,1,0,1,0,0,1}
	};
static short int symbol[239];			// final symbols after coding
static int symbol_idx;					// currently playing OPERA symbol list index


//=================================================================================================
// Normalize characters space A..Z 0..9 in order 0..36
//=================================================================================================
char chr_norm_opera(char bc) 
{
	char cc = 0;
  	if (bc >= '0' && bc <= '9') cc = bc - '0' + 27;
  	if (bc >= 'A' && bc <= 'Z') cc = bc - 'A' + 1;
  	if (bc >= 'a' && bc <= 'z') cc = bc - 'a' + 1;  
  	if (bc == ' ' ) cc = 0;

  	return(cc);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Generate call with 28 bits
//=================================================================================================
void generate_call(char *call, char *call_coded)
{
	int i;
	unsigned long code_sum;
	
	// the third character must always be a number
  	if (chr_norm_opera(call[2]) < 27) 
  	{
		for (i=5; i>0; i--) 
    		call[i] = call[i-1];
    	call[0] = ' ';
  	}

	// the call must always have 6 characters
	for (i=strlen(call); i<6; i++)
		call[i] = ' ';
	call[6] = 0x00;

  	code_sum = chr_norm_opera(call[0]);
  	code_sum = code_sum * 36 + chr_norm_opera(call[1]) - 1;
  	code_sum = code_sum * 10 + chr_norm_opera(call[2]) - 27;
  	code_sum = code_sum * 27 + chr_norm_opera(call[3]);
  	code_sum = code_sum * 27 + chr_norm_opera(call[4]);
  	code_sum = code_sum * 27 + chr_norm_opera(call[5]);

	// merge coded callsign into a string
	call_coded[28] = 0x00;
	call_coded[27] = (short int)((code_sum & 0x01) + 0x30);
	for (i=26; i>=0; i--)
	{
		code_sum = code_sum >> 1;
		call_coded[i] = (short int)((code_sum & 0x01) + 0x30);	
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Generate CRC
//=================================================================================================
void generate_crc(char *datas, char *crc, int length)
{
	int i, j, k;
	char buffer[strlen(datas)];
	short int wcrc[16] = {0}, byte1 = 0, byte2 = 0;

	strcpy(buffer, datas);
	for (i=0; i<strlen(datas); i++)
	{
		for (j=0; j<8; j++)
		{
			if (j>0) buffer[i] = buffer[i] >> 1;
			byte1 = buffer[i] & 0x01;
			
			byte2 = byte1 ^ wcrc[0];
			wcrc[0] = byte2 ^ wcrc[1];
			for (k=1; k<13; k++)
				wcrc[k] = wcrc[k+1];
			wcrc[13] = byte2 ^ wcrc[14];
			wcrc[14] = wcrc[15];
			wcrc[15] = byte2;
		}
	}
		
	// if msb byte crc = 0 then value at 27
	byte2 = 0;
	for (i=0; i<8; i++)
		byte2 = byte2 + (wcrc[i] * pow(2, i));
	if (byte2 == 0) byte2 = 27;
		
	// if lsb byte crc = 0 then value at 43
	byte1 = 0;
	for (i=8; i<16; i++)
		byte1 = byte1 + (wcrc[i] * pow(2, i - 8));
	if (byte1 == 0) byte1 = 43;

	// merge crc into a string
	for (i=0; i<8; i++)
	{
		if (i>0) byte2 = byte2 >> 1;
		wcrc[7-i] = byte2 & 0x01;
		
		if (i>0) byte1 = byte1 >> 1;
		wcrc[15-i] = byte1 & 0x01;
	}
	if (length > 16) length = 16;	
	for (i=16-length; i<16; i++)
		crc[i-(16-length)] = wcrc[i] + 0x30;
	crc[length] = 0x00;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// init OPERA beacon
//=================================================================================================
void opera_init_beacon(const char *call_in)
{
	int i, j, idx, data;
	char call[7], call_coded[45], crc1[17], crc2[4], vector[52];
	short int vector_to_tx[51], symbol_coding[119], symbol_interleaving[119];

	strcpy(call, call_in);
	generate_call(call,call_coded);
	generate_crc(call_coded, crc1, 16);
	generate_crc(strcat(call_coded, crc1), crc2, 3);

	// |4 bits sync| + |28 bits call| + |19 bits crc|
	strcpy(vector, "0000");
	strcat(vector, call_coded);
	strcat(vector, crc2);
		
	// encoding : |51 bits|
	for (i=0; i<51; i++)
	{
		vector_to_tx[i] = vector[i] & 0x01;				// convert ASCII to binary
		vector_to_tx[i] = vector_to_tx[i] ^ pseudo_sequence[i];
	}

	// order 8 walsh matrix codification : |119 bits|
	idx = 0;
	for (i=0; i<51; i+=3)
	{
		
		data = 0;
		for (j=0; j<3; j++)
			data = data + (vector_to_tx[i+j] << (2 - j));
		for (j=0; j<7; j++)
		{
			symbol_coding[idx] = walsh_matrix[data][j];
			idx++;
		}	
	}

	// interleaving : |119 bits|
	idx  = 0;
	for (i=0; i<7; i++)
	{
		for (j=i; j<119; j+=7)
		{
			symbol_interleaving[idx] = symbol_coding[j];
			idx++;
		}
	}

	// manchester codification :  |1| + |238 bits|
	idx = 0;
	symbol[0] = 1;
	for (i=0; i<119; i++)
	{
		if (symbol_interleaving[i] == 0)
		{
			symbol[idx+1] = 1;
			symbol[idx+2] = 0;
		}
		else
		{
			symbol[idx+1] = 0;
			symbol[idx+2] = 1;
		}
		idx+=2;	
	}

	symbol_idx = 0;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Beacon OPERA generator
// 1ms IRQ function, feed beacon OPERA symbols to the keyer code
//=================================================================================================
void opera_sym_irq(void)
{
	// run logic only when play symbol
	if(ts.on)
	{
		if (symbol_idx == 239)		// end of timeslot
		{	
			symbol_idx = 0;
			ts.on = 0;
			ts.end = 1;
		}	
		else
		{
			play_opera_sym(symbol[symbol_idx]);
			symbol_idx++;
		}
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Return transmitted OPERA symbol value for display
//=================================================================================================
char *opera_get_code(char *code)
{
	int x;

	if (ts.on)
	{
		x = symbol_idx;
		code[0] = 'S';
		code[1] = ' ';
		code[2] = ((x/100)+'0');
		x-=(x/100)*100;
		code[3] = ((x/10)+'0');
		x-=(x/10)*10;
		code[4] = (x +'0');
		code[5] = ':';
		x = symbol[symbol_idx - 1];
		code[6] = (x +'0');
	}
	else
		sprintf(code, "%.2d:%.2d:%.2d ", (ts.wait / 3600), (ts.wait % 3600) / 60, (ts.wait % 3600) % 60);

	return code;
}
//-------------------------------------------------------------------------------------------------

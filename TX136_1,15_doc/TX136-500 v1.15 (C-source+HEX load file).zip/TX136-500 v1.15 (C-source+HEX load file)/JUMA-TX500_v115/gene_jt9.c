//*************************************************************************************************
//
// JUMA-TX500/136 Transmitter Controller
// F4GCB 07.2016
//
// Microchip MPLAB + C30 compiler
// MCU dsPIC30F6014A
//
// Generates a JT9 message from 13 characters string
//
// Acknowledgement :
// The JT9 message algorithm is derived from Fortran files found in the K1JT WSJTX source code.
// Portions of the JT9 message algorithm is the work of Andy Talbot, G4JNT
// Portions of this code is derived from the work of Jason Milldrum, NT7S
//
// Some functions rewritten to save program memory space - F4GCB 10.2020
// Harmonization of timeslots control - F4GCB 10.2020
//
//*************************************************************************************************

#include <stdio.h>
#include <string.h>	
#include "timers_pwm.h"
#include "gene_wspr.h"

// External functions -----------------------------------------------------------------------------
extern void play_jt9_sym(int);			// play one JT9 symbol

// External variables -----------------------------------------------------------------------------
int jt9_shift[9];						// TX JT9 shift for DDS

// Local functions --------------------------------------------------------------------------------
static char chr_norm_jt9(char);
static void code_103_bits(char *, unsigned short *);
static int parity(unsigned long);
static void encode_conv(unsigned short *, int *);
static void interleave(int *, int *);
static void pack_gray_sync(int *);

// Local variables --------------------------------------------------------------------------------
static const int sync_vec[85] = {		// 85 bits synchronization vector
	1,1,0,0,1,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,1,1,0,0,1,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,1
	};	
static int symbol[86];					// final symbols after interleaving
static int symbol_idx;					// currently playing JT9 symbol list index


//=================================================================================================
// Normalize characters 0..9 A..Z in order 0..35 space + - . / ? in order 36..41
//=================================================================================================
char chr_norm_jt9(char bc) 
{
	char cc = 36;

  	if (bc >= '0' && bc <= '9') cc = bc - '0';
  	if (bc >= 'A' && bc <= 'Z') cc = bc - 'A' + 10;
  	if (bc >= 'a' && bc <= 'z') cc = bc - 'a' + 10; 
	if (bc == ' ' ) cc = 36;
	if (bc == '+' ) cc = 37;
	if (bc == '-' ) cc = 38;
	if (bc == '.' ) cc = 39; 
  	if (bc == '/' ) cc = 40;
	if (bc == '?' ) cc = 41;

  	return(cc);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Message combined into 103 bits code
//=================================================================================================
void code_103_bits(char *msg, unsigned short *code)
{
	int i;
	unsigned long n1 = 0, n2 = 0, n3 = 0;

	// 13 characters message
	for (i=strlen(msg); i<13; i++)
		msg[i] = ' ';
	msg[13] = 0x00;

	for (i=0; i<5; i++)
		n1 = n1 * 42 + chr_norm_jt9(msg[i]);
 	
	for (i=5; i<10; i++)
		n2 = n2 * 42 + chr_norm_jt9(msg[i]);

	for (i=10; i<13; i++)
		n3 = n3 * 42 + chr_norm_jt9(msg[i]);

	// merge bit 15 and 16 of n3 into n1 and n2, reset bit 15 of n3 
	n1 = (n1 << 1) + ((n3 >> 15) & 1);
	n2 = (n2 << 1) + ((n3 >> 16) & 1);
	n3 = n3 & 0x7FFF;

	// plain text flag
	n3 += 32768;

	// merge n1 value into array code[]
	code[3] = (n1 & 0x0F) << 4;
	n1 = n1 >> 4;
	code[2] = n1 & 0xFF; 
	n1 = n1 >> 8;
	code[1] = n1 & 0xFF;
	n1 = n1 >> 8;
	code[0] = n1 & 0xFF;

	// merge n2 value into array code[]
	code[6] = n2 & 0xFF;
	n2 = n2 >> 8;
	code [5] = n2 & 0xFF;
	n2 = n2 >> 8;
	code[4] = n2 & 0xFF;
	n2 = n2 >> 8;
	code[3] |= n2 & 0x0F;

	// merge n3 value into array code[]
	code[8] = n3 & 0xFF;
	n3 = n3 >> 8;
	code[7] = n3 & 0xFF;

	// the lowest 6 bytes are set to 0 (31 trailing zeros)
	for (i=9; i<13; i++)
		code[i] = 0;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Calculate the single bit parity (XOR)
//=================================================================================================
int parity(unsigned long value)
{
  	int bit_to_1 = 0;
  	while(value != 0)
  	{
    	bit_to_1++;
    	value &= (value - 1);
  	}

  	return (bit_to_1 & 1);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Convolutional encoding of message array code[] into a 206 bit stream
//=================================================================================================
void encode_conv(unsigned short *code, int *symbol_conv)
{
  	int byte_cnt = 0;
  	int cnt = 0;
  	int i, byte_code;
  	unsigned long shift_register = 0;

  	byte_code = code[0];
	for (i=0; i<103 ;i++)
	{
		// the 103 bits (including the 31 trailing zeros) are read out MSB first
		if (i % 8 == 0 )
		{
      		byte_code = code[byte_cnt];
      		byte_cnt++;
    	}
    	if (byte_code & 0x80) shift_register = shift_register | 1;

    	symbol_conv[cnt++] = parity(shift_register & 0xF2D05351);
    	symbol_conv[cnt++] = parity(shift_register & 0xE4613C47);

    	byte_code = byte_code << 1;
    	shift_register = shift_register << 1;
  	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Interleave reorder the 206 data bits
//=================================================================================================
void interleave(int *symbol_conv, int *symbol_inter)
{
  	int address, address_rev ,bit_pos, bit_test;
  	int cnt = 0;

  	for (address=0; address<=255; address++)
	{
    	bit_test = 1;
    	address_rev = 0;
		// bit address reverse eg address = 1 give address_rev = 128
    	for (bit_pos=0; bit_pos<8 ; bit_pos++)
		{
      		if (address & bit_test) address_rev = address_rev | (0x80 >> bit_pos);
      		bit_test = bit_test << 1;
    	}
		// interleaving process
    	if (address_rev < 206)
		{
      		symbol_inter[address_rev] = symbol_conv[cnt];
      		cnt++;
    	}
  	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Pack 3 bits into word
//=================================================================================================
void pack_gray_sync(int *symbol_inter)
{
	int i, cnt = 0;
	int symbol_pack[69];

	for (i=0; i<69; i++)
	{
		// Pack 3 bits into word
		symbol_pack[i] = (symbol_inter[cnt] & 1) << 2;
		cnt++;
		symbol_pack[i] |= (symbol_inter[cnt] & 1) << 1;
		cnt++;
		symbol_pack[i] |= symbol_inter[cnt] & 1;
		cnt++;

		// Gray coding
		symbol_pack[i] = symbol_pack[i] ^ (symbol_pack[i] >> 1);
	}

	// merge with the sync vector
	cnt = 0;
	for (i=0; i<85; i++)
	{
		if (sync_vec[i])
			symbol[i] = 0;
		else
		{	
			symbol[i] = symbol_pack[cnt] + 1;
			cnt++;
		}
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Init JT9 beacon
//=================================================================================================
void jt9_init_beacon(const char *msg_in)
{
	int i;
	char msg[14];
	unsigned short int code[13];	// 103 bits message
	int symbol_conv[206];			// symbols after convolutional encoding
	int symbol_inter[206];			// symbols after interleaving
	
	for (i=0; i<strlen(msg_in); i++)
	{
		if (i == 13) break;
		msg[i] = msg_in[i];
	}
	msg[i] = 0x00;

	code_103_bits(msg, code);
	encode_conv(code, symbol_conv);
	interleave(symbol_conv, symbol_inter);
	pack_gray_sync(symbol_inter);

	symbol_idx = 0;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Beacon JT9 generator
// 1ms IRQ function, feed beacon JT9 symbols to the keyer code
//=================================================================================================
void jt9_sym_irq(void)
{
	// run logic only when play symbol
	if(ts.on)
	{
		if (symbol_idx == 85)				// end of timeslot
		{
			symbol_idx = 0;
			ts.on = 0;
			ts.end = 1;
		}
		else
		{
			play_jt9_sym(symbol[symbol_idx]);
			symbol_idx++;
		}
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Return transmitted JT9 symbol value for display
//=================================================================================================
char *jt9_get_code(char *code)
{
	int x;

	if (ts.on)
	{
		x = symbol_idx;
		code[0] = 'S';
		code[1] = ' ';
		code[2] = ((x/10)+'0');
		x-=(x/10)*10;
		code[3] = (x +'0');
		code[4] = ':';
		x = symbol[symbol_idx - 1];
		code[5] = (x +'0');
	}
	else
		sprintf(code, "%.2d:%.2d:%.2d ", (ts.wait / 3600), (ts.wait % 3600) / 60, (ts.wait % 3600) % 60);

	return code;
}
//-------------------------------------------------------------------------------------------------

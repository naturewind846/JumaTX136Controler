//*************************************************************************************************
//
// JUMA-TX500/136 Transmitter Controller
// F4GCB 10.2020
//
// Microchip MPLAB + C30 compiler
// MCU dsPIC30F6014A
//
// Generates a FST4W message from call locator and power to a symbol/tone
// The WSPR generator is used to check call, locator and power
//
// Acknowledgement :
// The FST4W message algorithm is derived from Fortran found in the K1JT, K9AN
// and G4WJS WSJT-X 2.3.0 source code. 
// CRC generation is derived from the work of Kay Gorontzi, GHSi.de
//
//*************************************************************************************************

#ifndef FST4W_H
#define FST4W_H

	// Variables
	extern int fst4w_shift[4];												// TX FST4W shift for DDS

	// Functions
	extern void fst4w_init_beacon(const char *, const char *, const int);	// Init FST4W beacon
	extern void fst4w_sym_irq(void);										// Beacon FST4W generator
	extern char *fst4w_get_code(char *);									// Return transmitted FST4W symbol value

#endif

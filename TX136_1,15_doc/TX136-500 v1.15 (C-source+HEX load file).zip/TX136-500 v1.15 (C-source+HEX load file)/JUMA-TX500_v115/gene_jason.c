//*************************************************************************************************
//
// JUMA-TX500/136 Transmitter Controller
// F4GCB 08.2015
//
// Microchip MPLAB + C30 compiler
// MCU dsPIC30F6014A
//
// Generates a JASON message from string
//
// Function jason_char_irq modified - F4GCB 06.2016
// Some functions rewritten to save program memory space - F4GCB 10.2020
// Harmonization of timeslots control - F4GCB 10.2020
//
//*************************************************************************************************

#include <stdio.h>
#include <string.h>
#include "timers_pwm.h"	

// External functions -----------------------------------------------------------------------------
extern void play_jason_tone(int);

// External variables -----------------------------------------------------------------------------
int jason_shift;							// TX JASON shift for DDS

// Local variables --------------------------------------------------------------------------------
static short int nibble_high;				// high_order niddle ('1xxx'b)
static short int nibble_low;				// low_order niddle ('0xxx'b)
static int nibble_idx;						// currently playing start, high or low nibble
static int tone;							// tone value (0 to 16)
static int char_play;						// tone playing, 1=playing
static char b_buf[129];						// beacon test buffer
static char *b_buf_start;					// beacon text buffer start
static char *b_buf_ptr;						// beacon text buffer current pointer
static char b_buf_display[9];				// JASON code display buffer


//=================================================================================================
// Clear transmitted JASON characters buffer for display
//=================================================================================================
void jason_clear_display(void)
{
	int i;

	for (i=0; i<8; i++)
		b_buf_display[i] = ' ';
	b_buf_display[i] = 0x00;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Set transmitted JASON characters buffer for display
//=================================================================================================
void jason_set_display(unsigned char c)
{
	int i;

	// shift buffer left
	for (i=0; i<8; i++)
		b_buf_display[i] = b_buf_display[i+1];

	// insert new character
	b_buf_display[7] = c;
	b_buf_display[8] = ' ';
	
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Normalize characters (0x20 to 0x5f are allowed)
//=================================================================================================
char chr_norm_jason(char bc) 
{
	char cc = 0x20;
	if (bc >= 0x20 && bc <= 0x5F) cc = bc;
  	else if (bc >= 'a' && bc <= 'z') cc = bc - 0x20;
 
  	return(cc);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Generate nibbles for a character
//=================================================================================================
void generate_nibbles(char chr)
{
	if (chr >= 0x20 && chr <= 0x57)
	{
		switch (chr & 0x0F)
		{
			case 0x07: case 0x0F:
				nibble_high = ((chr - 0x1F) >> 3) + 0x08;
				nibble_low = 8;
			break;

			default:
				nibble_high = ((chr - 0x17) >> 3) + 0x08;
				nibble_low = (chr - 0x17) & 0x07;
			break;
		}
	}
	else if (chr >= 0x58 && chr <= 0x5F)
	{
		nibble_high = 16;
		nibble_low = (chr - 0x57) & 0x07;
	}

}
//=================================================================================================


//=================================================================================================
// Init JASON beacon
//=================================================================================================
void jason_init_beacon(const char *str)
{
	strcpy(b_buf, str);
	b_buf_start = b_buf;				// save start address
	b_buf_ptr = b_buf;					// set current pointer
	jason_clear_display();				// clear display text buffer
	char_play = 0;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// JASON character generator
// 1ms IRQ function, feed character
//=================================================================================================
void jason_char_irq(void)
{
	char c;

	// run logic only when play character active
	if (ts.on && char_play)
	{
		switch (nibble_idx)
		{
			// default center frequency
			case 3:
				tone = 8;
			break;

			// high nibble
			case 2:
				tone = (tone + nibble_high) % 17;
			break;

			// low nibble
			case 1:
				tone = (tone + nibble_low) % 17;
			break;

			case 0:
				char_play = 0;
				return;
			break;
		}
		if (nibble_idx)
		{
			play_jason_tone(tone);
			nibble_idx --;
		}	
	}
	else if (ts.on)
	{
		// get character
		c = *b_buf_ptr;

		// test end of message
		if (c == 0 || c == 0x0D)
		{
			// start over
			b_buf_ptr = b_buf_start;
			char_play = 0;							// JASON message finished
			ts.on = 0;
			ts.end = 1;
			jason_clear_display();
		}
		else										// was not end of message, decode & play
		{
			if (b_buf_ptr == b_buf)
				nibble_idx = 3;						// play default center frequency before the first character 
			else
				nibble_idx = 2;
			b_buf_ptr++;							// prepare for next character
			generate_nibbles(chr_norm_jason(c));
			char_play = 1;
			jason_set_display(c);					// run rolling characters for display
		}
	}
}
//=================================================================================================


//=================================================================================================
// Return transmitted JASON characters buffer for display 8 characters
//=================================================================================================
 char *jason_get_display(char *string)
{
	if (ts.on)
		strcpy(string, b_buf_display);
	else
		sprintf(string, "%.2d:%.2d:%.2d ", (ts.wait / 3600), (ts.wait % 3600) / 60, (ts.wait % 3600) % 60);

	return string;
}
//-------------------------------------------------------------------------------------------------

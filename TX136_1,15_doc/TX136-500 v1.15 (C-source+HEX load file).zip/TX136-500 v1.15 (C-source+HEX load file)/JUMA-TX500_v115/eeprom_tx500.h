//*************************************************************************************************
//
// JUMA-TX500 EEPROM save structures
// Juha Niinikoski, OH2NLT 24.08.2009
//
// Microchip MPLAB + C30 compiler
// MCU dsPIC30F6014A
//
// Add QRSS and DFCW modes - F4GCB 08.2014
// Add WSPR mode - F4GCB 10.2014
// Add OPERA mode and WSPR modifications - F4GCB 11.2014
// Add functions to set the datas stored in EEPROM - F4GCB 01.2015
// Add declarations from juma_tx500.c - F4GCB 02.2015
// Add CW frame parameter - F4GCB 05.2015
// Add JASON mode - F4GCB 05.2015
// Add CW identity option - F4GCB 04.2016
// Bug fixed: wrong default message in function set_cw_beacon - F4GCB 04.2016
// Bug fixed: add a character if the string is null dosn't work well - F4GCB 04.2016
// Add delay during scrolling of the character list to make the choice easier - F4GCB 04.2016
// Add SCRIPT mode - F4GCB 04.2016
// Limit EEPROM writing to preserve byte endurance - F4GCB 05.2016
// Add WSQ mode - F4GCB 06.2016
// PTT management modified - F4GCB 06.2016
// Add REMOTE mode - F4GCB 06.2016
// Improve JUMA software interface - F4GCB 06.2016
// Add JT9 mode - F4GCB 07.2016
// Add optional bi-band board control - F4GCB 11-2018
// Some functions rewritten to save program memory space - F4GCB 10.2020
// Harmonization of timeslots control - F4GCB 10.2020
// Add FST4W mode - F4GCB 10.2020
// Bug fixed : no TX FST4W shifts initialization, only when FST4W speed change , SW 1.12 - F4GCB 12.2020
// Improvement of script management - F4GCB 12.2021
// Add AFP interface via REMOTE mode, SW 1.13 - F4GCB 12.2021
//
//*************************************************************************************************

#ifndef EEPROM_H
#define EEPROM_H

	//---------------------------------------------------------------------------------------------
	// System configuration values
	//---------------------------------------------------------------------------------------------
	struct defval
	{
		long txfreq[3];					// tx frequency(Hz), for each board type or band if optional bi-band board installed
		int rfpwr;						// RF power level setting
		int preamp;						// preamp setting, off, 10dB, 20dB
		int converter;					// 3,5 / 10 MHz up converter off, on
		int mode;						// mode type: CW, QRSS, DFCW, JASON, OPERA, WSPR, FST4W, JT9, SCRIPT, REMOTE
		int cw_speed;					// CW speed (wpm)
		int cw_frame;					// CW frame 0 (one play), 1 to 5 (one TX timeslot / n timeslots)
		int cw_dot_time;				// QRSS and DFCW dot time (s)
		int cw_shift;					// shift for DFCW mode
		int cw_sidetone;				// buzzer tone
		int cw_keyer;					// keyer operating mode, 0=dot pri, 1=iambic A, 2=iambic B, 3=straight, 4=beacon
		int jason_speed;				// JASON speed 0=fast turbo, 1=fast, 2=normal turbo, 3=normal, 4=slow turbo, 5=slow
		int jason_frame;				// JASON frame 0 (one play), 1 to 5 (one TX timeslot / n timeslots)
		int wsq_frame;					// WSQ frame 0 (one play), 1 to 5 (one TX timeslot / n timeslots)
		int opera_speed;				// OPERA speed 0=OP2 to 5=OP65
		int opera_frame;				// OPERA frame 0 (one play), 1 to 5 (one TX timeslot / n timeslots)
		int wspr_speed;					// 0=WSPR-2, 1=WSPR-15 
		int wspr_frame;					// WSPR frame 0 (one play), 1 to 5 (one TX timeslot / n timeslots)
		int wspr_ndbm;					// WSPR power in dBm for max power, standard {0,3,7,10,13,...,60)
		int fst4w_speed;				// 0=FST4W-120, 1=FST4W-300, 2=FST4W-900, 3=FST4W-1800
		int fst4w_frame;				// FST4W frame 0 (one play), 1 to 5 (one TX timeslot / n timeslots)
		int jt9_speed;					// 0=JT9-1, 1=JT9-2, 2=JT9-5, 3=JT9-10, 4=JT9-30
		int jt9_frame;					// JT9 frame 0 (one play), 1 to 5 (one TX timeslot / n timeslots)
		int script_frame;				// script fframe 0 (one play), 1 (continuous)
		int rem_soft;					// software for serial remote (0=JASON normal, 1= JASON fast, 2=WSQ2, 3=AFP)
		int cwid;						// CW identiy 0=off, 1=12 wpm, 2=24 wpm
		char call[11];					// callsign
		char grid[7]; 					// locator
		int gps;						// GPS locator priority 0=off, 1=on
		int contrast;					// LCD display contrast, pwm4
		int back_light;					// LCD back light, pwm3 
		int serial_mode;				// serial interface operating mode 0=TX500, 1=Terminal, 2=GPS
		int br;							// UART1 baud rate index
		int swr_limit[4];				// SWR alarm limits for each power level
		int pa_state;					// Amplifier state, 0 = standby, 1 = oper, 2 = tune
		int mox;						// manually operated TX, 0=auto, 1=manual TX (high level), 2=RTS (low level)
		int spare_io;					// spare digital I/O state or optional bi-band board 0=TX136, 1=TX500
		int beacon_tx_on;				// beacon transmit on, 0=off, -1=continuous, positive number=rounds
		int script_on;					// script on, 0=off, -1=continuous, positive number=rounds
		unsigned int d_csum;			// checksum
	};

	typedef union
	{
		struct defval defval;
		unsigned int storage[sizeof(struct defval)/2];
	}eeprom_;
	extern eeprom_ eeprom;

	//---------------------------------------------------------------------------------------------		
	// System calibration values
	//---------------------------------------------------------------------------------------------
	struct calval
	{
		long ref_osc[5];				// Reference oscilator frequency, for each board type
		int id_mult;					// Drain current meter calibration
		int batt_mult;					// Battery voltage meter calibration
		int rev_pwr_mult;				// Reverse power meter calibration ** NOT USED **
		int fwd_pwr_mult;				// forward power meter calibration
		int	beep_len;					// tone marker length(ms)
		int cw_break_time;				// cw break timer set value
		int ms_offset;					// offset for WSPR timer
		int power_q4;					// jumper Q4 value
		unsigned int c_csum;			// checksum
	};

	typedef union
	{
		struct calval calval;
		unsigned int ee[sizeof(struct calval)/2];
	}cal_;
	extern cal_ cal;

	//---------------------------------------------------------------------------------------------
	// Global variables
	//---------------------------------------------------------------------------------------------
	extern char cw_beacon_buffer[];										// CW beacon text buffer
	extern char beacon_buffer[];										// beacon text buffer
	extern char script_buffer[];										// script buffer
	extern unsigned long tword;											// DDS tuning word
	extern unsigned long tword_hi;										// DDS word for high TX frequency
	extern float hz_bit;												// DDS resolution
	extern unsigned int fd_counter;										// counts how many times factory defaults have reloaded
	extern int band;													// define the band 1=630m, 2=2200m
	extern int msg_idx;													// message index for keying
	extern int cur_flg;													// 0 for first display, 1 after
	extern int disp_idx;												// beacon message index for keying
	extern int cw_beacon_flg;											// CW beacon buffer to save if = 1
	extern int beacon_flg;												// beacon buffer to save if = 1
	extern int script_flg;												// script buffer to save if = 1

	//---------------------------------------------------------------------------------------------
	// Global variables from juma-tx500.c
	//---------------------------------------------------------------------------------------------
	extern int board_type;												// main board type, 1=TX500, 2=TX136, 3=TX500-136, 4=TX136-500, 0=unknown
	extern unsigned int alarms;											// alarm bits
	extern int cw_active;												// cw active flag for keyer code
	extern int keyer_mode;												// keyer mode selector
	extern int key;														// TX request status
	extern char message[];												// message buffer from JUMA software
	extern int afp_ptt;													// PTT via AFP interface (1=active)
	extern int afp_serial;												// serial port AFP running (1=active)


	//---------------------------------------------------------------------------------------------
	// EEPROM storage functions
	//---------------------------------------------------------------------------------------------
	extern void save_defaults(void);									// Save defaults in EEPROM
	extern unsigned int read_defaults(void);							// Read defaults in EEPROM
	extern void save_calval(void);										// Save calibration values in EEPROM
	extern unsigned int read_calval(void);								// Read calibration values
	extern void save_cw_beacon(void);									// Save CW beacon string, one byte / address
	extern void read_cw_beacon(void);									// Read CW beacon string, one byte / address
	extern void save_beacon(void);										// Save beacon string, one byte / address
	extern void read_beacon(void);										// Read beacon string, one byte / address
	extern void save_script(void);										// Save string, one byte / address
	extern void read_script(void);										// Read string, one byte / address
	extern void set_factory_defaults(void);								// Set factory defaults for EEPROM storage


	//---------------------------------------------------------------------------------------------
	// Utility functions
	//---------------------------------------------------------------------------------------------
	extern int round_val(float);										// Round the value
	extern void beep_up_down(int *);                                    // Up/down beep


	//---------------------------------------------------------------------------------------------
	// Calculate or define new values in function eeprom values
	//---------------------------------------------------------------------------------------------
	extern void calc_hz_bit(void);										// Calculate Hz/bit from ref osc actual value
	extern void calc_tword(void);										// Calculate DDS tuning word
	extern void calc_tword_hi(void);									// Calculate DDS word for high TX frequency
	extern void freq_band(void);										// Define frequency according to the band
	extern void calc_cw_period(void);									// Calculate time value for the keyer logic
	extern void calc_morse_shift(void);									// Calculate TX MORSE shift for DDS
	extern void calc_jason_shift(int);									// Calculate the TX JASON shift for DDS
	extern void calc_wsq_shift(void);									// Calculate the TX WSQ shift for DDS
	extern void calc_wspr_shifts(void);									// Calculate the TX WSPR shifts for DDS
	extern void calc_fst4w_shifts(void);								// Calculate the TX FST4W shifts for DDS
	extern void calc_jt9_shifts(void);									// Calculate the TX JT9 shifts for DDS
	extern void calc_sidetone(void);									// Calculate sideone

			
	//---------------------------------------------------------------------------------------------
	// Write access to system configuration values
	//---------------------------------------------------------------------------------------------
	extern void set_frequency(long, int, int, int);            			// Set frequency (eeprom.defval.txfreq)
	extern void set_tx_power(int, int, int, int);                       // Set TX power (eeprom.defval.rfpwr)
	extern void set_pa_state(int, int, int, int);                       // Set operating mode (eeprom.defval.pa_state)
	extern void set_preamp(int, int, int, int);                         // Set RF preamp state (eeprom.defval.preamp)
	extern void set_converter(int, int, int, int);                      // Set RX converter state (eeprom.defval.converter)
	extern int set_mode(int, int, int, int);                           	// Set mode (eeprom.defval.mode)
	extern void set_band(int, int, int, int);                           // Set band (eeprom.defval.spare_io)
	extern void set_frame(int, int, int, int, int);						// Set mode frame (eeprom.defval.xxx_frame)
	extern void set_cw_speed(int, int, int, int);                       // Set CW speed (eeprom.defval.cw_speed)
	extern void set_dot_time(int, int, int, int);                       // Set dot time for QRSS and DFCW (eeprom.defval.cw_dot_time)
	extern void set_cw_shift(int, int, int, int);                       // Set CW shift for DFCW (eeprom.defval.cw_shift)
	extern void set_jason_speed(int, int, int, int);					// Set JASON speed (eeprom.defval.jason_speed)
	extern void set_opera_speed(int, int, int, int);                    // Set OPERA speed (eeprom.defval.opera_speed)
	extern void set_wspr_speed(int, int, int, int);                     // Set WSPR speed (eeprom.defval.wspr_speed)
	extern void set_wspr_ndbm(int, int, int, int);       	    		// Set WSPR power in dBm (eeprom.defval.wspr_ndbm)
	extern void set_fst4w_speed(int, int, int, int);                    // Set FST4W speed (eeprom.defval.fst4w_speed)
	extern void set_jt9_speed(int, int, int, int);                     	// Set JT9 speed (eeprom.defval.jt9_speed)
	extern void set_script_frame(int, int, int, int);					// Set script frame (eeprom.defval.script_frame)
	extern int set_script_delay(int, int, int);							// Set script delay time (counter.script)
	extern void set_rem_soft(int, int, int, int);						// set software for serial remote (eeprom.defval.com_soft)
	extern void set_cwid(int, int, int, int);							// set CW identification mode (eeprom.defval.cwid)
	extern void set_call(char *, int);									// Set callsign (eeprom.defval.call)
	extern void key_call(int, int,  int);								// Key callsign (eeprom.defval.call)
	extern void check_call(void);										// Check callsign (eeprom.defval.call)
	extern void set_grid(char *, int);									// Set locator (eeprom.defval.grid)
	extern void key_grid(int, int,  int);								// Key locator (eeprom.defval.grid)
	extern void check_grid(void);										// Check locator (eeprom.defval.grid)
	extern void set_gps(int, int, int, int);							// Set GPS locator (eeprom.defval.gps)
	extern void set_cw_sidetone(int, int, int, int);					// Set CW side tone (eeprom.defval.cw_sidetone)
	extern void set_cw_keyer(int, int, int, int);                     	// Set keyer mode (eeprom.defval.cw_keyer)
	extern void set_contrast(int, int, int, int);						// Set LCD contrast (eeprom.defval.contrast)
	extern void set_back_light(int, int, int, int);						// Set LCD back light (eeprom.defval.back_light)
	extern void set_serial_mode(int, int, int, int);					// Set UART1 serial mode (eeprom.defval.serial_mode)
	extern void set_baud_rate(int, int, int, int);						// Set UART1 baud rate(eeprom.defval.br)
	extern void set_swr_limit(int, int, int, int);						// Set SWR alarm trip points (eeprom.defval.swr_limit[])
	extern int set_mox(int, int, int, int);								// Set auto or PTT operated TX (eeprom.defval.mox)
	extern void set_spare_io(int, int, int, int);                       // Set SPARE I/O (eeprom.defval.spare_io)
	extern void set_beacon_tx(int, int);								// Set beacon transmit (eeprom.defval.beacon_tx_on)
	extern void set_script_on(int, int);								// Set script on (eeprom.defval.script_on)
	extern void set_cw_beacon(char *, int, int);						// Set CW beacon message (cw_beacon_buffer)
	extern void key_cw_beacon(int, int,  int);							// Key CW beacon message (cw_beacon_buffer)
	extern void set_beacon(char *, int, int);							// Set beacon message (beacon_buffer)
	extern void key_beacon(int, int,  int);								// Key beacon message (beacon_buffer)
	extern void set_message(char *, int);								// Set message from JUMA software
	extern void set_script(char *, int);								// Set script (script_buffer)
	extern void key_script(int, int,  int);								// Key script (script_buffer)


	//---------------------------------------------------------------------------------------------		
	// Write access to system calibration values
	//---------------------------------------------------------------------------------------------
	extern void set_cal_oscillator(int, int, int, int);					// Set local oscillator calibration value (cal.calval.ref_osc)
	extern void set_cal_id(int, int, int, int);							// Set drain current scaling calibration value (cal.calval.id_mult)
	extern void set_cal_batt(int, int, int, int);						// Set battery voltage calibration value (cal.calval.batt_mult)
	extern void set_cal_fwr_pwr(int, int, int, int);					// Set forward power scaling calibration value (cal.calval.fwd_pwr_mult)
	extern void set_cal_beep(int, int, int, int);						// Set beep length calibration value (cal.calval.beep_len)
	extern void set_cal_cw_break(int, int, int, int);					// Set CW break period calibration value (cal.calval.cw_break_time)
	extern void set_cal_ms_offset(int, int, int, int);					// Set milliseconds counter offset calibration value (cal.calval.ms_offset)
	extern void set_cal_power_q4(int, int, int, int);					// Set jumper Q4 (automatic power on) value (cal.calval.power_q4)


	//---------------------------------------------------------------------------------------------
	// External functions from juma-tx500.c
	//---------------------------------------------------------------------------------------------
	extern int check_io_board_type(void);								// Check I/O board type
	extern int get_out_pwr(void);										// Get output power
	extern int get_swr(void);											// Get SWR
	extern unsigned long meas_batt_volt(void);							// Measure battery voltage
	extern long meas_id(void);											// Measure drain current	
	extern char *get_info(char *);										// Get TX500/136 info						
	extern void set_sync_timer(int, int, int, int, int, int);			// Set synchronization timer
	extern void init_beacon(void);										// Init beacon
	extern void init_message(void);										// Init message					
	extern void set_beacon_on_off(int, int);							// Set beacon on/off
	extern void set_script_on_off(int, int);							// Set script on/off
	extern void run_script(void);										// Run script
	
#endif

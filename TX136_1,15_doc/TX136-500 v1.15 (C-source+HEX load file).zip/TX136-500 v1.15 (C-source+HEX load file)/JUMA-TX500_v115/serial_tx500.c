//*************************************************************************************************
//
// JUMA-TX136/TX500 protocol
//
// Juha Niinikoski, OH2NLT 09.09.2009
//
// Beacon repeat count logic added 14.09.2009
// very slow CW keyer speed, downto 0.1 wpm, S command changed to 3-digits 20.09.2009
// beacon message '=' and '?' character behaviour corrected 17.10.2009
// Add QRSS and DFCW modes - F4GCB 08.2014
// Add WSPR mode - F4GCB 10.2014
// Program structure modified to improve readability and maintenance - F4GCB 02-2015
// Add UART2 for optional GPS NMEA - 05.2015
// Add OPERA mode - F4GCB 05.2015
// Add JASON mode - F4GCB 08.2015
// Add CW identity option - F4GCB 04.2016
// Bug fixed: character '=' accepted in QRSS/DFCW/JASON beacon message - F4GCB 04.2016
// Add SCRIPT mode - F4GCB 04.2016
// Add JASON software interface - F4GCB 06.2016
// Add WSQ2 software interface - F4GCB 06.2016
// Improve JUMA software interface - F4GCB 06.2016
// Serial sets and queries redefined - F4GCB 06.2016
// Add JT9 mode - F4GCB 07.2016
// Serial commands diseabled when tx on or script delay time, except the command '=B0' (TX OFF) - F4GCB 08.2016
// Locator accuracy improved with taking hundredth of minutes in account from GPS - F4GCB 08-2016
// Add optional bi-band board control - F4GCB 11-2018
// Some functions rewritten to save program memory space - F4GCB 10.2020
// Add FST4W mode - F4GCB 10.2020
// Bug fixed : DDS stopped during TX in REMOTE mode when Power or Display buttons on - F4GCB 12.2021
// During a tune only the command =B0 (TX OFF) is available - F4GCB 12.2021
// Improvement of script management - F4GCB 12.2021
// Add AFP interface via REMOTE mode, SW 1.13 - F4GCB 12.2021
//
//*************************************************************************************************

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "juma-tx500.h"
#include "eeprom_tx500.h"
#include "timers_pwm.h"
#include "serial_tx500.h"
#include "uart.h"
#include "uart2.h"

// External variables -----------------------------------------------------------------------------
extern int jason_shift;							// TX JASON shift for DDS
extern int wsq_shift;							// TX WSQ shift for DDS

// Local definitions ------------------------------------------------------------------------------
#define CMD_BUF_SIZE 20							// for full size command message
#define MSG_GPS_SIZE 75							// for GPS NMEA message

// Local variables --------------------------------------------------------------------------------
static char cmd_buf[CMD_BUF_SIZE];				// command buffer										/
static int cmd_buf_idx = 0;						// command buffer fill pointer				    		|	
static char bcn_buf[CW_BEACON_BUFFER_SIZE+3];	// beacon message buffer								|
static int bcn_buf_idx = 0;						// beacon message buffer fill index						|> command serial buffer
static int rd_bcn_msg_flag = 0;					// instead of command interpreter read beacon message   |
static char s_buf[SCRIPT_BUFFER_SIZE+3];		// script buffer										|
static int s_buf_idx = 0;						// script buffer fill index								|
static char *s_buf_ptr;							// script buffer current pointer						|
static char *s_goto_ptr;						// script buffer goto pointer							/
static int gps_status = 0;						// GPS status 0=nok				/
static char msg_gps[MSG_GPS_SIZE];				// GPS message buffer			|
static int msg_gps_idx = 0;						// GPS buffer fill pointer		|> GPS serial buffer
static char grid4[5];							// GPS grid 4					|
static char grid6[7];							// GPS grid 6					/
static unsigned long tone_afp;					// AFP tone
static unsigned long tone_dds;					// DDS tone
static int script_loop;							// number of loops has executed in the script


//*************************************************************************************************
// TX136/500 serial set functions
//*************************************************************************************************

//=================================================================================================
// Terminate CW beacon message collect, we have received CR
//=================================================================================================
void collect_cw_beacon(void)
{
	bcn_buf[bcn_buf_idx] = 0x00;
	set_cw_beacon(bcn_buf, 0, 1);
	init_beacon();						// init beacon logic, need this if beacon running
	rd_bcn_msg_flag = 0;
	cur_flg = 0;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Terminate beacon message collect, we have received CR
//=================================================================================================
void collect_beacon(void)
{
	bcn_buf[bcn_buf_idx] = 0x00;
	set_beacon(bcn_buf, 0, 1);
	init_beacon();						// init beacon logic, need this if beacon running
	rd_bcn_msg_flag = 0;
	cur_flg = 0;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Terminate message collect, we have received CR
//=================================================================================================
void collect_message(void)
{
	bcn_buf[bcn_buf_idx] = 0x00;
	set_message(bcn_buf, 1);
	init_message();						// init message logic, need this if message running
	rd_bcn_msg_flag = 0;
	cur_flg = 0;
}
//-------------------------------------------------------------------------------------------------


//*************************************************************************************************
// TX136/500 serial commands functions
//*************************************************************************************************

//=================================================================================================
// Convert number from command buffer
//=================================================================================================
static unsigned long get_number(int nb_idx)
{
	unsigned long number = 0;
	int i = nb_idx;			// msb of the number

	while(i < cmd_buf_idx)
	{
		number = (number * 10) + (cmd_buf[i] & 0x0F);
		i++;
	}

	return number;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Clear buffer
//=================================================================================================
void clear_buffer(void)
{
	int x;

	// clear whole buffer
	for(x=0; x<CMD_BUF_SIZE; x++)
	// clear only CMD bytes
	//for(x=0; x<9; x++)
		cmd_buf[x] = 0;
	cmd_buf_idx = 0;
	rd_bcn_msg_flag = 0;
	// reset also buffer data collect index
	bcn_buf_idx = 0;
	s_buf_idx = 0;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Filter no operation characters, return = 1 if no op
//=================================================================================================
int filter_nop_char(char c)
{
	//if((c==0x00) || (c==0x0A) || (c==0x20) || (c==0x2C) || (c==0x2E))
	// we need space and comma and period for beacon string
	if((c==0x00) || (c==0x0A))
		return 1;
	else
		return 0;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Parse TX500/TX136 message or script
//=================================================================================================
void serial_tx500(int script)
{
	char c;
	char buffer[250];
	long value;

	// process one character at time
	//if(kbhit())
	// process all at once, better for high speed
	while((!script && uart1_kbhit()) || script)
	{
		if (script) c = 0x0D;				// put the buffer ready
		else c = uart1_get_char();			// save character

		// discard nop characters
		if(filter_nop_char(c))
			return;

		// capture start sync with action characters, when collecting beacon buffer accept them
		if(c == '=' || c == '?')
			// normal mode & command received
			if(rd_bcn_msg_flag == 0 && cmd_buf_idx > 2 )
				clear_buffer();

		// check if buffer ready, interpret message - CR = message ready, action
		if(c == 0x0D)
		{
			switch(cmd_buf[0])
			{
				// send values
				case '?':
					// select command
					switch(cmd_buf[1])
					{
						case 'A': case 'a':
							printf("=A%i\n\r", eeprom.defval.preamp);
						break;
	
						case 'B': case 'b':
							printf("=B%i\n\r", eeprom.defval.beacon_tx_on);
						break;
	
						case 'C': case 'c':
							printf("=C%i\n\r", eeprom.defval.converter);
						break;

						case 'D': case 'd':
							printf("=D%.3d\n\r", eeprom.defval.cw_dot_time);
						break;

						case 'E': case 'e':
							printf("=E%s\n\r", cw_beacon_buffer);
						break;

						case 'F': case 'f':
							printf("=F%.6ld\n\r", eeprom.defval.txfreq[band]);
						break;

						case 'G': case 'g':
							printf("=G%i\n\r", eeprom.defval.mode);
						break;

						case 'H': case 'h':
							printf("=H%s\n\r", beacon_buffer);
						break;

						case 'I': case 'i':
							// select sub command
							switch(cmd_buf[2])
							{
								case 'B': case 'b':
									printf("=IB%ld\n\r", meas_batt_volt());
								break;
	
								case 'D': case 'd':
									printf("=ID%ld\n\r", meas_id());
								break;

								case 'I': case 'i': default:
									printf("=II%s\n\r", get_info(buffer));
								break;

								case 'P': case 'p':
									printf("=IP%d\n\r", get_out_pwr());
								break;

								case 'S': case 's':
									printf("=IS%d\n\r", get_swr());
								break;
							}
						break;

						case 'J': case 'j':
							// select sub command
							switch(cmd_buf[2])
							{
								case 'F': case 'f':
									printf("=JF%.2d\n\r", eeprom.defval.jason_frame);
								break;

								case 'S': case 's':
									printf("=JS%i\n\r", eeprom.defval.jason_speed);
								break;
							}
						break;

						case 'K': case 'k':
							printf("=K%i\n\r", eeprom.defval.cw_keyer);
						break;

						case 'L': case 'l':
							printf("=L%s\n\r", eeprom.defval.grid);
						break;

						case 'N': case 'n':
							printf("=N%.4d\n\r", counter.sync);
						break;

						case 'O': case 'o':
							// select sub command
							switch(cmd_buf[2])
							{
								default:
									printf("=O%i\n\r", eeprom.defval.pa_state);
								break;

								case 'F': case 'f':
									printf("=OF%.1d\n\r", eeprom.defval.opera_frame);
								break;

								case 'S': case 's':
									printf("=OS%.1d\n\r", eeprom.defval.opera_speed);
								break;
							}
						break;

						case 'P': case 'p':
							printf("=P%i\n\r", eeprom.defval.rfpwr);
						break;

						case 'Q': case 'q':
							// select sub command
							switch(cmd_buf[2])
							{
								default:
									printf("=Q%.2d\n\r", eeprom.defval.cw_frame);
								break;

								case 'F': case 'f':
									printf("=QF%.2d\n\r", eeprom.defval.wsq_frame);
								break;
							}
						break;

						case 'R': case 'r':
							// select sub command
							switch(cmd_buf[2])
							{
								default:
									printf("=R%.2d\n\r", eeprom.defval.cw_shift);
								break;

								case 'S': case 's':
									printf("=RS%.1d\n\r", eeprom.defval.rem_soft);
								break;
							}
						break;

						case 'S': case 's': 
							// select sub command
							switch(cmd_buf[2])
							{
								default:
									printf("=S%.3d\n\r", eeprom.defval.cw_speed * 10);
								break;

								case 'D': case 'd':
									printf("=SD%.4ld\n\r", counter.script);
								break;

								case 'F': case 'f':
									printf("=SF%.1d\n\r", eeprom.defval.script_frame);
								break;
							}
						break;

						case 'T': case 't':
							// select sub command
							switch(cmd_buf[2])
							{
								default:
									printf("=T%i\n\r", eeprom.defval.mox);
								break;

								case 'F': case 'f':
									printf("=TF%.1d\n\r", eeprom.defval.jt9_frame);
								break;

								case 'S': case 's':
									printf("=TS%.1d\n\r", eeprom.defval.jt9_speed);
								break;
							}
						break;

						case 'U': case 'u':
							printf("=U%s\n\r", script_buffer);
						break;

						case 'V': case 'v':
							printf("=V%i\n\r", eeprom.defval.gps);
						break;

						case 'W': case 'w':
							// select sub command
							switch(cmd_buf[2])
							{
								default:
									printf("=W%s\n\r", grid6);
								break;
	
								case 'F': case 'f':
									printf("=WF%.1d\n\r", eeprom.defval.wspr_frame);
								break;

								case 'G': case 'g':
									printf("=WG%.1d\n\r", eeprom.defval.fst4w_frame);
								break;

								case 'P': case 'p':
									printf("=WP%.2d\n\r", eeprom.defval.wspr_ndbm);
								break;

								case 'S': case 's':
									printf("=WS%.1d\n\r", eeprom.defval.wspr_speed);
								break;

								case 'T': case 't':
									printf("=WT%.1d\n\r", eeprom.defval.fst4w_speed);
								break;
							}
						break;

						case 'X': case 'x':
							printf("=X%i\n\r", eeprom.defval.spare_io);
						break;

						case 'Y': case 'y':
							printf("=Y%i\n\r", eeprom.defval.cwid);
						break;

						case 'Z': case 'z':
							printf("=Z%s\n\r", eeprom.defval.call);
						break;
					}
					// clear for next round
					clear_buffer();
				break;

				// set values
				case '=':

					// when the tx is on or wait timeslot or script wait time only the command =B0 (TX OFF) is available
					if (CW || eeprom.defval.beacon_tx_on || counter.script)
					{
						switch(cmd_buf[1])
						{
							case 'B': case 'b':
								if (cmd_buf[2] == '0')
								{
									set_beacon_on_off(0, 1);
									if (eeprom.defval.script_on) set_script_on_off(0, 1);
								}
							break;
						}
				
						// clear for next round
						clear_buffer();
					}

					else
					{ 
						// select command
						switch(cmd_buf[1])
						{
							case 'A': case 'a':
								set_preamp(get_number(2), 1, 0, 0);
							break;

							case 'B': case 'b':
								// select sub command
								if (script)
								{
									value = get_number(2);
									if (value > 99) value = 99;
									set_beacon_on_off(value, 1);
								}
								else
								{
									switch(cmd_buf[2])
									{
										case 'T': case 't':
											set_beacon_on_off(-1, 1);	// run a message transmission with the juma-tx136-500 control software
										break;

										case '1':
											if (eeprom.defval.mode == MODE_SCRIPT)
												set_script_on_off(1, 1);
											else
												set_beacon_on_off(1, 1);
											break;
										break;
									}
								}
							break;

							case 'C': case 'c':
								set_converter(get_number(2), 1, 0, 0);
							break;

							case 'D': case 'd':
								set_dot_time(get_number(2), 1, 0, 0);
							break;

							case 'E': case 'e':
								collect_cw_beacon();
								save_cw_beacon();
							break;

							case 'F': case 'f':
								value = get_number(2);
								// check the band according to the new frequency
								if (board_type == TX500_136_TYPE || board_type == TX136_500_TYPE)
								{
									if (value <= TX136_HI_TX_FREQ && value >= TX136_LOW_TX_FREQ && band == TX500_TYPE)
										set_band(BAND_136, 1, 0, 0);
									if (value <= TX500_HI_TX_FREQ && value >= TX500_LOW_TX_FREQ && band == TX136_TYPE)
										set_band(BAND_500, 1, 0, 0);
								}
								set_frequency(value, 1, 0, 1);
							break;
	
							case 'G': case 'g':
								set_mode(get_number(2), 1, 0, 0);
								if (!eeprom.defval.script_on)
									set_pa_state (0, 1, 0, 0);			// force standby state
							break;
	
							case 'H': case 'h':
								collect_beacon();
								save_beacon();
							break;

							case 'J': case 'j':
								// select sub command
								switch(cmd_buf[2])
								{
									case 'F': case 'f':
										set_frame(MODE_JASON, get_number(3), 1, 0, 0);
									break;
		
									case 'S': case 's':
										set_jason_speed(get_number(3), 1, 0, 0);
									break;
								}
							break;

							case 'K': case 'k':
								set_cw_keyer(get_number(2), 1, 0, 0);
							break;

							case 'L': case 'l':
								set_grid(cmd_buf + (2 * sizeof(char)), 1);
								cur_flg = 0;
							break;

							case 'M': case 'm':
								collect_message();
							break;

							case 'N': case 'n':
								if (counter.gps == 0)
									set_sync_timer(get_number(2), 1, 0, 0, 0, 0);
							break;

							case 'O': case 'o':
								switch(cmd_buf[2])
								{
									default:
										set_pa_state(get_number(2), 1, 0, 0);
									break;

									case 'F': case 'f':
										set_frame(MODE_OPERA, get_number(3), 1, 0, 0);
									break;

									case 'S': case 's':
										set_opera_speed(get_number(3), 1, 0, 0);
									break;
								}
							break;
	
							case 'P': case 'p':
								set_tx_power(get_number(2), 1, 0, 0);
							break;
	
							case 'Q': case 'q':
								switch(cmd_buf[2])
								{
									default:
										set_frame(MODE_CW, get_number(2), 1, 0, 0);
									break;

									case 'F': case 'f':
										set_frame(MODE_WSQ, get_number(3), 1, 0, 0);
									break;
								}
							break;

							case 'R': case 'r':
								switch(cmd_buf[2])
								{
									default:
										set_cw_shift(get_number(2), 1, 0, 0);
									break;

									case 'S': case 's':
										set_rem_soft(get_number(2), 1, 0, 0);
									break;
								}
							break;
	
							case 'S': case 's':
								switch(cmd_buf[2])
								{
									default:
										set_cw_speed(get_number(2) / 10, 1, 0, 0);	// compatibility with the juma-tx136-500 control software
									break;
	
									case 'D': case 'd':
										if (script) set_script_delay(get_number(3), 1, 0);
									break;

									case 'F': case 'f':
										set_frame(MODE_SCRIPT, get_number(3), 1, 0, 0);
									break;

									case 'H': case 'h':
										if (script)
										{
											// loop into script if no gps available
											if (set_script_delay(get_number(3), 3, 0))
												s_buf_ptr = s_buf_ptr - cmd_buf_idx;
										}
									break;

									case 'L': case 'l':
										if (script)
											s_goto_ptr = s_buf_ptr;
									break;
							
									case 'N': case 'n':
										if (script)
										{
											script_loop ++;
											if (get_number(3) > script_loop && script_loop < 1000)
												s_buf_ptr = s_goto_ptr;
											else
												script_loop = 0;
										}
									break;

									case 'S': case 's':
										if (script)		// force shutdown
										{
											set_pa_state(STATE_STBY, 1, 0, 0);
											save_defaults();
											PWR_ON = 0;
											for (;;) {};
										}		
									break;

									case 'T': case 't':
										if (script) set_script_delay(get_number(3), 2, 0);
									break;
								}
							break;

							case 'T': case 't':
								// select sub command
								switch(cmd_buf[2])
								{
									default:
										if (set_mox(get_number(2), 1, 0, 0));
											set_pa_state (0, 1, 0, 0);		// force standby state
									break;
	
									case 'F': case 'f':
										set_frame(MODE_JT9, get_number(3), 1, 0, 0);
									break;

									case 'S': case 's':
										set_jt9_speed(get_number(3), 1, 0, 0);
									break;
								}
							break;

							case 'U': case 'u':
								s_buf[s_buf_idx] = 0x00;
								set_script(s_buf, 0);
								cur_flg = 0;
								save_script();   
							break;

							case 'V': case 'v':
								set_gps(get_number(2), 1, 0, 0);
							break;

							case 'W': case 'w':
								// select sub command
								switch(cmd_buf[2])
								{
									case 'F': case 'f':
										set_frame(MODE_WSPR, get_number(3), 1, 0, 0);
									break;

									case 'G': case 'g':
										set_frame(MODE_FST4W, get_number(3), 1, 0, 0);
									break;

									case 'P': case 'p':
										set_wspr_ndbm(get_number(3), 1, 0, 0);
									break;

									case 'S': case 's':
										set_wspr_speed(get_number(3), 1, 0, 0);
									break;

									case 'T': case 't':
										set_fst4w_speed(get_number(3), 1, 0, 0);
									break;
								}
							break;

							case 'X': case 'x':
								switch (board_type)
								{
									case TX500_TYPE:
									case TX136_TYPE:
										set_spare_io(get_number(2), 1, 0, 0);
									break;

									case TX500_136_TYPE:
									case TX136_500_TYPE:
										set_band(get_number(2), 1, 0, 0);
									break;
									}
							break;

							case 'Y': case 'y':
								set_cwid(get_number(2), 1, 0, 0);
							break;

							case 'Z': case 'z':
								set_call(cmd_buf + (2 * sizeof(char)), 1);
								cur_flg = 0;
							break;
						}
						// clear for next round
						clear_buffer();
					}
				break;

				// not known
				default:
					// clear for next round
					clear_buffer();
				break;
			}
		}

		else
		{
			// special case ('=' as character message), collect to the message buffer
			if (cmd_buf[0] == '=' && cmd_buf[1] == 'E')
			{
				bcn_buf[bcn_buf_idx] = c;
				if(bcn_buf_idx < CW_BEACON_BUFFER_SIZE)
					bcn_buf_idx++;
			}
			else if (cmd_buf[0] == '=' && cmd_buf[1] == 'H')
			{
				bcn_buf[bcn_buf_idx] = c;
				if(bcn_buf_idx < BEACON_BUFFER_SIZE)
					bcn_buf_idx++;
			}
			else if (cmd_buf[0] == '=' && cmd_buf[1] == 'M')
			{
				bcn_buf[bcn_buf_idx] = c;
				if(bcn_buf_idx < MSG_BUFFER_SIZE)
					bcn_buf_idx++;
			}
			else if(cmd_buf[0] == '=' && cmd_buf[1] == 'U')
			{
				rd_bcn_msg_flag = 1;
				s_buf[s_buf_idx] = c;
				if(s_buf_idx < SCRIPT_BUFFER_SIZE)
					s_buf_idx++;
			}
			else
			{
				cmd_buf[cmd_buf_idx] = c;
				if(cmd_buf_idx < CMD_BUF_SIZE-1)
					cmd_buf_idx++;
			}
		}
		if (script) script = 0;
	}
}
//-------------------------------------------------------------------------------------------------


//*************************************************************************************************
// Script functions
//*************************************************************************************************

//=================================================================================================
// Init script
//=================================================================================================
void serial_script_init(const char *str)
{
	strcpy(s_buf, str);
	s_buf_ptr = s_buf;					// set current pointer
	s_goto_ptr = s_buf;;				// set goto pointer
	script_loop = 0;					// one loop by default
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// This function is called continuously from main when script is on
// init must be done before
// return 1 when script is finished
//=================================================================================================
int serial_script_run(void)
{
	char c;

	clear_buffer();		// a serial command could be cancelled if this function is called during the keybording !
	do
	{
		// get character
		c = *s_buf_ptr;

		// test of the command sequence
		if ((c == '=' || c == 0)&& cmd_buf_idx)
		{
			serial_tx500(1);					// play the script
			return 0;
		}
		// test end of script
		else if (c == 0 || c == 0x0D)
		{
			// start over
			s_buf_ptr = s_goto_ptr;
			return 1;
		}
		// get command character
		else
		{
			cmd_buf[cmd_buf_idx] = c;
			if(cmd_buf_idx < CMD_BUF_SIZE-1)
				cmd_buf_idx++;
			s_buf_ptr++;
		}
	}
	while(1);

	return 0;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Get script next command position
//=================================================================================================
int get_script_next(void)
{
	return (int)(s_buf_ptr - s_buf);
}
//-------------------------------------------------------------------------------------------------


//*************************************************************************************************
// GPS functions
//*************************************************************************************************

//=================================================================================================
// Clear buffer GPS
//=================================================================================================
void clear_gps(void)
{
	int x;

	// clear whole buffer
	//for(x=0; x<MSG_GPS_SIZE; x++)
	// clear only the sentence type bytes
	for(x=0; x<6; x++)
		msg_gps[x] = 0;
	msg_gps_idx = 0;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Define locator in function of longitude and latitude
//=================================================================================================
void serial_grid (float longitude, float latitude, char *grid)
{
	float symb1, symb2, symb3, symb4, symb5, symb6;

	symb1 = ((180 + longitude) / 20);
    symb2 = ((90 + latitude) / 10);
    symb3 = (symb1 - (int)symb1) * 10;
    symb4 = (symb2 - (int)symb2) * 10;
    symb5 = (symb3 - (int)symb3) * 24;
  	symb6 = (symb4 - (int)symb4) * 24;

    grid[0] = (int)symb1 + 65;
    grid[1] = (int)symb2 + 65;
    grid[2] = (int)symb3 + 48;
    grid[3] = (int)symb4 + 48;
    grid[4] = (int)symb5 + 65;
    grid[5] = (int)symb6 + 65;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Parse GPS NMEA message - UART 1 = 0, UART 2 = 1
//=================================================================================================
void serial_gps(int uart)
{
	char c;
	const char gps_start[] = {"$GPGGA"}; 			// starting GPS message
	int i, idx, cnt, minutes, seconds, millis;
	int sep[15];
	float longitude, latitude, minute;

	// process all at once, better for high speed
	while((!uart && uart1_kbhit()) || (uart && uart2_kbhit()))
	{
		if (uart)
			c = uart2_get_char();
		else
			c = uart1_get_char();

		// check if buffer ready, interpret message - LF = message ready, action
		if(c == 0x0A)
		{
      		cnt = 0;

			// check the GPS
			if (msg_gps[0] == '$')
				gps_status = 1;
			else
				gps_status = 0;

			// werify the received message starts with $GPGGA
      		for (i=0; i<6; i++)
        		if (msg_gps[i] == gps_start[i])
          			cnt++;

			// message awaited
			if (cnt == 6)
			{
				idx = 0;
				for (i=6; i<msg_gps_idx; i++)
				{
					// check the position separators
					if (msg_gps[i] == ',')
					{
						sep[idx] = i;
						idx++;
					}
				}

				// valid datas
				if (idx == 14 && msg_gps[sep[5]+1] != '0')
				{
					// disable TMR3 tick irq
					_T3IE = 0;

					// define WSPR timer
        			counter.gps_hour = (msg_gps[sep[0]+1] - 48) * 10 + msg_gps[sep[0]+2] - 48;
        			minutes = (msg_gps[sep[0]+3] - 48) * 10 + msg_gps[sep[0]+4] - 48;
        			seconds = (msg_gps[sep[0]+5] - 48) * 10 + msg_gps[sep[0]+6] - 48;
					millis = (msg_gps[sep[0]+8] - 48) * 100 + (msg_gps[sep[0]+9] - 48) * 10;

					// some GPS with hundredth only
					if (sep[1] > sep[0]+10)
						millis = millis + (msg_gps[sep[0]+10] - 48);

					// set synchronization timer
					set_sync_timer((minutes * 60) + seconds, 0, 1, millis, 0, 0);

					// enable TMR3 tick irq
					_T3IE = 1;

					// define locator
					longitude = (msg_gps[sep[3]+1] - 48) * 100 + (msg_gps[sep[3]+2] - 48) * 10 + msg_gps[sep[3]+3] - 48;
					minute = (msg_gps[sep[3]+4] - 48) * 10 + (msg_gps[sep[3]+5] - 48) + (msg_gps[sep[3]+7] - 48) * 0.1 + 
							(msg_gps[sep[3]+8] - 48) * 0.01;
					longitude = longitude + minute / 60;
					if (msg_gps[sep[4]+1] == 'W')
						longitude = -longitude;
					latitude = (msg_gps[sep[1]+1] - 48) * 10 + msg_gps[sep[1]+2] - 48;
					minute = (msg_gps[sep[1]+3] - 48) * 10 + (msg_gps[sep[1]+4] - 48) + (msg_gps[sep[1]+6] - 48) * 0.1 + 
							(msg_gps[sep[1]+7] - 48) * 0.01;
					latitude = latitude + minute / 60;
					if (msg_gps[sep[2]+1] == 'S')
						latitude = -latitude;
					serial_grid(longitude, latitude, grid6);
					strncpy(grid4, grid6, 4);

					// datas not used
					/*satellite = (msg_buf[sep[6]+1] - 48) * 10 + msg_buf[sep[6]+2] - 48;*/
				}
			}

			// clear for next round
			clear_gps();
		}

		// collect data to the command buffer
		else
		{
			msg_gps[msg_gps_idx] = c;
			if(msg_gps_idx < MSG_GPS_SIZE-1)
				msg_gps_idx++;
		}
	}

	// switch baud rate if no GPS message
	if (!gps_status)
	{
		uart2_set_baud();
		strcpy(grid6, "NO GPS");
		strcpy(grid4, "NGPS");
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Get GPS grid 4
//=================================================================================================
char *get_gps_grid4(char *string)
{
	return strcpy(string, grid4);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Get GPS grid 6
//=================================================================================================
char *get_gps_grid6(char *string)
{
	return strcpy(string, grid6);
}
//-------------------------------------------------------------------------------------------------


//*************************************************************************************************
// JASON software interface
//*************************************************************************************************

//=================================================================================================
// Parse JASON software message
//=================================================================================================
void serial_jason(int ptt)
{
	char tone;

	if (ptt)
	{
		while(uart1_kbhit())
		{
			tone = uart1_get_char();		// save character
	
			// read native format : 0 to 16
			if(tone >= 0x00 && tone <= 0x10)
			{
				counter.busy = -1;
				set_tx_on(jason_shift * (int)tone);
			}
		}
	}
	else
		stop_keyer();
}
//-------------------------------------------------------------------------------------------------


//*************************************************************************************************
// WSQ2 software interface
//*************************************************************************************************

// setup.txt for WSQ2 software
/*
WSQ2 setup for serial comms and PTT

1
9600
N
8
0
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
*/

//=================================================================================================
// Parse WSQ2 software message
//=================================================================================================
void serial_wsq2(int ptt)
{
	char c;
	int tone;

	if (ptt)
	{
		while(uart1_kbhit())
		{
			c = uart1_get_char();			// save character

			// discard nop characters
			if(filter_nop_char(c))
				return;

			// check if buffer ready, interpret message - CR = message ready, action
			if(c == 0x0D)
			{
				tone = get_number(0);		// read code 0 (no tx) and 1 to 33 (tones)
				clear_buffer();
				counter.busy = -1;
				if (!tone)
					set_spot_on(0);
				else
					set_tx_on(wsq_shift * tone);
			}
			else
			{
				cmd_buf[cmd_buf_idx] = c;
				if(cmd_buf_idx < CMD_BUF_SIZE-1)
					cmd_buf_idx++;
			}
		}
	}
	else
		stop_keyer();
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Parse AFP interface message
//=================================================================================================
void serial_afp(void)
{
	char c;

	while(uart1_kbhit())
	{
		c = uart1_get_char();			// save character

		// discard nop characters
		if(filter_nop_char(c))
			return;

		// check if buffer ready, interpret message - CR = message ready, action
		if(c == 0x0D)
		{
			switch(cmd_buf[0])
			{
				case 'T': case 't':
					tone_afp = get_number(1);	// tone in mHz
 					if (tone_afp >= 190000 && tone_afp <= 2510000)	// available tone : 200 to 2500 Hz with 10 Hz tolerance
					{
						counter.busy = -1;
						tone_dds = ((float)tone_afp / 500) / hz_bit;
						set_tx_on(tone_dds);
						afp_ptt = 1;
					}
				break;
	
				case 'R': case 'r':
					afp_ptt = 0;
					stop_keyer();
				break;	
			}
			clear_buffer();
		}
		else
		{
			cmd_buf[cmd_buf_idx] = c;
			if(cmd_buf_idx < CMD_BUF_SIZE-1)
				cmd_buf_idx++;
		}
	}
}


//=================================================================================================
// Return the DDS tone according to the AFP tone
//=================================================================================================
 char *afp_get_tone(char *string)
{
	sprintf(string, "+%7.2f ", (double)tone_dds * ((double)hz_bit / 2));

	return string;
}
//-------------------------------------------------------------------------------------------------

//*************************************************************************************************
//
// JUMA-TX136/TX500 protocol
//
// Juha Niinikoski, OH2NLT 09.09.2009
//
// Beacon repeat count logic added 14.09.2009
// very slow CW keyer speed, downto 0.1 wpm, S command changed to 3-digits 20.09.2009
// beacon message '=' and '?' character behaviour corrected 17.10.2009
// Add QRSS and DFCW modes - F4GCB 08.2014
// Add WSPR mode - F4GCB 10.2014
// Program structure modified to improve readability and maintenance - F4GCB 02-2015
// Add UART2 for optional GPS NMEA - 05.2015
// Add OPERA mode - F4GCB 05.2015
// Add JASON mode - F4GCB 08.2015
// Add CW identity option - F4GCB 04.2016
// Add SCRIPT mode - F4GCB 04.2016
// Add JASON software interface - F4GCB 06.2016
// Add WSQ2 software interface - F4GCB 06.2016
// Improve JUMA software interface - F4GCB 06.2016
// Serial sets and queries redefined - F4GCB 06.2016
// Add JT9 mode - F4GCB 07.2016
// Serial commands diseabled when tx on, except the command '=B0' (TX OFF) - F4GCB 08.2016
// Locator accuracy improved with taking hundredth of minutes in account fropm GPS - F4GCB 08-2016
// Improvement of script management - F4GCB 12.2021
// Add AFP interface via REMOTE mode, SW 1.13 - F4GCB 12.2021
//
//*************************************************************************************************

#ifndef SERIAL
#define SERIAL

	extern void clear_buffer(void);					// Clear buffer
	extern void serial_tx500(int);					// Parse TX500/TX136 message or script
	extern void serial_script_init(const char*);	// Init script
	extern int serial_script_run(void);				// Script logic, called continously from main
	extern int get_script_next(void);				// Get script next command position
	extern void serial_gps(int);					// Parse GPS NMEA message - UART 1 = 0, UART 2 = 1
	extern char *get_gps_grid4(char *);				// Get GPS grid 4
	extern char *get_gps_grid6(char *);				// Get GPS grid 6		
	extern void serial_jason(int);					// Parse JASON software message
	extern void serial_wsq2(int);					// Parse WSQ2 software message
	extern void serial_afp(void);					// Parse AFP interface message
	extern char *afp_get_tone(char *);				// Return the DDS tone according to the AFP tone
	
#endif

//*************************************************************************************************
//
// JUMA-TX500/136 Transmitter Controller
// F4GCB 10.2014
//
// Microchip MPLAB + C30 compiler
// MCU dsPIC30F6014A
//
// Generates a WSPR message from call locator and power to a symbol/tone
//
// Acknowledgement :
// The WSPR message algorithm is derived from Fortran and C files found in the K1JT WSPR source code. 
// Portions of the WSPR message algorithm is the work of Andy Talbot, G4JNT
// Portions of this code is derived from the work of Gene Marcus, W3PM
//
// Functions rewritten - F4GCB 02.2015
// Program structure modified to improve readability and maintenance - F4GCB 02-2015
// Add compound call and grid 6 checking - F4GCB 06-2016
// Some functions rewritten to save program memory space - F4GCB 10.2020
// Harmonization of timeslots control - F4GCB 10.2020
//
//*************************************************************************************************

#include <stdio.h>
#include <string.h>	
#include "timers_pwm.h"

// External functions -----------------------------------------------------------------------------
extern void play_wspr_sym(int);			// play one WSPR symbol

// Local functions --------------------------------------------------------------------------------
static char chr_norm_wspr(char); 
static unsigned long code_call(char *);
static unsigned long code_grid_pwr(char *, int);
static void code_50_bits(unsigned long, unsigned long, unsigned short *);
static int parity(unsigned long);
static void encode_conv(unsigned short *, int *);
static void interleave_sync(int *);

// External variables -----------------------------------------------------------------------------
int wspr_shift[4];						// TX WSPR shift for DDS

// Local variables --------------------------------------------------------------------------------
static const int sync_vec[162] = {		// 162 bits synchronization vector
	1,1,0,0,0,0,0,0,1,0,0,0,1,1,1,0,0,0,1,0,0,1,0,1,1,1,1,0,0,0,0,0,0,0,1,0,0,1,0,1,0,0,0,0,0,0,1,0,
  	1,1,0,0,1,1,0,1,0,0,0,1,1,0,1,0,0,0,0,1,1,0,1,0,1,0,1,0,1,0,0,1,0,0,1,0,1,1,0,0,0,1,1,0,1,0,1,0,
  	0,0,1,0,0,0,0,0,1,0,0,1,0,0,1,1,1,0,1,1,0,0,1,1,0,1,0,0,0,1,1,1,0,0,0,0,0,1,0,1,0,0,1,1,0,0,0,0,
  	0,0,0,1,1,0,1,0,1,1,0,0,0,1,1,0,0,0
	};	
static int symbol[162];					// final symbols after interleaving
static int symbol_idx;					// currently playing WSPR symbol list index


//=================================================================================================
// Test the callsign validity (0=standard call, 1=compound call)
//=================================================================================================
int wspr_check_call(char *call, int type)
{
	int i, pos = 0;
	char test[11];

	if (strlen(call) > 10)
		return 0;
	strcpy(test, call);

	// compound callsign
	if (type)
	{
		// find the only slash position
		for (i=0; i<strlen(test); i++)
			if (test[i] == '/')
				if (!pos) pos = i;
	
		// prefix
		if (pos && pos < 4)
		{
			// one or three characters consisting of 0-9, A-Z or a-z
			for (i=0; i<pos; i++)
				if ((test[i] < '0' || test[i] > '9') && (test[i] < 'A' || test[i] > 'Z') && (test[i] < 'a' || test[i] > 'z'))
					return 0;
			for (i=0; i<strlen(test)-pos-1; i++)
				test[i] = test[i+pos+1];
			test[i] = 0x00;
		}
		// suffix
		else if (pos)
		{
			// one character consisting of 0-9, A-Z or a-z if one suffix character
			if (pos == strlen(test) - 2)
			{
				for (i=pos+1; i<strlen(test); i++)
					if ((test[i] < '0' || test[i] > '9') && (test[i] < 'A' || test[i] > 'Z') && (test[i] < 'a' || test[i] > 'z'))
						return 0;
			}
			// two characters consisting of 0-9 two suffix characters
			else if (pos == strlen(test) - 3)
			{
				for (i=pos+1; i<strlen(test); i++)
					if (test[i] < '0' || test[i] > '9')
						return 0;
			}
			else
				return 0;
			test[pos] = 0x00;
		}
	}
	
	// standard call
	if (strlen(test) > 6 || strlen(test) < 4)
		return 0;

	// the second or third character must always be a number (WSPR protocol)
	if (test[2] >= '0' && test[2] <= '9')
		pos = 2;
	else if (test[1] >= '0' && test[1] <= '9')
		pos = 1;
	else
		return 0;

	// 3 characters max after number
	if (strlen(test) > pos + 4)
		return 0;

	// if second character is a number
	if (pos == 1)
	{
		// start with one characters consisting of A-Z or a-z
		if ((test[0] < 'A' || test[0] > 'Z') && (test[0] < 'a' || test[0] > 'z'))
			return 0;
	}

	// if third character is a number
	if (pos == 2)
	{
		// start with one characters consisting of of 0-9, A-Z or a-z
		if ((test[0] < '0' || test[0] > '9') && (test[0] < 'A' || test[0] > 'Z') && (test[0] < 'a' || test[0] > 'z'))
			return 0;
		// continue with one characters consisting of A-Z or a-z
		if ((test[1] < 'A' || test[1] > 'Z') && (test[1] < 'a' || test[1] > 'z'))
			return 0;
	}

	// last characters which must be A-Z or a-z
	for (i=pos+1; i<strlen(test); i++)
		if ((test[i] < 'A' || test[i] > 'Z') && (test[i] < 'a' || test[i] > 'z'))
			return 0;

	return 1;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Test grid validity (0=grid 4, 1=grid 6)
//=================================================================================================
 int wspr_check_grid(char *grid, int type)
{
	int i;

	if ((!type && strlen(grid) != 4) || (type && strlen(grid) !=6))
		return 0;

	for (i=0; i<strlen(grid); i++)
		switch (i)
		{
			// two characters consisting of A-R or a-r
			case 0: case 1:
				if ((grid[i] < 'A' || grid[i] > 'R') && (grid[i] < 'a' || grid[i] > 'r')) 
					return 0; 
			break;

			// two characters consisting of 0-9
			case 2: case 3:
				if (grid[i] < '0' || grid[i] > '9') 
					return 0; 
			break;

			// two characters consisting of A-Z or a-z
			case 4: case 5:
				if ((grid[i] < 'A' || grid[i] > 'Z') && (grid[i] < 'a' || grid[i] > 'z')) 
				return 0; 
			break;
		}

	return 1;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Normalize characters 0..9 A..Z space in order 0..36
//=================================================================================================
char chr_norm_wspr(char bc ) 
	{
	char cc = 36;
  	if (bc >= '0' && bc <= '9') cc = bc - '0';
  	if (bc >= 'A' && bc <= 'Z') cc = bc - 'A' + 10;
  	if (bc >= 'a' && bc <= 'z') cc = bc - 'a' + 10;  
  	if (bc == ' ' ) cc = 36;

  	return(cc);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Coding of callsign
//=================================================================================================
unsigned long code_call(char *call)
{
	int i;
	unsigned long code;

	// the third character must always be a number
  	if (chr_norm_wspr(call[2]) > 9) 
  	{
		for (i=5; i>0; i--) 
    		call[i] = call[i-1];
    	call[0] = ' ';
  	}

  	code = chr_norm_wspr(call[0]);
  	code = code * 36 + chr_norm_wspr(call[1]);
  	code = code * 10 + chr_norm_wspr(call[2]);
  	code = code * 27 + chr_norm_wspr(call[3])-10;
  	code = code * 27 + chr_norm_wspr(call[4])-10;
  	code = code * 27 + chr_norm_wspr(call[5])-10;

	return code;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Coding of grid and power level
//=================================================================================================
unsigned long code_grid_pwr(char *grid, int ndbm)
{
	unsigned long code;

  	// coding of grid
  	code = 179 - 10 * (chr_norm_wspr(grid[0]) - 10) - chr_norm_wspr(grid[2]);
  	code = code * 180 + 10 * (chr_norm_wspr(grid[1]) - 10) + chr_norm_wspr(grid[3]);

	// add coding of power level
	return code * 128 + ndbm + 64;
}
//------------------------------------------------------------------------------------------------


//=================================================================================================
// Code1 and code2 truncated and combined into 50 bits code
//=================================================================================================
void code_50_bits(unsigned long code1, unsigned long code2, unsigned short *code)
{
	int i;
	unsigned long temp;

  	// merge coded callsign into message array code[]
  	temp = code1;
	code[0]= (temp >> 20) & 0xFF;
  	temp = code1;
	code[1]= (temp >> 12) & 0xFF;
  	temp = code1;
	code[2]= (temp >> 4) & 0xFF;
  	temp = code1;
	code[3]= (temp << 4) & 0xFF;

	// merge coded grid and power level into message array code[]
  	temp = code2;
	code[3]= code[3] + ((0x0F & temp >> 18) & 0xFF);
  	temp = code2;
	code[4]= (temp >> 10) & 0xFF;
  	temp = code2;
	code[5]= (temp >> 2) & 0xFF;
  	temp = code2;
	code[6]= (temp << 6) & 0xFF;

	// the lowest 6 bytes are set to 0
	for (i=7; i<12; i++)
		code[i] = 0;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Calculate the single bit parity (XOR)
//=================================================================================================
int parity(unsigned long value)
{
  	int bit_to_1 = 0;
  	while(value != 0)
  	{
    	bit_to_1++;
    	value &= (value - 1);
  	}

  	return (bit_to_1 & 1);
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Convolutional encoding of message array code[] into a 162 bit stream
//=================================================================================================
void encode_conv(unsigned short *code, int *symbol_conv)
{
  	int byte_cnt = 0;
  	int cnt = 0;
  	int i, byte_code;
  	unsigned long shift_register = 0;

  	byte_code = code[0];
	for (i=0; i<81 ;i++)
	{
		// the 81 bits (including the 31 trailing zeros) are read out MSB first
		if (i % 8 == 0 )
		{
      		byte_code = code[byte_cnt];
      		byte_cnt++;
    	}
    	if (byte_code & 0x80) shift_register = shift_register | 1;

    	symbol_conv[cnt++] = parity(shift_register & 0xF2D05351);
    	symbol_conv[cnt++] = parity(shift_register & 0xE4613C47);

    	byte_code = byte_code << 1;
    	shift_register = shift_register << 1;
  	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Interleave reorder the 162 data bits and and merge table with the sync vector
//=================================================================================================
void interleave_sync(int *symbol_conv)
{
  	int address, address_rev ,bit_pos, bit_test;
  	int cnt = 0;

  	for (address=0; address<=255; address++)
	{
    	bit_test = 1;
    	address_rev = 0;
		// bit address reverse eg address = 1 give address_rev = 128
    	for (bit_pos=0; bit_pos<8 ; bit_pos++)
		{
      		if (address & bit_test) address_rev = address_rev | (0x80 >> bit_pos);
      		bit_test = bit_test << 1;
    	}
		// interleaving process
    	if (address_rev < 162 )
		{
      		symbol[address_rev] = sync_vec[address_rev] + 2 * symbol_conv[cnt];
      		cnt++;
    	}
  	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Standard dBm WSPR (types 0 3 7 10 13 17 ... 60)
//=================================================================================================
int wspr_ndbm(int dbm)
{
	int nu[10] = {0,-1,1,0,-1,2,1,0,-1,1};
	int dbm_std;

	dbm_std = dbm;
	
	if (dbm_std < 0)
		dbm_std = 0;
	if (dbm_std > 60)
		dbm_std = 60;

	return dbm_std + nu[dbm_std % 10];
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Init WSPR beacon
//=================================================================================================
void wspr_init_beacon(const char *call_in, const char *grid_in, const int ndbm_in)
{
	int ndbm;
	char call[13], grid[7];
	unsigned short int code[11];	// 50 bits callsign grid and power level compressed
	int symbol_conv[162];			// symbols after convolutional encoding

	strcpy(call, call_in);
	strcpy(grid, grid_in);
	ndbm = wspr_ndbm(ndbm_in);

	code_50_bits(code_call(call), code_grid_pwr(grid, ndbm), code);
  	encode_conv(code, symbol_conv);
  	interleave_sync(symbol_conv);
		
	symbol_idx = 0;
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Beacon WSPR generator
// 1ms IRQ function, feed beacon WSPR symbols to the keyer code
//=================================================================================================
void wspr_sym_irq(void)
{
	// run logic only when play symbol
	if(ts.on)
	{
		if (symbol_idx == 162)				// end of timeslot
		{
			symbol_idx = 0;
			ts.on = 0;
			ts.end = 1;
		}
		else
		{
			play_wspr_sym(symbol[symbol_idx]);
			symbol_idx++;
		}
	}
}
//-------------------------------------------------------------------------------------------------


//=================================================================================================
// Return transmitted WSPR symbol value for display
//=================================================================================================
char *wspr_get_code(char *code)
{
	int x;

	if (ts.on)
	{
		x = symbol_idx;
		code[0] = 'S';
		code[1] = ' ';
		code[2] = ((x/100)+'0');
		x-=(x/100)*100;
		code[3] = ((x/10)+'0');
		x-=(x/10)*10;
		code[4] = (x +'0');
		code[5] = ':';
		x = symbol[symbol_idx - 1];
		code[6] = (x +'0');
	}
	else
		sprintf(code, "%.2d:%.2d:%.2d ", (ts.wait / 3600), (ts.wait % 3600) / 60, (ts.wait % 3600) % 60);

	return code;
}
//-------------------------------------------------------------------------------------------------

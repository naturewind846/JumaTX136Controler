//
// JUMA-TRX2 SPI 1 driver for 74HC595 ahift registers
// Two 74HC595 can be connected to cascade
//
// Juha Niinikoski, OH2NLT 03.12.2006
//
// 
// MPLAB C30 version
//
// MCU dsPIC30F6014A
//
// Quiet bus test to reduce main board interference 23.12.2006


#include "juma-tx500.h"			// JUMA-TRX2 hardware specific definitions

#define SPI1_LATCH _LATB2		// strobe signal in I/O pins

unsigned int spi_rx_data;		// rx data
int spi_rx_data_available;		// data available flag

static unsigned int old_dta;	// previously transmitted data.


// init SPI 1 system
void init_spi1(void)
	{
	SPI1_LATCH = 0;				// set Slave Latch to idle state, lov
	spi_rx_data_available = 0;
	old_dta = 0;	
	SPI1CON = 0x0439;			// bit clk falling edge, clock/32
	SPI1STAT = 0x8000;			// SPI1 on
	_SPI1IF = 0;
	_SPI1IE = 1;				// enable SPI TX ready irq
	}

// send data
void exchg_data_spi1(unsigned int dta)
	{
	if(dta != old_dta)			// transmit only if data changed
		{
    	while(SPI1STATbits.SPITBF);  // wait until 'SPITBF' bit is cleared
		SPI1BUF = dta;
		old_dta = dta;
		}
	}


// tx ready, generate latch pulse

void __attribute__((interrupt)) _SPI1Interrupt(void)
	{
	int x;
	SPI1_LATCH = 1;				// generate latch strobe pulse __-__, rising edge sensitive
	_SPI1IF = 0;				// clear IRQ flag

	if(SPI1STATbits.SPIRBF)
		{
		spi_rx_data = SPI1BUF;	// save RX data
		spi_rx_data_available = 1;	// data available
		}

	SPI1_LATCH = 0;				// back to idle state
	}

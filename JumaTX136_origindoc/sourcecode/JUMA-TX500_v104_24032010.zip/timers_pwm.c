//
// dsPIC30 timers PWM DAC for JUMA-TX500
// Juha Niinikoski, OH2NLT 16.08.2009
//
// Microchip C30 compiler conversion
//
// JUMA-PATX500 timer & pwm system
//
// Timer & PWM unit usage

// TMR1 is used for freq ctr
// TMR2 is used for tone generation, IRQ driven system, RD1/OC2 = tone out
// TMR3 is used for 1ms timer tick IRQ and for LCD PWM dac timebase
// OC3 output is for LCD back light control
// OC4 output is for LCD contrast
// OC3 and OC4 are connected to TMR3
//
// TMR4 
// TMR5 used for delays (separate module)

// encoder simulatot repeat logic added 13.08.2008
// hardware tone generator with TMR2 & OC2 18.08.2009
// Buzzer notone play cleaned, no click 25.08.2009

//#define TICK_PERIOD 7500		// 1ms tick
//#define TICK_PERIOD (FCY/1000)	// 1ms tick

#include "juma-tx500.h"
#include "morse_characters.h"


#define MAX_FREQ_DELAY 50;			// peak hold delay
unsigned int band_query_timer;		// band data query timer 
 
static int blink_counter; 			// blink cycle (ms)
static unsigned int ms_counter;		// 1s divider, 1000ms counter
unsigned int tone_counter; 			// beep tone length (ms)
long busy_counter;					// tone generator busy(ms), busy if != 0

static int key_down;				// key down flag for straight mode tone generator

static int iambic_flag;				// last played, 0=dot, 1=dash
static int dot;						// DOT RS flip flop, follow paddle logic, 0=pressed
static int dash;					// DASH RS flip flop
int keyer_ptt;						// keyer generated PTT signal

long cw_break_time;					// set value for the timer
long cw_break_timer;				// cw break timer
unsigned int cw_period;				// CW period(ms)

// external variables

extern int cw_active;				// cw active flag for keyer code
extern int keyer_mode;				// 0=dot priority, 1=iambic A,  2=iambic B, 3=straight & tune
extern int beacon_transmit;			// beacon starten in "Transmit mode", beacon end returns TX500 mode
extern int old_keyer;				// temporary storage for Beacon Transmit command
extern int old_pa_state;

unsigned int t_stamp;				// 1ms free running time stamp
//int cmd_timeout;					// RS232 command timeout, 0 = timeout, negative values = state flags.

int blink;							// alarm blink flag
unsigned int long_push;				// long push timer, count from set value to zero, global visibility

int decay_counter;					// power meter slow decay

// Encoder simulator
static unsigned int up;				// UP button shift register
static unsigned int dn;				// DOWN button shift register

static int up_pushed;				// up pushed status
static int dn_pushed;				// dn pushed status
static int rep_up;					// repeat timers (ms)
static int rep_dn;
static int rep_up_dly;				// repeat start delay (ms)
static int rep_dn_dly;

int enc;							// encoder accu

// Frequency tune repeat counters
int volatile start_frep;			// start repeat
int volatile frep;					// repeat timer

// external variables
extern int seconds;					// free running second counter
extern int sidetone;				// calculated sidetone timer set value

extern unsigned long tword;					// DDS tuning word
extern 	void tune_ad9833(unsigned long);	// set DDS

// EEPROM structures
#include "tx500_eeprom.h"			// get EEPROM structure definitions

extern union
	{
	struct defval defval;
	unsigned int storage[sizeof(struct defval)/2];
	}eeprom;

extern union
	{
	struct calval calval;
	unsigned int ee[sizeof(struct calval)/2];
	}cal;


// Simulate encoder with UP / DN buttons
// read encoder
int encoder_get(void)
	{
	int temp;

	temp = enc;
	enc = 0;
	return(temp);
	}



// PTT out handling
void set_ptt_out(void)
	{
	if(eeprom.defval.mox == 0)	// auto PTT
		{
		if(keyer_ptt != 0)		// TX On
			{
			ANT_RLY	 = 1;		// switch antenna for TX
			PTT_OUT_1 = 1;
			PTT_OUT_2 = 1;		// activate PTT OUT signal (PA100 fan control transistors)
			}
		else					// TX off
			{
			ANT_RLY	 = 0;
			PTT_OUT_1 = 0;
			PTT_OUT_2 = 0;		// PTT OUT signal off
			}
		}

	else						// manual (MOX) PTT
		{
		if(PTT_IN)				// MOX TX On
			{
			ANT_RLY	 = 1;		// switch antenna for TX
			PTT_OUT_1 = 1;
			PTT_OUT_2 = 1;		// activate PTT OUT signal (PA100 fan control transistors)
			}
		else					// TX off
			{
// off without any conditions
			ANT_RLY	 = 0;
			PTT_OUT_1 = 0;
			PTT_OUT_2 = 0;	// PTT OUT signal off

			}
		}
	}


// TX handling
void tx_on(void)				// TX on sequence
	{
	keyer_ptt = 1;				// keyer generated PTT signal, 1 = true
	tune_ad9833(tword);			// set / start DDS
	BUFFER_ON = 1;				// DDS outbut buffer on
	CW = 1;						// carrier on (keying)
	}

void spot_on(void)				// SPOT on
	{
	tune_ad9833(tword);			// set / start DDS
	BUFFER_ON = 1;				// DDS outbut buffer on
	CW = 1;						// carrier on (keying)
	}

void tx_off(void)				// TX or spot off
	{
	CW = 0;
	BUFFER_ON = 0;
	tune_ad9833(0);				// stop DDS
	keyer_ptt = 0;				// keyer generated PTT signal, 0 = false

	if(beacon_transmit != 0)	// beacon was on in "Transmit mode", restore TX500 state
		{
		eeprom.defval.pa_state	= old_pa_state;	// save current state
		eeprom.defval.keyer	= old_keyer;
		beacon_transmit = 0;	// reset flag
		}
	}


// init timer & PWM system
void init_timers_pwm(void)
	{
	cw_break_time = cal.calval.cw_break_time;
	keyer_ptt = 0;				// keyer generated PTT signal, 0 = false

	ms_counter = 1000;
	OC3CON = 0;					// first turn off the module if it was on
	OC4CON = 0;

// LCD PWM DAC setup
	OC3RS = 100;				// some small value for back light
	OC3R = 100;
	OC3CON = 0x000E;			// use TMR3, OC3 = PWM mode

	OC4RS = 2000;				// something for contrast to make display visible
	OC4R = 2000;
	OC4CON = 0x000E;			// use TMR3, OC4 = PWM mode

	PR3 = TICK_PERIOD - 1;		// set PWM cycle, TMR3 period register, 1000Hz/1ms
	T3CONbits.TON = 1;			// start TMR3
	_T3IE = 1;					// enable TMR3 tick irq

// Hardware tone generator TMR2 & OC2
	TONE_TRIS = 0;				// enable output
	OC2RS = 2;					// something for contrast to make display visible
	OC2R = 2;
	OC2CON = 0x0006;			// use TMR2, OC2 = PWM mode
	T2CONbits.TON = 0;			// stop TMR2
	_T2IE = 0;					// disable TMR2 tick irq
	}


// PWM set functions

void set_pwm3_dac(unsigned int pwm)		// LCD back light
	{
	OC3RS = pwm;
	}

void set_pwm4_dac(unsigned int pwm) 	// LCD contrast
	{
	OC4RS = pwm;
	}



// Tone set functions
void tone_on(int tone)					// set tone, set value = 7,5MHz / tone(Hz) * 2
	{
//	if(tone != NOTONE)					// do not start tone if notone asked
	if(tone < LOWTONE)					// play only if pitch high enough
		{
		TMR2 = 0;
		PR2 = (tone << 1) - 1;			// set tone cycle period
		OC2RS = tone;					// set 50% PWM
		OC2R = tone;
		T2CONbits.TON = 1;				// start tone timer
		}
	}


void tone_off(void)						// stop tone generator
	{
	T2CONbits.TON = 0;					// stop tone timer
	}


void beep(int tone, unsigned int duration)
	{
	if(busy_counter == 0 && duration > 0)	// start tone only if tone generator free & duration specified
		{
		tone_counter = duration;			// set tone length
		tone_on(tone);						// set tone pitch & start play
		}
	}


// Keyer code

void play_dot(void)						// Turn TX on & generate dot
	{
	iambic_flag = 0;					// remember last played
	if(cw_active != 0)
		{
		cw_break_timer = cw_break_time * cw_period;	// TX on break time
		tx_on();						// RF out on
		}
	else
		{
		cw_break_timer = cw_break_time * cw_period;	// TX on break time
		spot_on();						// DDS on, SPOT
		}
	if(eeprom.defval.cw_sidetone != CW_SIDETONE_OFF)	// no sound if sidetone off
		beep(sidetone, cw_period);		// start tone
	else
		beep(NOTONE, cw_period); 		// start tone not audible tone
	busy_counter = 2 * cw_period;		// set busy period
	}

void play_dash(void)
	{
	iambic_flag = 1;					// remember last played
	if(cw_active != 0)
		{
		cw_break_timer = cw_break_time * cw_period;	// TX on break time
		tx_on();						// RF out on
		}
	else
		{
		cw_break_timer = cw_break_time * cw_period;	// TX on break time
		spot_on();						// DDS on, SPOT
		}
	if(eeprom.defval.cw_sidetone != CW_SIDETONE_OFF)	// no sound if sidetone off
		beep(sidetone, (3 * cw_period)); // start tone
	else
		beep(NOTONE, (3 * cw_period)); // start tone not audible tone
	busy_counter = 4 * cw_period;		// set busy period
	}


// IRQ code
// 1ms Tick timer
void __attribute__((interrupt)) _T3Interrupt(void)
	{
	int x;

	_T3IF = 0;
	IRQ_TEST = 1;		// timing test

// tone duration counter
	if(tone_counter != 0)
		{
		tone_counter--;
		if(tone_counter == 0)
			{
			tone_off();					// run stop with half cycle logic
			CW = 0;						// RF carrier off
			}
		}

	if(cw_break_timer != 0)				// run cw break timer
		{
		cw_break_timer--;
		if(cw_break_timer == 0)
			{
			tx_off();					// RF off
			}
		}


	if(busy_counter != 0)				// decrement CW tone busy timer if active
		{
		busy_counter--;
		
		if(busy_counter == 0)			// mark ready
			{
			if(iambic_flag == 0)		// was DOT
				dot = 1;				// reset dot
			else						// was dash
				dash = 1;				// reset dash
			}
		}

// run beacon morse generator
	morse_char_irq();

// read paddle switches, set dot/dash RS flip flops
	if(keyer_mode == KEYER_IAMBIC_B)	// Iambic B, flip set only
		{
		if(DOT == 0)					// Set RS/ flip flop
			dot = 0;

		if(DASH == 0)
			dash = 0;
		}
	else								// Iambic A or other mode, flip flop set/reset
		{
		if(DOT == 0)					// Set/Reset RS flip flop
			dot = 0;
		else
			dot = 1;

		if(DASH == 0)
			dash = 0;
		else
			dash = 1;
		}

// run keyer logic
		switch(keyer_mode)							// select keyer operation
			{
			case KEYER_DOT_PRI: 					// dot priority
			if(DOT == 0 && busy_counter == 0)		// start only if not sound going
				play_dot();
			else
				{
				if(DASH == 0 && busy_counter == 0)
					play_dash();
				}
			break;


			case KEYER_IAMBIC_A:	case KEYER_IAMBIC_B:							// iambic mode A & B, sample from dot/dsah RS flip flop
			if(iambic_flag != 0)					// last played was dash, test DOT contact first
				{
				if(dot == 0 && busy_counter == 0)	// start only if not sound going
					play_dot();
				else
					{
					if(dash == 0 && busy_counter == 0)
						play_dash();
					}
				}
			else									// last played was dot, test DASH contact first
				{
				if(dash == 0 && busy_counter == 0)	// start only if not sound going
					play_dash();
				else
					{
					if(dot == 0 && busy_counter == 0)
						play_dot();
					}
				}
			break;


			case KEYER_STRAIGHT:					// straight mode
			if(DOT == 0)							// key down, I/O bit
				{
				if(key_down == 0)					// do this only if key was up
					{
					key_down = 1;					// set key down status
					if(eeprom.defval.cw_sidetone != CW_SIDETONE_OFF)	// no sound if sidetone off
						tone_on(sidetone);			// keep on starting side tone generator
					}

				if(cw_active != 0)					// tx only if CW mode selected
					{
					cw_break_timer = cw_break_time * cw_period;	// TX on break time
					tx_on();
					}
				else
					{
					cw_break_timer = cw_break_time * cw_period;	// TX on break time
					spot_on();						// DDS on, SPOT
					}
				}

			if(DOT != 0)							// key up
				{
				if(key_down != 0)					// do only if key was down
					{
					CW = 0;							// CW modulator off
					tone_off();						// stop side tone generator
					key_down = 0;					// remove key down flag
					}
				}
			break;

			default:								// beacon & unknown modes

			break;
			}

// set TX PTT signal depending on PTT mode, keyer or MOX
	set_ptt_out();


// push button timer
	if(long_push != 0)					// decrement long push timer if active
		long_push--;


// general timing
	ms_counter--;						// run 1s free running counter
	if(ms_counter == 0)
		{
		ms_counter = 1000;
		seconds++;
		}

// Blinc flag
	blink_counter--;
	if(blink_counter < 0)
		{
		blink_counter = BLINK_RATE;
		if(blink == 0)
			blink = 1;
		else
			blink = 0;
		}

// Power meter decay counter
	if(decay_counter != 0)
		decay_counter--;

// Band data query timer
	if(band_query_timer != 0)
		band_query_timer--;

// In the PA100 we do not have rotary encoder.
// Encoder functions are simulated, with UP & DOWN buttons

// do debounce shift registers
	up = up << 1;					// UP button, encoder ++
	if(UP == 0)
		up = up | 0x0001;
	else
		up = up & 0xFFFE;

	dn = dn << 1;					// DOWN button, encoder --
	if(DN == 0)
		dn = dn | 0x0001;
	else
		dn = dn & 0xFFFE;

// test pushed condition

// UP
	if(up_pushed == 0)				// not pushed
		{
		if(up == 0xFFFF)			// test if debounce shift register all ones
			{
			up_pushed = 1;			// set pushed
			rep_up_dly = REP_DLY;	// set repeat start timer
			enc++;					// increment encoder
			}
		}
	else							// pushed
		{
		if(up == 0x0000)			// test if debounce shift register all zeroes
			{
			up_pushed = 0;			// clear pushed
			rep_up_dly = 0;			// clear repeat
			rep_up = 0;
			}
		}

// DOWN
	if(dn_pushed == 0)				// not pushed
		{
		if(dn == 0xFFFF)			// test if debounce shift register all ones
			{
			dn_pushed = 1;			// set pushed
			rep_dn_dly = REP_DLY;	// set repeat start timer
			enc--;					// increment encoder
			}
		}
	else							// pushed
		{
		if(dn == 0x0000)			// test if debounce shift register all zeroes
			{
			dn_pushed = 0;			// clear pushed
			rep_dn_dly = 0;			// clear repeat
			rep_dn = 0;
			}
		}


// repeat start timers
	if(rep_up_dly != 0)				// check if UP button stsrt repeat timer is running
		{
		rep_up_dly--;
		if(rep_up_dly == 0)			// start repeat action
			rep_up = REP;
		}

	if(rep_dn_dly != 0)				// check if DN button stsrt repeat timer is running
		{
		rep_dn_dly--;
		if(rep_dn_dly == 0)			// start repeat action
			rep_dn = REP;
		}


// repeat generator timers
	if(rep_up != 0)					// UP button rep counter going ?
		{
		rep_up--;
		if(rep_up == 0)
			{
			rep_up = REP;			// reload timer
			enc++;					// add encoder accu
			}
		}

	if(rep_dn != 0)					// DOWN button rep counter going ?
		{
		rep_dn--;
		if(rep_dn == 0)
			{
			rep_dn = REP;			// reload timer
			enc--;					// subtract encoder accu
			}
		}

	if(start_frep != 0)				// frequency tune start repeat
		start_frep--;


	if(frep != 0)					// frequency tune repeat
		frep--;


	t_stamp++;						// increment time stamp

	IRQ_TEST = 0;		// timing test
	}

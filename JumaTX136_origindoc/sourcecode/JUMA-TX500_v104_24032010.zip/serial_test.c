//
// JUMA-TX500 serial I/O test command set
//
// Juha Niinikoski, OH2NLT 06.07.2006
//
//


#include "juma-tx500.h"				// board definitions
#include "DataEEPROM.h"				// EEPROM I/O definitions, interface to assembler module
#include "lcd-tx500.h"				// LCD specific definitions

// external references
// external functions

extern void putch(char);						// uart I/O
extern unsigned char kbhit(void);
extern unsigned char getch(void);
extern unsigned char getche(void);
extern unsigned long getlong(void);
extern unsigned char get2hex(void);
extern void bin2ascii(unsigned long);
extern void putlong( unsigned long); 

extern void draw_s_meter(int);					// LCD functions
extern void draw_bar(int, int);
extern void lcd_putst(register const char *);
extern void set_chgen(void);
extern void initlcd(void);
extern void clear_lcd(void);
extern void set_cur_lcd(unsigned char);
extern void disp_freq(long);
extern void disp_rit(int);
extern void disp_meter(int, int);

extern void init_adc12(void);
extern int convert_adc12(unsigned int adchs);	// ADC
extern int check_io_board_type(void);

extern void ms_delay( unsigned int);			// general delay

extern void calc_tword(void);					// calculate DDS tuning word
extern void calc_hz_bit (void);					// calculate Hz/bit from ref osc actual value

extern void paly_string(char *);				// play morse code string
extern void clear_lcd_morse_buffer(void);		// clear LCD scroll buffer
extern void init_beacon(char *);				// init beacon buffer contnous play

extern void read_beacon_string(void);			// read beacon string from the EEPROM
extern void save_beacon(void);					// save beacon string

// external data

extern const char ver[];						// system version
extern const char date[];						// version date

extern int board_type;							// main board type, 0=TX500, 1= TX136, 0=unknown

extern int batt;								// Powersupply voltage scaled value, measured only when displayed
extern int service_mode;						// service mode selected flag

extern unsigned int long_push;					// long push timer for buttons

extern unsigned long dds_test;

extern unsigned long txfreq;					// tx frequency
extern unsigned long tword;						// DDS tuning word
extern float hz_bit;							// calculated DDS bit resolution

extern char beacon_buffer[BEACON_BUFFER_SIZE];	// beacon text buffer

extern long busy_counter;						// tone generator busy(ms), busy if != 0
extern long cw_break_time;						// set value for the timer
extern long cw_break_timer;						// cw break timer
extern unsigned int cw_period;					// CW period(ms)
extern int cw_active;							// cw active flag for keyer code
extern int keyer_mode;							// 0=dot priority, 1=iambic A,  2=iambic B, 3=straight & tune

// test

extern int morse_chr_idx;
extern int morse_table_idx;
extern void play_beacon(void);

// EEPROM structures

#include "tx500_eeprom.h"						// get EEPROM structure definitions
#include "ad9833.h"								// DDS functions

extern union
	{
	struct defval defval;
	unsigned int storage[sizeof(struct defval)/2];
	}eeprom;

// system calibration values

extern union
	{
	struct calval calval;
	unsigned int ee[sizeof(struct calval)/2];
	}cal;


void dump_eeprom(void)
	{
	int x;
	unsigned int y, w;

	printf("Dump EEPROM contents\n\r");	
//	for(x=0; x<256; x=x+2)								// byte address for EEPROM, but data is stored in words
	for(x=0; x<512; x=x+2)
		{
		y = ReadEE(EEPAGE, (x+EEDEF), &w, WORD);		// EEPROM Address 8 high bits, address + physical EEPROM start 16 low bits
		if((x%16) == 0)
			printf("\n\r%5.4X", x);

			printf(" %4X", w);			
		}
	printf("\n\rLast success code = %X ", y);
	}

// morse player test, 0 = repeat old buffer, 1 = ask new buffer
void morse_test(int mode)
	{
	char c;
	int idx;

	c = 0;
	idx = 0;

	printf("\n\rMorse Code player test, mode = %d\n\r",mode);

	if(mode !=0 )
		{
		printf("\n\rWrite message max &d char, terminate with CR\n\r", BEACON_BUFFER_SIZE);

		while(c != 0x0D && idx < (BEACON_BUFFER_SIZE-1))
			{
			c = getche();
			beacon_buffer[idx] = c;
			idx++;
			}
		}

	clear_lcd_morse_buffer();				// clear LCD scroll buffer

	printf("\n\rPlay started\n\r");
	paly_string(&beacon_buffer[0]);
	}

// clear Beacon string
void clear_beacon_string(void)
	{
	int x;

	for(x=0; x < BEACON_BUFFER_SIZE; x++)
		{
		beacon_buffer[x] = 0;
		}
	}

// get Beacon string from the terminal
void get_beacon_string(void)
	{
	char c;
	int idx;

	printf("\n\rWrite Beacon message max %d char, terminate with CR\n\r", BEACON_BUFFER_SIZE);

	clear_beacon_string();						// clear, write nulls before new message
	idx = 0;

		while(c != 0x0D && idx < (BEACON_BUFFER_SIZE-1))
			{
			c = getche();
			beacon_buffer[idx] = c;
			idx++;
			}

	init_beacon(beacon_buffer);					// init beacon logic, need this if beacon running
	printf("\n\r");
	}





// command menu
void print_menu(void)
	{
	printf("\n\r--- Beacon control commands ---\n\r");
	printf("b Write Beacon message\n\r");
	printf("p Print Beacon message, no sound\n\r");
	printf("t Test play Beacon message\n\r");
	printf("s Start Beacon transmission\n\r");
	printf("q Stop Beacon transmission\n\r");

	printf("\n\r--- Test commands ---\n\r");
	printf("i system info\n\r");
	printf("e dump EEPROM\n\r");
	printf("c clear EEPROM factory reset counter\n\r");
	printf("a show all ADC values\n\r");
	printf("d DDS constants\n\r");
	printf("T play tone\n\r");
	printf("W write LCD test HEX\n\r");
	printf("w write LCD test ASCII\n\r");
	printf("B LCD bar graph test\n\r");
	printf("Z CPU error trap test\n\r");
	}

void serial_test(void)
	{
	int x, z, temp;
	unsigned int y, w;
	unsigned char c;
	unsigned long l;

		if(kbhit())
			{
			c = getch();
			switch(c)
				{
// Beacon commands

				case 'b':									// Get & save Save beacon string
					get_beacon_string();
					save_beacon();
					break;

				case 'p':									// read beacon string from the EEPROM, print it, no sound
					printf("\n\r\n\rBeacon string from the EEPROM:");
					read_beacon_string();
					printf("\n\r\n\r%s\n\r", beacon_buffer);
					break;

				case 't':									// test play beacon string
					printf("\n\rTest Play Beacon string:\n\r");
//					paly_string(&beacon_buffer[0]);

					if(eeprom.defval.beacon_tx_on == 0)		// turn on only if beacon was off
						{
						eeprom.defval.pa_state = 0;			// force STBY
						eeprom.defval.keyer = 4;	 		// force keyer mode = Beacon
						init_beacon(beacon_buffer);			// init beacon logic
						eeprom.defval.beacon_tx_on = 1;		// set Beacon on, one round
						}

					break;

				case 's':									// start Beacon TX
					printf("\n\rBeacon TX started\n\r");
					if(eeprom.defval.beacon_tx_on == 0)		// turn on only if beacon was off
						{
						eeprom.defval.pa_state = 1;			// force OPER
						eeprom.defval.keyer = 4;	 		// force keyer mode = Beacon
						init_beacon(beacon_buffer);			// init beacon logic
						eeprom.defval.beacon_tx_on = -1;	// set Beacon on, continous
						}
					break;

				case 'q':							// stop Beacon TX
					printf("\n\rBeacon TX stopped\n\r");
					eeprom.defval.beacon_tx_on = 0;					// turn it off
					break;


// Info commands
				case 'I': case 'i':										// system info
					x = check_io_board_type();
					switch(x)
						{
						case TX500_TYPE:
							printf("\n\r\n\rJUMA-TX500 copyright OH7SV & OH2NLT\n\r");
						break;

						case TX136_TYPE:
							printf("\n\r\n\rJUMA-TX136 copyright OH7SV & OH2NLT\n\r");
						break;

						case UNKNOWN_TYPE: default:
							printf("\n\r\n\rUnknown Main Board type copyright OH7SV & OH2NLT\n\r");
						break;
						}
					printf("\n\rSoftware version ");
					printf(ver);
					printf(" / ");
					printf(date);
					printf(", copyright Juha Niinikoski OH2NLT\n\r");
					break;

// Test commands

// ADC & PWM DAC test
				case 'a':												// Measure all ADC channels 9:14
				for(x=9; x<15; x++)
						{
						printf("\n\rADC %i = %i", x, convert_adc12(x));
						}
					break;

// EEPROM
				case 'e':												// dump EEPROM
					dump_eeprom();
					break;

				case 'c':												// clear factory default reset counter
					printf("EEPROM reset counter cleared\n\r");
					temp = 0;
					EraseEE(EEPAGE, EE_FD_LOC, WORD);
					WriteEE(&temp, EEPAGE, EE_FD_LOC, WORD);
					dump_eeprom();
					break;

// LCD tests
				case 'w':												// test LCD chgen, ASCII
					printf("LCD write ascii, ESC = end test, CR = clear LCD \n\r");
					clear_lcd();
					while(c != 0x1B)
						{
						while(kbhit() == 0);
						c = getch();
						if(c == 0x0D)									// CR = clear screen
							clear_lcd();
						printf("char = %x\n\r", c);
						lcd_putch(c);
						}
					break;

				case 'W':												// test LCD chgen, HEX
					printf("LCD write hex, 0x1B = end test, 0x0D = clear LCD\n\r");
					clear_lcd();
					while(c != 0x1B)
						{
						c = get2hex();
						if(c == 0x0D)									// CR = clear screen
							clear_lcd();
						printf(" = %c\n\r", c);
						lcd_putch(c);
						}
					break;

				case 'B':												// bar graph
					printf("bar graph test\n\r");
					
					for(;;)
					{
					for(x=0; x<96; x++)
						{
						clear_lcd();
						draw_s_meter(x);
						ms_delay(50);
						}
					if(kbhit())
						break;
					}
					break;

				case 'Z':							// Trap / Error test
					printf("\n\rDiv by Zero");
					x = 0;
					temp = temp / x;				// generate error ==> trap
					break;


				case 'T':							// Buzer sound test, pitch = FCYMHz / tone(Hz) * 2
					printf("\n\rSound test, FCYMHz / tone(Hz) * 2, give pitch ");
					x = getlong();
					printf("\n\rSound test, give duration(ms) ");
					z = getlong();
					beep(x, z);
					break;

				case 'd':							// DDS test
					calc_hz_bit();					// calculate Hz/bit from ref osc actual value
					printf("\n\rRef osc %ld, hz_bit %f",cal.calval.ref_osc[board_type] ,hz_bit);
					break;




// temporary test commands


				case 'z':							// test
					printf("\n\rTest beacon primitives, give letter or number ");
					c = getche();
					play_morse_character(c);
					printf(", 0x%.2X\n\r", c);
					break;

				case 'o':							// set ref osc
					printf("\n\rSet Ref osc frequency > ");
					cal.calval.ref_osc[board_type] = getlong();
					calc_hz_bit();					// calculate Hz/bit from ref osc actual value
					printf("\n\rRef osc %ld, hz_bit %f",cal.calval.ref_osc[board_type] ,hz_bit);
					break;


				case 'l':							// test, keyer timing
					printf("\n\rTest, keyer timing ");
					printf("\n\rbusy_counter   %ld", busy_counter);
					printf("\n\rcw_break_timer %ld", cw_break_timer);
					printf("\n\rcw_break_time  %ld",cw_break_time);
					printf("\n\rcw_period      %d",cw_period);
					printf("\n\rcw_active      %d",cw_active);
					printf("\n\r keyer_mode    %d", keyer_mode);
					printf("\n\rANT RLY %d, PTT %d, BUFFER %d, CW %d",ANT_RLY, PTT_OUT_1, BUFFER_ON, CW);
					break;


// test command grave yard
#if 0

// Temporary hardware debug commands

				case 'S':							// Save beacon string
					save_beacon();
					printf("\n\rBeacon string saved to the EEPROM");
					break;


				case 'm':							// morse test, new input
					morse_test(1);
					save_beacon();
					printf("\n\rBeacon string saved to the EEPROM");
					break;

				case 'r':							// morse test, repeat
					morse_test(0);
					break;

				case 'D':												// DDS test
					printf("\n\rGive DDS control word value: ");
					l = getlong();

					printf("\n\rDDS set %ld", l);
					tune_ad9833(l);
					dds_test = l;
					break;


				case 'F':												// DDS test
					printf("\n\rGive DDS Freq: ");
					l = getlong();

					printf("\n\rFreq set %ld, DDS started", l);
					eeprom.defval.txfreq = l;
					calc_tword();
					tune_ad9833(tword);
					break;

				case 'T':						// Buzer sound test, pitch = FCYMHz / tone(Hz) * 2
					printf("\n\rTimer based Sound test, FCYMHz / tone(Hz) * 2, give pitch ");
					x = getlong();
					printf("\n\rSound test, give duration(ms) ");
					z = getlong();

					tone_on(x);
					ms_delay(z);
					tone_off();	
					ms_delay(z);

					beep(x, z);
					break;

#endif

				default:
					print_menu();				// if unknown command print menu
//					printf("Key is: %d\n\r", c);
//					printf("Try: Valid commands\n\r");

				}	// case
			}		// if
	}

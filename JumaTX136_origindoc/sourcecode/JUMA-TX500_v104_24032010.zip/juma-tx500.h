//
// Board specifc definitions for
// JUMA-TX500 / JUMA-TX136 transmitter
// Juha Niinikoski OH2NLT 22.11.2008
//

// Band limits set  SW v1.00, 10.10.2009

// processor header
#include <p30f6014A.h>

// uart setup according clock config
#define BAUD 9600
//#define SERIAL_MODE 0					// JUMA-TX500
#define SERIAL_MODE 1					// SERIAL TEST

// clock constants
#define FCY    7372800UL				// 29,4912MHz ext Osc / 4  = 7,3728MHz

#define DLYCONST ((FCY/1000000UL) + 1)	// constant for timer delay routines
#define TICK_PERIOD (FCY/1000)			// 1ms tick

// Ref Osc & DDS constants
#define DDS_RESOLUTION 268435456.0		// DDS resolution = 28bits

#define HZ_BIT_6 0.02235174				// DDS resolution @ 6 000 000Hz ref clk
#define REF_OSC_6 6000000UL				// Reference oscilator 6.000MHz

#define HZ_BIT_20 0.07450580596923828125	// DDS resolution @ 20 000 000Hz ref clk
#define REF_OSC_20 20000000UL				// Reference oscilator 20.000MHz

#define REF_OSC_U 1234567UL				// Reference oscilator for undefined board type

// TX500 frequency constants
#define TX500_DEFAULT_TX_FREQ	500000
#define TX500_LOW_TX_FREQ		420000		// engineering test
#define TX500_HI_TX_FREQ		600000

// TX136 frequency constants
#define TX136_DEFAULT_TX_FREQ	136000
#define TX136_LOW_TX_FREQ		120000
#define TX136_HI_TX_FREQ		190000

// TX Unknown frequency constants
#define U_DEFAULT_TX_FREQ	300000
#define U_LOW_TX_FREQ		120000
#define U_HI_TX_FREQ		600000

// LCD parameters & factory defaults
#define DEFAULT_CONTRAST 2000
#define MAX_CONTRAST 3500
#define DEFAULT_BL 100
#define MAX_BL 1100

// panel buttons
//#define BUTTON_DEBOUNCE 200		// debounce delay(ms) "original"
#define BUTTON_DEBOUNCE 100			// debounce delay(ms) for fast fingers(oh7sv)
#define LONG_PUSH 1000				// long button push
#define VERY_LONG_PUSH	3000		// very long push
#define POWER_OFF 1200				// power off push
#define DEFAULT_BEEP_LEN 50			// button beep length 50ms, long = * 10
#define BLINK_RATE 500				// alarm text blink rate (ms)
#define ALARM_BEEP_LEN 30			// alarm beep length
// encoder simulator with UP and DN buttons
#define REP 80						// UP / DN muttons repeat interval
#define REP_DLY 500					// delay before repeat starts

// alarm flags
// Alarm bits
#define SWR_AL 	(1<<1)
#define CURR_AL	(1<<2)

//#define SWR_LIMIT  300				// Default value 0,01 units, 500 = 5.0
#define SWR_LIMIT_MAX	(3 * 100)		// MAX power limit
#define SWR_LIMIT_HI	(6 * 100)
#define SWR_LIMIT_LOW	(15 * 100)
#define SWR_LIMIT_MIN	(30 * 100)		// MIN power limit

//#define MAX_SWR (35 * 100)			// max setup value
#define MAX_SWR 10100				// max setup value for hardware tests 101.00

// Power meter
// Fast attach, slow release parameters
#define PEAK_SHOW_TIME 350						// freeze after new peak value(ms)
#define DECAY_TIME 50							// power meter decay tiimer(ms)
#define DECAY_RATE 1							// decay rate 

// ADC values
// channell definitions
#define ID_CUR 9				// PA Drain current chanell
#define BATT_CH 10				// battery chanell
#define B_TYPE	11				// Board type
#define REV_PWR 12				// reverse power chanell
#define FWD_PWR 13				// forward power

//Main board types
// TX500 1V +/-0,2V
// TX136 2V +/-0,2V
#define TX500_LOW		655		// ADC 0,8V
#define TX500_HI		983		// ADC 1,2V
#define TX136_LOW		1474	// ADC 1,8V
#define TX136_HI		1802	// ADC 2,2V
#define TX500_TYPE		1		// Main board types
#define TX136_TYPE		2
#define UNKNOWN_TYPE	0

// Tone generator constants, FCYMHz / tone(Hz) * 2
// some harmony sounds * 2, FCY = 7,3728MHz
#define HZ392_01	4702		// G, off
#define HZ466_85	3948		// Bp, push button standard tone
#define HZ587_31	6138		// D, fast tune tone
#define HZ698_45	2639		// F, CW side tone
#define LOWTONE	16756			// too low to play tone, about 220Hz (Sidetone off)
#define NOTONE		0			// not audible tone (Sidetone off)

//button tones
#define TONE_A		8262		// 446,164Hz
#define TONE_B		6276		// 587,330Hz
#define TONE_C		5278		// 698,456Hz
#define TONE_D		3954		// 932,328Hz

// CW constants
//#define MIN_CW_SPEED	1		// min speed(wpm)
//#define MAX_CW_SPEED	50		// max speed(wpm)
//#define DEFAULT_CW_SPEED 20		// default speed(wpm)

#define MIN_CW_SPEED	1		// min speed(wpm * 10), 0.1
#define MIN_UI_CW_SPEED	10		// min user interface speed(wpm * 10), 1.0
#define MAX_CW_SPEED	500		// max speed(wpm * 10), 50.0
#define DEFAULT_CW_SPEED 200	// default speed(wpm * 10), 20.0

#define CW_SIDETONE 	700		// default tone 700 Hz
#define CW_SIDETONE_LOW	200		// sidetone limits
#define CW_SIDETONE_OFF	200		// tone off limit	
#define CW_SIDETONE_HI	2000
#define CW_SIDETONE_STEP 50		// addjust step

// CW keyer
#define KEYER 2					// factory default = Iambic B
#define CW_BREAK_TIME 7			// default cw break timer value
#define MIN_CW_BREAK_TIME 5		// low limit
#define MAX_CW_BREAK_TIME 10	// hi limit

// Beacon
#define BEACON_BUFFER_SIZE 240	// beacon buffer size

// meter scaling factors, factory defaults
#define BATT_MULT 135UL			// 100 x battery voltage ADC * BATT_MULT / 256 
#define ID_MULT 4000UL			// default value for Drain current scaling, ID*10 = ADC * ID_MULT / 65536
 
//#define	S_MTR_MULT 1920UL		// default value for S-meter scaling, S-meter = ADC * S_MTR_MULT / 65536, 48 = max meter = 2.0V FS

// 0,85V = 50,0W
//#define	REV_PWR_MULT 67UL		// default value for Reverse Power scaling
//#define	FWD_PWR_MULT 67UL		// default value for Forward Power scaling,P*100 =  ADC^2 * FWD_PWR_MULT / 65536, 100W = 1000
//#define PWR_GRAPH_MULT 104UL		// power bar graph,48=max = 50W, ADC^2 * PWR_GRAPH_MULT / 1048576
//#define F_VOLT_GRAPH_MULT 9040UL 	// power bar graph,48=max = 50W, ADC * F_VOLT_GRAPH_MULT / 131072

// 1:40 SWR transformer, 1,58V = 50,0W
#define	REV_PWR_MULT 20UL			// default value for Reverse Power scaling
#define	FWD_PWR_MULT 20UL			// default value for Forward Power scaling, P*100 =  ADC^2 * FWD_PWR_MULT / 65536, 100W = 1000

//#define F_VOLT_GRAPH_MULT 4043UL 	// power bar graph, 48=max = 60W, ADC * F_VOLT_GRAPH_MULT / 131072, 60W = 1,9V
#define F_VOLT_GRAPH_MULT 4546UL 	// power bar graph, 48=max = 60W, ADC * F_VOLT_GRAPH_MULT / 131072, 60W = 1,7V

// other constants
#define MAX_RFPWR	3			// RF power selector max value, range = 0 ... 3


// Power on & calibration value addresses in the EEPROM
#define EEPAGE 0x7F				// EEPROM address high part
#define EEDEF 0xF000			// EEPROM default values storage area
#define EECAL 0xF040			// EEPROM calibration values storage area
#define EE_FD_LOC 0xF0F0		// counter address in EEPROM
#define EEBEACON 0xF100			// Beacon bessage string

// PA100 board I/O definitions

// Port A Switches

#define INIT_TRISA 0xFF3F				// PortA switch inputs
#define INIT_PORTA 0x0000

#define RFPWR	_RA12					// SW2, RF power level selector
#define DISP	_RA13					// SW1, FUNC / DISP
#define DN		_RA14					// SW8, DOWN button
#define UP 		_RA15					// SW5, UP button


// Port B ADC inputs

#define INIT_TRISB 0x3E08
#define INIT_PORTB 0x0000

#define IRQ_TEST	_LATB0				// timing test, J19-4
#define MAIN_TEST	_LATB1				// timing test, J19-5

#define OC_CLR		_LATB5				// Over current clear, 0 = clear

#define PTT_IN_IO	_RB3				// PTT input / TX on, 0 = active, Test

#define	PREAMP_GAIN	_LATB14				// Preamp gain, 0 = 10dB, 1 = 20dB

// Port C Switches & power control

#define INIT_TRISC 0x401E				//
#define INIT_PORTC 0x0000				//

#define OPER	_RC4					// SW3, OPER
#define FREQ_DN	_RC3					// SW4, Band - button
#define FREQ_UP	_RC1					// SW6, Band + button

#define F_SENSE	_RC14					// F-Sense counter input
#define PWR_ON	_RC13					// Power on


// Port D LCD & PWM out

#define INIT_TRISD 0x0001				// LCD & LED I/O, all outputs
#define INIT_PORTD 0x0000				//

// power switch
#define PWR_SW		_RD0				// Power switch input, 1 = switch pushed

// tone output
#define TONE_OUT	_LATD1				// tone output
#define TONE_TRIS	_TRISD1				// tone output tri state control

// LCD signals
#define LCD_E		_LATD5				// LCD E signal

#define LCD_RW		_LATD6				// LCD R/W signal
#define LCD_RS		_LATD7				// LCD RS signal

#define LCD_DATA	LATD				// LCD 8-bit data bus out register
#define LCD_BUS		PORTD				// LCD 8-bit data bus state
#define LCD_TRIS	TRISD				// LCD data direction 

#define LCD_SHIFT 8						// LCD bits shifted from D0
#define LCD_MASK	(0x00FF<<LCD_SHIFT)			// LCD data lines at port


// PORT F RS232

#define INIT_TRISF 0xFD7C				//
#define INIT_PORTF 0x0000


// PORT G FAN control

#define INIT_TRISG 0x8000				// RG15 input, others outputs
#define INIT_PORTG 0x0000

#define OC			_RG15				// Over Cueernt trip indicator from PA board

//DDS
#define AD_FSYNC	_LATB7				// AD9833 DDS Chip signals
#define AD_SCLK		_LATB4
#define AD_SDATA	_LATB6


// PTT
#define PTT_IN			_RB3			// 1 = PTT IN active
#define PTT_OUT_1		_LATG2			// PTT_OUT, Q5 drive, 1 = active
#define PTT_OUT_2		_LATG3			// PTT_OUT, Q6 drive, 1 = active

// Paddle
#define	DASH			_RF6			// 0 = active, key down
#define	DOT				_RF8			// 0 = active, key down

// 
#define PREAMP_ON		_LATG13			// Preamp relay, 1 = preamp on
#define ANT_RLY			_LATG12			// Antenna relay, 1 = on
#define MIXER_CLK_ON	_LATG14			// Mixer clock on, 1 = on
#define SPOT			_LATA7			// Spot, 1 = gate driver power on
#define SPARE			_LATA7			// Spare output, 1 = active
#define CW				_LATA6			// CW on, 1 = PA power on, keying

#define BUFFER_ON		_LATB2			// DDS output buffer on, 1=buffer powered

#define PWR0			_LATG0			// PWR0 relay, 1 = active
#define PWR1			_LATG1			// PWR1 relay, 1 = active

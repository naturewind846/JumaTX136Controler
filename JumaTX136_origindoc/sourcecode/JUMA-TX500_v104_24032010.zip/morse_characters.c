//
// JUMA-TX500 Transmitter Controller
// Juha Niinikoski, OH2NLT 06.07.2008
//
// 
// Microchip MPLAB + C30 compiler
// MCU dsPIC30F6014A
//
// Brute Force Morse Code "character generator" 01.09.2009
// More morse characters coded 15.09.2009
// very slow CW keyer speed, downto 0.1 wpm 20.09.2009
// Beacon end quick TX release 11.10.2009

#include "juma-tx500.h"							// JUMA-TRX2 hardware specific definitions
#include "tx500_eeprom.h"						// EEPROM storage structure
#include "lcd-tx500.h"							// LCD specific definitions

extern union
	{
	struct defval defval;
	unsigned int storage[sizeof(struct defval)/2];
	}eeprom;

extern union
	{
	struct calval calval;
	unsigned int ee[sizeof(struct calval)/2];
	}cal;

extern int board_type;							// main board type, 0=TX500, 1= TX136, 0=unknown

static int morse_chr_idx;						// currently playing morse character dash/dot list index
static int morse_table_idx;						// currently playing morse character morse code table index
int morse_chr_playing;							// character playing, keyer reserved, 1=playing

static long argument;							// argument accu

char lcd_m_buf[10];								// LCD morse code display buffer

// 1ms interupt routine variables and functions
extern long busy_counter;						// tone generator busy(ms), busy if != 0
extern long cw_break_time;						// set value for the timer
extern long cw_break_timer;						// cw break timer
extern unsigned int cw_period;					// cw impulse period for the keyer code(ms)
extern int cw_active;							// cw active flag for keyer code

extern void play_dot(void);						// Turn TX on & generate dot
extern void play_dash(void);
extern void calc_cw_period(void);				// calculate new values for the keyer


extern void calc_tword(void);					// just calculate new DDS set value
extern const long low_tx_freq[3];				// tuning limits
extern const long hi_tx_freq[3];


// helper routines

// Clear LCD buffer
void clear_lcd_morse_buffer(void)
	{
	int x;
	for(x=0; x<10; x++)
		{
		lcd_m_buf[x] = ' ';					// clear buffer
		}
	lcd_m_buf[9] = 0;						// terminating null
	}

// LCD text scroll
// display 8-character long scrolling message at upper left display corner
void disp_morse_code(unsigned char c)
	{
	int x;
	unsigned char cc;

	switch(c)								// convert Scandinavian characters for the LCD module
		{
		case 0xC4: case 0xE4:				// �, �
			cc = 0xE1;						// �
		break;

		case 0xD6: case 0xF6:				// �, �
			cc = 0xEF;						// �
		break;

		case 0xC5: case 0xE5:				// �, �
			cc = 0x61;						// a
		break;

		case 0xDC: case 0xFC:				// �, �
			cc = 0xF5;						// �
		break;

		case 0x5C:							// in some LCD displays back slash is Yen sign
			cc =0x60;						// substitute with accent
		break;

		default:
			cc = c;							// no conversion
		break;
		}

	for(x=0; x<7; x++)						// shift buffer left
		{
		lcd_m_buf[x] = lcd_m_buf[x+1];
		}

	lcd_m_buf[7] = cc;						// insert new character

//	set_cur_lcd(LINE1);
//	lcd_putst(lcd_m_buf);					// display buffer
	}


// Simple but not very memory efficient Morse code character storage

// Morse characters

const char morse_char_table[68][8]={

// special
{' ',0},						//   0x20 (space),  index 0x00
{'-','.','-','.','-',0},		// ! 0x21 (start),  index 0x01
{'.','-','.','.','-','.',0},	// " 0x22 
{'.','-','.','-','.',0},		// # 0x23 (end of message AR)
{'.','.','.','-','.','.','-',0}, // $ 0x24
{' ',0},						// % 0x25
{'.','-','.','.','.',0},		// & 0x26 (wait AS)
{'.','-','-','-','-','.',0},	// ' 0x27
{'-','.','-','-','.',0},		// ( 0x28
{'-','.','-','-','.','-',0},	// ) 0x29
{'.','.','.','-','.','-',0},	// * 0x2A (end of contact SK)
{'.','-','.','-','.',0},		// + 0x2B
{'-','-','.','.','-','-',0},	// , 0x2C comma
{'-','.','.','.','.','-',0},	// - 0x2D minus / hyphen
{'.','-','.','-','.','-',0},	// . 0x2E period
{'-','.','.','-','.',0},		// / 0x2F slash

// numbers
{'-','-','-','-','-',0},		// 0 0x30
{'.','-','-','-','-',0},		// 1 0x31
{'.','.','-','-','-',0},		// 2 0x32
{'.','.','.','-','-',0},		// 3 0x33
{'.','.','.','.','-',0},		// 4 0x34
{'.','.','.','.','.',0},		// 5 0x35
{'-','.','.','.','.',0},		// 6 0x36
{'-','-','.','.','.',0},		// 7 0x37
{'-','-','-','.','.',0},		// 8 0x38
{'-','-','-','-','.',0},		// 9 0x39

// special
{'-','-','-','.','.','.',0},	// : 0x3A
{'-','.','-','.','-','.',0},	// ; 0x3B
{' ',0},						// < 0x3C
{'-','.','.','.','-',0},		// = 0x3D
{' ',0},						// > 0x3E
{'.','.','-','-','.','.',0},	// ? 0x3F
{'.','-','-','.','-','.',0},	// @ 0x40

// letters, only capitals are coded
{'.','-',0},					// a 0x41, 0x65
{'-','.','.','.',0},			// b
{'-','.','-','.',0},			// c
{'-','.','.',0},				// d
{'.',0},						// e
{'.','.','-','.',0},			// f
{'-','-','.',0},				// g
{'.','.','.','.',0},			// h
{'.','.',0},					// i
{'.','-','-','-',0},			// j
{'-','.','-',0},				// k
{'.','-','.','.',0},			// l
{'-','-',0},					// m
{'-','.',0},					// n
{'-','-','-',0},				// o
{'.','-','-','.',0},			// p
{'-','-','.','-',0},			// q
{'.','-','.',0},				// r
{'.','.','.',0},				// s
{'-',0},						// t
{'.','.','-',0},				// u
{'.','.','.','-',0},			// v
{'.','-','-',0},				// w
{'-','.','.','-',0},			// x
{'-','.','-','-',0},			// y
{'-','-','.','.',0},			// z 0x5A, 0x7A

// not coded
{' ',0},						// 0x5B, 0x7B
{' ',0},						// 0x5C
{' ',0},						// 0x5D
{' ',0},						// 0x5E
{'.','.','-','-','.','-',0},	// _ 0x5F, 0x7F, index 0x3F

// North/West European characters according to ISO 8859-4 Latin Alphabet 4
{'.','-','.','-',0},			// � 0xE4, � 0xC4, index 0x40
{'-','-','-','.',0},			// � 0xF6, � 0xD6, index 0x41
{'.','-','-','.','-',0},		// � 0xE5, � 0xC5, index 0x42
{'.','.','-','-',0}				// � 0xFC, � 0xDC, index 0x43
};




// Beacon morse generator
// 1ms IRQ function, feed beacon character dash/dot info to the keyer code
void morse_char_irq(void)
	{
	char c;

	if(morse_chr_playing != 0)						// run logic only when play character active
		{
		c = morse_char_table[morse_table_idx][morse_chr_idx];

		if(busy_counter == 0)						// keyer free, mark ready
			{
			switch(c)								// action based on look up character
				{
				case 0: default:					// end of mark
					morse_chr_playing = 0;			// clear playing flag
//					busy_counter = 3 * cw_period;	// character space period
					busy_counter = 2 * cw_period;	// character space period, note one unit is already included with dash or dot
				break;

				case ' ':							// space
					morse_chr_idx++;
					busy_counter =  4 * cw_period;	// word space period, note 3 units are already there from end of mark
					cw_break_timer = cw_break_time * cw_period;				// TX on break time
				break;

				case '-':							// dash
					morse_chr_idx++;
					play_dash();
				break;

				case '.':							// dot
					morse_chr_idx++;
					play_dot();
				break;		
				}
			}

		}
	}


// Convert Ascii to morse code table index

int convert_ascii2morse_idx(unsigned char c)
	{
	int idx;

	switch(c)
		{
		case 0xC4: case 0xE4:		// �, �
			idx = 0x40;
		break;

		case 0xD6: case 0xF6:		// �, �
			idx = 0x41;
		break;

		case 0xC5: case 0xE5:		// �, �
			idx = 0x42;
		break;

		case 0xDC: case 0xFC:		// �, �
			idx = 0x43;
		break;


		default:					// all other
		if(c < 0x20)
			c = 0x20;				// convert all control characters to space

		if(c > 0x5F)				// convert small letters to capital
			c = c - 0x20;

		idx = c - 0x20;				// addjust table index range 0 ... 0x5F
		break;
		}

	return idx;
	}

// play one ascii character, blocking
void play_morse_character(char chr)
	{
	while(morse_chr_playing != 0);					// wait for free

	morse_table_idx = convert_ascii2morse_idx(chr);	// compute & set morse character table index
	morse_chr_idx = 0;								// start play
	morse_chr_playing = 1;
	}


// play string, NULL or CR terminate
void paly_string(char *str)
	{
	cw_active = 0;						// disable keyer logic

	while((*str)!= 0 && (*str)!= 0x0D)
		{
		disp_morse_code(*str);			// display
		play_morse_character(*str);		// play
		putch(*str);					// print to terminal
		str++;
		}
	}

char *b_buf_start;			// beacon text buffer start
char *b_buf_ptr;			// beacon text buffer current pointer
int b_state;				// beacon state machine, special character processing

// init beacon buffer contnous play
void init_beacon(char *str)
	{
	b_buf_start = str;					// save start address
	b_buf_ptr = str;					// set current pointer
	b_state = 0;						// expect printable characters
	clear_lcd_morse_buffer();			// clear LCD text buffer
	}

static int digit_counter;				// digit counter for command processor

// this function is called continoysly from main when beacon is on
// init beacon must be done before
void run_beacon(void)
	{
	char c, tmp;

	if(morse_chr_playing != 0)			// wait for machine free
		return;

	c = *b_buf_ptr;						// get character

	if(c == 0 || c == 0x0D)				// test end of message
		{
		b_buf_ptr = b_buf_start;		// start over

		if(eeprom.defval.beacon_tx_on > 0)	// not continous(-1) or rounds left(positive)
			{
			eeprom.defval.beacon_tx_on--;

			if(eeprom.defval.beacon_tx_on == 0)	// was last round, do stop procedures
				{
				cw_break_timer = 10;	// fast release 10ms
				cw_break_time = cal.calval.cw_break_time;	// normal cw break time
				}
			}
		}

	else								// was not end of message, decode & play
		{
		b_buf_ptr++;					// prepare for next character

		switch(b_state)
			{
			case 0: default:			// normal characters / command seq start
				if(c == 0x5C)			// test if command sequence start character \ back slash
					{
					b_state = 1;		// escape sequence started
					}
				else
					{
					morse_table_idx = convert_ascii2morse_idx(c);	// compute & set morse character table index
					morse_chr_idx = 0;								// start play
					morse_chr_playing = 1;							// set busy flag
					}
			break;

			case 1:								// select command
				switch(c)
					{
					case 'p': case 'P':			// set tx power level
						b_state = 2;
					break;

					case 's': case 'S':			// set CW speed
						b_state = 3;
//						digit_counter = 2;		// expect 2 digits, resolution 1 wpm
						digit_counter = 3;		// expect 3 digits, resolution 0.1 wpm
						argument = 0;			// clear ASCII2Binaryconversion accu
					break;

					case 'f': case 'F':			// set frequency
						b_state = 4;
						digit_counter = 6;		// expect 6 digits
						argument = 0;			// clear ASCII2Binaryconversion accu
					break;

					case 'x': case 'X':			// SPARE signal state
						b_state = 5;
					break;

					default:
						b_state = 0;			// unknown, reset state machine
					break;
					}
			break;

			case 2:								// set tx power level
				eeprom.defval.rfpwr = (c & 0x03);	// simple conversion, set TX RF power level 0...3
				b_state = 0;
			break;

			case 3:								// set CW speed
				if(digit_counter > 0)
					{
					argument = argument * 10 + (c & 0x0F);		// collect 2-digit number
					digit_counter --;

					if(digit_counter == 0)						// was last digit, action
						{
						if(argument < MIN_CW_SPEED)
							argument = MIN_CW_SPEED;			// check range
						if(argument > MAX_CW_SPEED)
							argument = MAX_CW_SPEED;
	
						eeprom.defval.cwspeed = argument;		// set CW speed(wpm) 1 ... 50
						calc_cw_period();						// calculate new values for the keyer logic

						b_state = 0;							// reset state machine
						}
					}

			break;

			case 4:							// set frequency
				if(digit_counter > 0)
					{
					argument = argument * 10 + (c & 0x0F);			// collect 6-digit number
					digit_counter --;

					if(digit_counter == 0)							// was last digit, action
						{
						if(argument > hi_tx_freq[board_type])		// check limits
							argument = hi_tx_freq[board_type];
						if(argument < low_tx_freq[board_type])
							argument = low_tx_freq[board_type];

						eeprom.defval.txfreq[board_type] = argument; // set new frequency
						calc_tword();								// calculate new DDS set value

						b_state = 0;								// reset state machine
						}
					}
			break;

			case 5:													// set SPARE output state
				if((c & 0x01) != 0)
					{
					SPARE = 1;										// set I/O immediatelly
					eeprom.defval.spare_io = 1;						// set also EEPROM flag
					}
				else
					{
					SPARE = 0;
					eeprom.defval.spare_io = 0;
					}
				b_state = 0;
			break;
			}


		disp_morse_code(c);											// run rolling characters on the LCD
		}
	
	if(eeprom.defval.serial_mode == 1)
		putch(c);													// test print to terminal, only when RS232 = test
	}

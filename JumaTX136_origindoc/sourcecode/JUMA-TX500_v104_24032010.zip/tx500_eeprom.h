//
// JUMA-TX500 EEPROM save structures
//
// Juha Niinikoski, OH2NLT 24.08.2009
//

// PA states
#define STATE_STBY	0
#define STATE_OPER	1
#define STATE_TUNE	2

// keyer modes
#define KEYER_DOT_PRI	0
#define KEYER_IAMBIC_A	1
#define KEYER_IAMBIC_B	2
#define KEYER_STRAIGHT	3

struct defval
	{
	unsigned long txfreq[3];		// tx frequency(Hz), for each board type
	int rfpwr;						// RF power level setting
	int preamp;						// preamp setting, off, 10dB, 20dB
	int converter;					// 3,5 / 10 MHz up converter off, on
	int cwspeed;					// CW speen (wpm)
	int cw_sidetone;				// buzzer tone
	int keyer;						// keyer operating mode, 0=dot pri, 1=iambic A, 2=iambic B, 3=straight, 4=beacon
	int contrast;					// LCD display contrast, pwm4
	int back_light;					// LCD back light, pwm3 
	int serial_mode;				// serial interface operating mode
	int br;							// baud rate index
	int swr_limit[4];				// SWR alarm limits for each power level
	int pa_state;					// Amplifier state, 0 = standby, 1 = oper, 2 = tune
	int mox;						// manually operated TX, 1=manual TX, 0=auto
	int beacon_tx_on;				// beacon transmit on, 1= on
	int spare_io;					// spare digital I/O state
	unsigned int d_csum;			// checksum
	};
		
// system calibration values

struct calval
	{
	long ref_osc[3];				// Reference oscilator frequency, for each board type
	long id_mult;					// Drain current meter calibration
	long batt_mult;					// Battery voltage meter calibration
	long rev_pwr_mult;				// Reverse power meter calibration
	long fwd_pwr_mult;				// forward power meter calibration
	int	beep_len;					// tone marker length(ms)
	int cw_break_time;				// cw break timer set value
	unsigned int c_csum;			// checksum
	};
		

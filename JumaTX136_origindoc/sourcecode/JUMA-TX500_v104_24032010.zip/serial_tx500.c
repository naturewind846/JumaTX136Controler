//
// JUMA-TX500/TX136 protocol
//
// Juha Niinikoski, OH2NLT 09.09.2009
//
//

// Beacon repeat count logic added 14.09.2009
// very slow CW keyer speed, downto 0.1 wpm, S command changed to 3-digits 20.09.2009
// beacon message '=' and '?' character behaviour corrected 17.10.2009

#include "juma-tx500.h"							// board definitions
#include "DataEEPROM.h"							// EEPROM I/O definitions, interface to assembler module

// module variables

#define CMD_BUF_SIZE 16
//#define CMD_BUF_SIZE 256						// for full size beacon message
static char cmd_buf[CMD_BUF_SIZE];				// command buffer
static int cmd_buf_idx = 0;						// buffer fill pointer

int old_keyer = 0;								// temporary storage for Beacon Transmit command
int old_pa_state = 0;
int	beacon_transmit = 0; 						// beacon starten in "Transmit mode", beacon end returns TX500 mode
int rd_bcon_msg_flag = 0;						// instead of command interpreter read beacon message

// external functions

extern void putch(char);						// uart I/O
extern int kbhit(void);
extern unsigned char getch(void);
extern unsigned char getche(void);
extern unsigned long getlong(void);
extern void putlong( unsigned long); 

extern void clear_beacon_string(void);			// clear beacon buffer
extern void init_beacon(char *);				// init beacon buffer contnous play
extern void save_beacon(void);					// save beacon string to the EEPROM

extern int check_io_board_type(void);			// check main board type

extern void calc_cw_period(void);				// calculate CW period
extern void calc_tword(void);					// calculate DDS tuning word

extern void tone_off(void);						// stop tone generator
extern void tx_off(void);						// TX or spot off


// external references

extern unsigned int tone_counter; 				// beep tone length (ms)
extern long busy_counter;						// tone generator busy(ms), busy if != 0
extern long cw_break_timer;						// cw break timer
extern int morse_chr_playing;					// character playing, keyer reserved, 1=playing

extern char beacon_buffer[];					// beacon text buffer
int bcon_buf_idx = 0;								// beacon buffer fill index
extern int board_type;							// main board type, 1=TX500, 2=TX136, 0=unknown
extern int key;									// TX request status

// band limits
extern const long low_tx_freq[3];
extern const long hi_tx_freq[3];

extern const char ver[];						// system version
extern const char date[];						// version date

extern int board_type;							// main board type, 0=TX500, 1= TX136, 0=unknown

extern long fwd_pwr;							// relative forward power
extern long rev_pwr;							// relative reverse power
extern long out_pwr;							// scaled output power = fwd_pwr - rev_pwr * scale
extern long peak_pwr;							// peak, fast attach slow decay power
extern int swr;									// calculated swr * 100

// EEPROM structures

#include "tx500_eeprom.h"						// EEPROM storage structure

extern union
	{
	struct defval defval;
	unsigned int storage[sizeof(struct defval)/2];
	}eeprom;

// system calibration values

extern union
	{
	struct calval calval;
	unsigned int ee[sizeof(struct calval)/2];
	}cal;


// Some I/O functions

// convert number from command buffer
unsigned long get_number(void)
	{
	unsigned long n;
	int i;
	i = 2;															// msb of the number
	n= 0;

	while(i < cmd_buf_idx)											// cmd_buf_idx point to last(lsb) digit +1
		{
		n = (n * 10) + (cmd_buf[i] & 0x0F);
		i++;
		}
	return(n);
	}


// TX500 / TX136 protocol parser

// Send mode data
void send_mode(void)
	{
	printf("=O%i\n\r", eeprom.defval.pa_state);						// send PA state, 1 digit
	}


// Send frequency
void send_FREQ(void)
	{
	printf("=F%.6ld\n\r", eeprom.defval.txfreq[board_type]);		// print frequency, 6 digits

//	printf("=F");
//	put_freq(eeprom.defval.txfreq[board_type]);						// print frequency, 6 digits
//	printf("\n\r");
	}		

// send PTT status
void send_ptt(void)
	{
	if(key == 1)													// TX status
		printf("=T1\n\r");											// PTT status, 0 = off, 1 = on
	else
		printf("=T0\n\r");
	}

// send keyer type
void send_keyer_mode(void)
	{
	printf("=K%i\n\r", eeprom.defval.keyer);						// send Keyer type, 1 digit
	}

// send CW speed
void send_cw_speed(void)
	{
//	printf("=S%.2d\n\r", eeprom.defval.cwspeed);					// send CW speed, 2 digit
	printf("=S%.3d\n\r", eeprom.defval.cwspeed);					// send CW speed, 3 digit
	}

// send TX power level setting
void send_tx_power(void)
	{
	printf("=P%i\n\r", eeprom.defval.rfpwr);						// send TX power setting, 1 digit
	}

// send SPARE I/O state
void send_spare_io_state(void)
	{
	printf("=X%i\n\r", eeprom.defval.spare_io);						// send spare I/O state, 1 digit
	}

// send RF preamp state
void send_preamp_state(void)
	{
	printf("=A%i\n\r", eeprom.defval.preamp);						// send preamp state, 1 digit
	}

// send RX converter state
void send_converter_state(void)
	{
	printf("=C%i\n\r", eeprom.defval.converter);					// send RX converter state, 1 digit
	}

// send Beacon message
void send_beacon_message(void)
	{
	char *str;
	str = beacon_buffer;											// set string starrt

	printf("=M");													// header

	while((*str)!= 0 && (*str)!= 0x0D)
		{
		putch(*str);												// print string to terminal
		str++;
		}

	printf("\n\r");													// trailer
	}

// send system info
void send_system_info(void)
	{
	int temp;
	long ultemp;

	switch(cmd_buf[2])												// select sub command, I, P, S, B D
		{
		case 'I': default:											// general system info
			printf("=II");
			switch(board_type)										// select main board
				{
				case TX500_TYPE:
					printf("JUMA-TX500");
				break;

				case TX136_TYPE:
					printf("JUMA-TX136");
				break;

				case UNKNOWN_TYPE: default:
					printf("UNKNOWN");
				break;
				}
			printf(", SW ");										// print SW version
			printf(ver);
			printf(", DATE ");
			printf(date);											// print SW date
			printf("\n\r");
		break;

		case 'P':													// power meter
			temp = (out_pwr * cal.calval.fwd_pwr_mult) >> 16;
			printf("=IP%d\n\r", temp);
		break;

		case 'S':													// SWR meter
			printf("=IS%d\n\r", swr);
		break;

		case 'B':													// battery voltage
			ultemp = cal.calval.batt_mult * convert_adc12(BATT_CH);	// scale Battery voltage
			temp = ultemp >> 8;
			printf("=IB%d\n\r", temp);
		break;

		case 'D':													// Drain current
			temp = ((long)convert_adc12(ID_CUR) * cal.calval.id_mult) >> 16;	
			printf("=ID%d\n\r", temp);
		break;
		}
	}	

// send Beacon on/off status
void send_beacon_on_off(void)
	{
	if(eeprom.defval.beacon_tx_on == -1)
		printf("=BC\n\r");											// continous mode
	else
		printf("=B%i\n\r", eeprom.defval.beacon_tx_on);				// send Beacon state, 1 digit
	}


// Set frequency
void set_FREQ(void)
	{
	unsigned long ultemp;

	ultemp = get_number();							// get decimal frequency

	if(ultemp < low_tx_freq[board_type])
		ultemp = low_tx_freq[board_type];

	if(ultemp > hi_tx_freq[board_type])
		ultemp = hi_tx_freq[board_type];

	eeprom.defval.txfreq[board_type] = ultemp;		// set frequency
	calc_tword();									// just calculate new DDS set value
	}

// Set operating mode mode
void set_mode(void)
	{
	int temp;
	temp = get_number();

	if(temp < 0)
		temp = 0;
	if(temp > 2)									// only values 0 ... 2 allowed
		temp = 2;
	eeprom.defval.pa_state = temp;					// Set PA state
	}

// set keyer mode
void set_keyer_mode(void)
	{
	int temp;
	temp = get_number();
	if(temp < 0)
		temp = 0;
	if(temp > 4)									// only values 0 ... 4 allowed
		temp = 4;

	eeprom.defval.keyer = temp;						// set keyer mode

	if(eeprom.defval.keyer != 4)					// stop beacon TX if it was on if any other type than beacon selected
		eeprom.defval.beacon_tx_on = 0;				// stop beacon
	}

// Set CW speed
void set_cw_speed(void)
	{
	int temp;

	temp = get_number();

	if(temp < MIN_CW_SPEED)
		temp = MIN_CW_SPEED;

	if(temp > MAX_CW_SPEED)
		temp = MAX_CW_SPEED;

	eeprom.defval.cwspeed = temp;					// set CW speed
	calc_cw_period();								// calculate new period immediatelly
	}

// Set TX power
void set_tx_power(void)
	{
	int temp;

	temp = get_number();

	if(temp < 0)
		temp = 0;

	if(temp > 3)
		temp = 3;

	eeprom.defval.rfpwr = temp;						// set TX power level
	}

// Set SPARE I/O state
void set_spare_io_state(void)
	{
	int temp;
	temp = get_number();
	if(temp < 0)
		temp = 0;
	if(temp > 1)									// only states 0 or 1 allowed
		temp = 1;

	eeprom.defval.spare_io = temp;					// set SPARE I/O state, on / off
	}

// set RF preamp state
void set_preamp_state(void)
	{
	int temp;
	temp = get_number();
	if(temp < 0)
		temp = 0;
	if(temp > 2)									// only values 0 ... 2 allowed
		temp = 2;

	eeprom.defval.preamp = temp;					// set preamp gain
	}

// set RX converter state
void set_converter_state(void)
	{
	int temp;
	temp = get_number();
	if(temp < 0)
		temp = 0;
	if(temp > 1)									// only states 0 or 1 allowed
		temp = 1;

	eeprom.defval.converter = temp;					// set converter state on / off
	}

// set PTT status
void set_ptt(void)
	{
	int b;
//	if(cmd_buf[2] == '1')							// PTT on
//		PTT_OUT = 1;								// TX on
//	else											// PTT off
//		PTT_OUT = 0;								// TX off
	}


// set Beacon message
#if 0
void set_beacon_message(void)
	{
	int i = 2;									// first string character
	int n = 0;
	int idx = 0;

	clear_beacon_string();						// clear, write nulls before new message

	while(i < cmd_buf_idx && idx < (BEACON_BUFFER_SIZE-3))	// watch also buffer limits
			{
			beacon_buffer[idx] = cmd_buf[i];
			idx++;
			i++;
			}

	beacon_buffer[idx] = 0x0D;					// write terminator
	idx++;
	beacon_buffer[idx] = 0x00;

	init_beacon(beacon_buffer);					// init beacon logic, need this if beacon running
	}
#endif

// collect message into the beacon message buffer, CR terminate the operation
void collect_beacon_message(char c)
	{
	beacon_buffer[bcon_buf_idx] = c;			// save data
	if(bcon_buf_idx < BEACON_BUFFER_SIZE-3)
		bcon_buf_idx++;							// addjust index
	}

// terminate message collect, we have received CR
void set_beacon_message(void)
	{
	beacon_buffer[bcon_buf_idx] = 0x0D;			// write terminator
	bcon_buf_idx++;
	beacon_buffer[bcon_buf_idx] = 0x00;

	init_beacon(beacon_buffer);					// init beacon logic, need this if beacon running
	rd_bcon_msg_flag = 0;						// '=' & '?' normal processing
	}


// set Beacon on/off
void set_beacon_on_off(void)
	{
	if(cmd_buf[2] == '0')						// Beacon off
		{
		eeprom.defval.beacon_tx_on = 0;			// turn it off, leave other settings as is
		morse_chr_playing = 0;					// stop morse code generator

// brute force stop all keyer activity
		tone_counter = 0;						// reset irq timers
		__asm__ volatile ("disi #4");			// protect long word clear
		busy_counter = 0;
		tone_off();								// use irq functions to stop activity, not good practice
		__asm__ volatile ("disi #4");			// protect long word clear
		cw_break_timer = 0;
		tx_off();
		}

	else	
		{
		if(eeprom.defval.beacon_tx_on == 0)			// turn on only if beacon was off
			{
			old_pa_state = eeprom.defval.pa_state;	// save current state
			old_keyer = eeprom.defval.keyer;
			beacon_transmit = 0;

			eeprom.defval.pa_state = 1;				// force OPER
			eeprom.defval.keyer = 4;	 			// force keyer mode = Beacon
			init_beacon(beacon_buffer);				// init beacon logic
			switch(cmd_buf[2])
				{
				case 'C':
					eeprom.defval.beacon_tx_on = -1; 					// set Beacon on continous
				break;

				case 'T':
					beacon_transmit = 1;								// set flag for mode & keyer state restoration
					eeprom.defval.beacon_tx_on = 1; 					// Transmit message once and return to previous mode 
				break;

				case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': 
					eeprom.defval.beacon_tx_on = (cmd_buf[2] & 0x0F); // set Beacon on for n rounds	
				break;
				}
			}
		}
	}


// clear buffer
void clear_buffer(void)
	{
	int x;
//	for(x=0; x<CMD_BUF_SIZE; x++)					// clear whole buffer
	for(x=0; x<8; x++)								// clear only CMD bytes
		{
		cmd_buf[x] = 0;
		}
	cmd_buf_idx = 0;
	rd_bcon_msg_flag = 0;
	bcon_buf_idx = 0;								// reset also beacon buffer data collect index
	}

// filter no operation characters, return = 1 if no op
int filter_nop_char(char c)
	{
//	if((c==0x00) || (c==0x0A) || (c==0x20) || (c==0x2C) || (c==0x2E))
	if((c==0x00) || (c==0x0A))						// we need space and comma and period for peacon string
		return(1);
	else
		return(0);
	}

// Parse TX500/TX136 message
void serial_tx500(void)
	{
	char c;
	int b;


// process input
//	if(kbhit())										// process one character at time
	while(kbhit())									// process all at once, better for high speed
		{
		c = getch();								// save character

// filter nop
		if(filter_nop_char(c))						// discard nop characters 
			return;									// do nothing

// capture start sync
		if(c == '=' || c == '?')					// sync with action characters, when collecting beacon buffer accept them
			{
			if(rd_bcon_msg_flag == 0 && cmd_buf_idx > 2 ) // normal mode & command received
				clear_buffer();						// clear input buffer & reset state
			}

// check if buffer ready, interprete message
		if(c == 0x0D)								// CR = message ready, action
			{
			switch(cmd_buf[0])						// action
				{
				case '?':							// query
					switch(cmd_buf[1])
						{
						case 'F':
							send_FREQ();			// send frequency in use
						break;

						case 'O':
							send_mode();			// send operating mode data
						break;

						case 'T':
							send_ptt();				// send PTT status
						break;	

						case 'K':
							send_keyer_mode();		// send keyer type
						break;

						case 'S':
							send_cw_speed();		// send CW speed
						break;

						case 'P':
							send_tx_power();		// send TX power level
						break;

						case 'X':
							send_spare_io_state();	// send SPARE I/O state
						break;

						case 'A':
							send_preamp_state();	// send RX preamp state
						break;

						case 'C':
							send_converter_state();	// send frequency converter state
						break;

						case 'M':
							send_beacon_message();	// send beacon message
						break;

						case 'B':
							send_beacon_on_off();	// send Beacon on/off status
						break;

						case 'I':
							send_system_info();		// send system infi
						break;
						}

					clear_buffer();					// clear for next round
				break;

				case '=':							// set
					switch(cmd_buf[1])
						{
						case 'O':
							set_mode();								// Set PA state
						break;
		
						case 'F':
							set_FREQ();								// set frequency in selected VFO
						break;

						case 'T':
							set_ptt();								// set PTT on/off
						break;

						case 'K':
							set_keyer_mode();						// set keyer mode
						break;

						case 'S':
							set_cw_speed();							// set CW speed
						break;

						case 'P':
							set_tx_power();							// set TX power
						break;

						case 'X':
							set_spare_io_state();					// set Spare I/O state
						break;

						case 'A':
							set_preamp_state();						// set RX preamp state
						break;

						case 'C':
							set_converter_state();					// set frequency converter state
						break;

						case 'M':
							set_beacon_message();					// set Beacon message
						break;

						case 'B':
							set_beacon_on_off();					// set Beacon on/off
						break;

						case 'E':
							save_beacon();							// save Beacon message to the EEPROM 
						break;
						}

					clear_buffer();									// clear for next round
				break;

				default:											// not known
					clear_buffer();									// clear for next round
				break;
				}
			}

		else
			{
			if(cmd_buf[0] == '=' && cmd_buf[1] == 'M')				// special cace, collect to the message buffer
				{
				rd_bcon_msg_flag = 1;								// defeat '=' & '?' processing
				collect_beacon_message(c);
				}

			else													// collect data to the command buffer
				{
				cmd_buf[cmd_buf_idx] = c;							// save data
				if(cmd_buf_idx < CMD_BUF_SIZE-1)
					cmd_buf_idx++;									// addjust index
				}
			}
		}
	}

//
// JUMA-TX500 Transmitter Controller
// Juha Niinikoski, OH2NLT 06.07.2008
//
// 
// Microchip MPLAB + C30 compiler
// MCU dsPIC30F6014A
//
// Brute Force Morse Code "character generator" 01.09.2009
// 


extern void morse_char_irq(void);		// beacon Morse generator 1ms IRQ
void init_beacon(char *str);			// init beacon logic
extern void run_beacon(void);			// beacon logic, called continously from main

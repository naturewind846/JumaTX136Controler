/*
AD9833 DDS Driver for JUMA-TX500

OH2NLT, Juha Niinikoski 14.01.2005

TX500 version 09.06.2009

*/

extern void tune_ad9833(unsigned long);		// set DDS control word
extern void init_ad9833(void);				// init DDS

//
// JUMA-TX500 service & setup routines
//
// Juha Niinikoski, OH2NLT, 08.07.2008
//
// Display clean up 11.11.2008
// Factory setup function corrected 16.12.2008

#include "juma-tx500.h"
#include "lcd-tx500.h"				// LCD specific definitions


// external references
// external functions

extern void beep(int, unsigned int);							// generate beep, period, length
extern void ms_delay( unsigned int);							// delay
extern int encoder_get(void);									// read encoder
extern void clear_lcd(void);									// clear LCD
extern void set_cur_lcd(unsigned char);							// set cursor
extern void lcd_putst(register const char *);					// LCD put string
extern void disp_meter(int, int);								// display meters
extern void power_off(void);									// power down routine
extern void display_s_meter(void);								// display scaled S-meter
extern void disp_fwd_pwr(void);									// display wat meter
extern void disp_id(void);										// display RF Amp Drain current
extern void check_alarms(void);									// check alarms
extern void power_measurements(void);							// do analog measurements

extern void calc_hz_bit (void);									// calculate Hz/bit from ref osc actual value
extern void calc_tword(void);									// calculate DDS tuning word

// external data

extern int batt;					// Powersupply voltage scaled value, measured only when displayed
extern int fwd_adval;				// forward & reverse power raw values, measured only when TX
extern int rev_adval;
extern long fwd_pwr;				// relative forward power
extern long rev_pwr;				// relative reverse power
extern long out_pwr;				// scaled output power = fwd_pwr - rev_pwr * scale
extern int id_cur;					// PA Drain current raw value
extern int service_mode;			// service mode selected flag
extern int key;						// copy of TX request input
extern unsigned int alarms;			// alarm bits

extern unsigned int long_push;		// long push timer for buttons

extern int cw_active;				// cw active flag for keyer code
extern int keyer_mode;				// keyer mode selector

extern unsigned long tword;			// DDS tuning word
extern float hz_bit;				// DDS resolution

extern int board_type;				// main board type, 0=TX500, 1= TX136, 0=unknown

// EEPROM structures

#include "tx500_eeprom.h"			// get EEPROM structure definitions

extern union
	{
	struct defval defval;
	unsigned int storage[sizeof(struct defval)/2];
	}eeprom;

// system calibration values

extern union
	{
	struct calval calval;
	unsigned int ee[sizeof(struct calval)/2];
	}cal;


#define MAX_SERVICE_PAGES 6					// number of display pages

// Service & calibration functions, when tested move to own module

void service(void)
	{
	int cal_page;
	unsigned long ultemp;
	unsigned char lcdpbuff[20];				// LCD print buffer

// start DDS
//	hz_bit = HZ_BIT;
	calc_hz_bit();							// calculate Hz/bit value

	calc_tword();
	init_ad9833();
	tune_ad9833(0);							// keep DDS stopped
//	tune_ad9833(tword);

	calc_cw_period();						// calculate CW period value(ms)
	calc_sidetone();						// calculate sidetone timer value


	cal_page = 0;
	clear_lcd();
	keyer_mode = KEYER_STRAIGHT;			// forse straight
	cw_active = 1;							// cw active flag for keyer code

// conditional start up text printout, print only if RS232 = Test
 	if(eeprom.defval.serial_mode == 1)
		{
		printf("\n\rService & calibration mode");
		printf("\n\rDISP = parameter select, OPER = save & exit");
		}


	for(;;)
		{

// Make atomic copy of KEY(TX request) signal for this processing round
		if(PTT_OUT_1)						// 1 = active
			key = 1;						// copy I/O bit to status flag	
		else
			key = 0;

// do measurements & check alarms
		power_measurements();
		check_alarms();


// do A/D conversions for power meter
		fwd_adval = convert_adc12(FWD_PWR);
		rev_adval = convert_adc12(REV_PWR);
// calculate Power
		fwd_pwr = (long)fwd_adval * (long)fwd_adval;		// calculate relative power levels ( U^2)
		rev_pwr = (long)rev_adval * (long)rev_adval;
		out_pwr = fwd_pwr - rev_pwr;						// output power = forward - reverse.

// Main board relays
		set_rf_pwr_relays();								// RF power selector
		set_preamp();										// set pre amplifier
		set_converter();									// select 3,5MHz up converter



		if(DISP == 0)				// select calibration function
			{
			cal_page++;
			if(cal_page > MAX_SERVICE_PAGES) // number of active pages
				cal_page = 0;
			beep(HZ392_01, 50);
			while(DISP == 0)
				{
				}
			ms_delay(BUTTON_DEBOUNCE);
			encoder_get();			// flush encoder
			}

		switch(cal_page)			// select major page to display
			{
// Local Oscillator
			case 0: default:
			set_cur_lcd(LINE1);
			lcd_putst("Set Ref Osc Freq");

			set_cur_lcd(LINE2);
			cal.calval.ref_osc[board_type] = cal.calval.ref_osc[board_type] + encoder_get() * 10;	// use encoder to adjust
			sprintf(lcdpbuff, "Osc %li Hz  ", cal.calval.ref_osc[board_type]);
			lcd_putst(lcdpbuff);
			break;

// battery voltage
			case 1:
			set_cur_lcd(LINE1);
			ultemp = (unsigned long)convert_adc12(BATT_CH) * cal.calval.batt_mult;		// scale Battery voltage
			batt = ultemp >> 8;															// div by 256, save scaled value
			lcd_putst("Supply  ");
			disp_meter(batt, 2);														// display with two decimals								
			lcd_putst("V  ");

			set_cur_lcd(LINE2);
			cal.calval.batt_mult = cal.calval.batt_mult + encoder_get();		// use coarse encoder to adjust
			if(cal.calval.batt_mult < 100)
				cal.calval.batt_mult = 100;
			if(cal.calval.batt_mult > 200)
				cal.calval.batt_mult = 200;
			sprintf(lcdpbuff, "Cal mult = %li    ", cal.calval.batt_mult);				// show scale multiplier
			lcd_putst(lcdpbuff);
			break;

// beep length
			case 2:
			set_cur_lcd(LINE1);
			sprintf(lcdpbuff, "Beep len, 0=OFF ");
			lcd_putst(lcdpbuff);

			set_cur_lcd(LINE2);
			cal.calval.beep_len = cal.calval.beep_len + encoder_get();		// use coarse encoder to adjust
			if(cal.calval.beep_len < 0)
				cal.calval.beep_len = 0;
			if(cal.calval.beep_len > 100)
				cal.calval.beep_len = 100;
			sprintf(lcdpbuff, "Beep = %i ms    ", cal.calval.beep_len);				   // show current setup
			lcd_putst(lcdpbuff);
			break;

// Forward power scaling
			case 3:
			set_cur_lcd(LINE1);
			lcd_putst("Forward ");
			disp_fwd_pwr();																// display Watt meter

			set_cur_lcd(LINE2);
			cal.calval.fwd_pwr_mult = cal.calval.fwd_pwr_mult + encoder_get();			// use encoder to adjust
			if(cal.calval.fwd_pwr_mult < 0)
				cal.calval.fwd_pwr_mult = 0;
			if(cal.calval.fwd_pwr_mult > 100)
				cal.calval.fwd_pwr_mult = 100;

			cal.calval.rev_pwr_mult = cal.calval.fwd_pwr_mult;							// use same value for reverse pwr

			sprintf(lcdpbuff, "Cal mult = %li    ", cal.calval.fwd_pwr_mult);
			lcd_putst(lcdpbuff);
			break;

// ID scaling
			case 4:
			set_cur_lcd(LINE1);
			lcd_putst("RF Amp.  ");
			disp_id();																	// display drain current

			set_cur_lcd(LINE2);
			cal.calval.id_mult = cal.calval.id_mult + encoder_get();					// use encoder to adjust

			if(cal.calval.id_mult < 3000)
				cal.calval.id_mult = 3000;
			if(cal.calval.id_mult > 5000)
				cal.calval.id_mult = 5000;

			sprintf(lcdpbuff, "Cal mult = %li  ", cal.calval.id_mult);
			lcd_putst(lcdpbuff);
			break;


// CW break period
			case 5:
			set_cur_lcd(LINE1);
			lcd_putst("CW break period ");

			set_cur_lcd(LINE2);
			cal.calval.cw_break_time = cal.calval.cw_break_time + encoder_get();					// use encoder to adjust

			if(cal.calval.cw_break_time < MIN_CW_BREAK_TIME)
				cal.calval.cw_break_time = MIN_CW_BREAK_TIME;
			if(cal.calval.cw_break_time > MAX_CW_BREAK_TIME)
				cal.calval.cw_break_time = MAX_CW_BREAK_TIME;

			sprintf(lcdpbuff, "%i Units          ", cal.calval.cw_break_time);
			lcd_putst(lcdpbuff);
			break;


// Factory defaults, this must be last item in the list
			case 6:
			set_cur_lcd(LINE1);
			lcd_putst("Push OPER long =");
			set_cur_lcd(LINE2);
			lcd_putst("factory defaults");
			break;

			}				// end switch


// read switches
			if(cal_page == MAX_SERVICE_PAGES)							// Restore defaults only when last cal_page
				{
				if(OPER == 0)											// test SW2 (SET)
					{
					long_push = LONG_PUSH;								// set long push timer

					while(OPER == 0)										// detect long push
						{
						if(long_push == 0)								// detect long push, restore factory setup
							{
							set_factory_defaults();						// EEPROM empty, set factory defaults
							save_calval();								// save calibration values
							save_defaults();							// save user defaults

							beep(HZ466_85, cal.calval.beep_len*10);		// long beep for save
							service_mode = 0;							// back to normal operation
							clear_lcd();
							lcd_putst("Factory setup ok");
		
 							if(eeprom.defval.serial_mode == 1)			// conditional print only if RS232 = Test
								printf("\n\rFactory defaults restored");
							ms_delay(1500);								// show message
							while(OPER == 0)
								{
								}
							return;										// exit service mode
							}
						}		// end while
					}			// end if(OPER == 0)
				}				// end (cal_page == 6)
			else
				{
				if(OPER == 0)											// test SW2 (SET) when  cal_page != 6
					{
					save_calval();										// save changes
					beep(HZ466_85, cal.calval.beep_len);				// short beep for return to normal operation
					service_mode = 0;									// back to normal operation
					clear_lcd();
					lcd_putst("Calibr. Saved");
					if(eeprom.defval.serial_mode == 1)					// conditional print only if RS232 = Test
						printf("\n\rCalibration settings saved to EEPROM");
					while(OPER == 0)
						{
						}
					return;												// exit service mode
					}
				}			// end else


		if(PWR_SW == 1)
			power_off();			// go shut down, do not save changes

		}		// end for(;;)
	}			// end function

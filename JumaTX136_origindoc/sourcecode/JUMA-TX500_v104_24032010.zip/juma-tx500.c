//
// JUMA TX500 & TX136 Transmitter Controller
// Juha Niinikoski, OH2NLT 06.07.2008
//
// 
// Microchip MPLAB + C30 compiler
// MCU dsPIC30F6014A
//

// speed tune added, calibration constants changed 24.08.2009
// 136kHz / 500kHz ref osc selection added 31.08.2009
// command clean up, beacon test play, bug fixes 10.09.2009
// Beacon repeat count logic added 14.09.2009
// More morse characters coded 15.09.2009
// Scandi character LCD display, more TX500 protocol commands, Beacon auto start after power failure 16.09.2009
// very slow CW keyer speed, downto 0.1 wpm 20.09.2009
// CW speed user interface setup limited down to 1 wpm 23.09.2009
// Band limits set  SW v1.00, 10.10.2009
// Beacon end quick TX release 11.10.2009, SW v1.01
// Beacon Transmit =BT command added 15.10.2009, SW v1.02
// beacon message '=' and '?' character behaviour corrected 17.10.2009 SW v1.03
// 0.1 wpm CW bug corrected, beep(int, unsigned int), cw_period => unsigned int  24.03.2010 

const char ver[] = {"v1.04"};				// software version information, displayed at startup
const char date[] = {"24.03.2010"};			// version date

//#define MORSE_START_MSG					// define if Morse start up message wanted

#include "juma-tx500.h"						// JUMA-TRX2 hardware specific definitions
#include "lcd-tx500.h"						// LCD specific definitions
#include "DataEEPROM.h"
#include "ad9833.h"							// DDS functions


_FOSC(CSW_FSCM_OFF & XT_PLL4);				// 7,3728MHz XT, 29,4912MHz clock = 7,3728MHz cycle
//_FOSC(CSW_FSCM_OFF & XT_PLL8);				// 3,68640MHz XT, 29,4912MHz clock = 7,3728MHz cycle
_FWDT(WDT_OFF);                				//Turn off the Watch-Dog Timer.
_FBORPOR(MCLR_EN & PWRT_64 & BORV_20);   	//Enable MCLR, power on timer, brown out 2V
//_FGS(GEN_PROT);            				//Disable Code Protection, old compiler
 _FBS(CODE_PROT_OFF);
 _FSS(CODE_PROT_OFF);
 _FGS(CODE_PROT_OFF);


// Global variabbles
int fcy;						// clock / kHz

// Baud Rate divisors for 29,4912 MHz osc =  7,3728 MHz FCY 
/* actual baud rate divisors
[0] 1200	383
[1] 2400	191
[2] 4800	95
[3] 9600	47
[4] 19200	23
[5] 38400	11
[6] 57600	7
[7] 115200	3
*/

// baud rates
#define DEFAULT_BAUD_RATE 3		// default baud rate = 9600
const char br_txt[8][8] = {{"1200  "}, {"2400  "}, {"4800  "} ,{"9600  "}, {"19200 "}, {"38400 "}, {"57600 "}, {"115200 "}};

// band limits
const long low_tx_freq[3] = {U_LOW_TX_FREQ, TX500_LOW_TX_FREQ, TX136_LOW_TX_FREQ};
const long hi_tx_freq[3] = {U_HI_TX_FREQ, TX500_HI_TX_FREQ, TX136_HI_TX_FREQ};

// timing
int seconds;					// free running 1s timer

// display control
#define MAX_LCD_MODE 1			// last display "main" page
#define	MAX_SUB_PAGE0 3			// sub page 0 displays
#define	MAX_SUB_PAGE1 10			// sub page 1 displays
#define S_BAR 0x07				// S-meter vertical bar character

unsigned char lcdpbuff[20];		// LCD print buffer
int	lcd_mode;					// lcd display mode
int sub_page0;					// lcd display sub page for lcd_mode0
int sub_page1;					// lcd display sub page for lcd_mode1
int service_mode;				// service mode selected flag

// ADC & meter variables
int batt;						// Powersupply voltage scaled value, measured only when displayed
long batt_mean_val;
int bat_samples = 0;
int s_meter;					// scaled S-meter value 0 ... 48
int fwd_adval;					// forward & reverse power raw values, measured only when TX
int rev_adval;
int id_cur;						// PA Drain current raw value
long pa_temp;					// PA temperature, ADC value
int scaled_pa_temp;				// scaled to deg C

long fwd_pwr;					// relative forward power
long rev_pwr;					// relative reverse power
long out_pwr;					// scaled output power = fwd_pwr - rev_pwr * scale
long peak_pwr;					// peak, fast attach slow decay power
int swr;						// calculated swr * 100
int old_swr;					// for alarm trigger
int pwr_meter;					// scaled S-meter value 0 ... 48

// PA status
int board_type;					// main board type, 1=TX500, 2=TX136, 0=unknown
int key;						// TX request status
unsigned int alarms;			// alarm bits
int alarm_beep;					// alarm beep logic flag
int sidetone;					// calculated sidetone timer set value

extern unsigned int long_push;	// long push timer, count from set value to zero, global visibility
extern int blink;				// alarm blink flag
extern int decay_counter;		// power meter slow decay
extern unsigned int t_stamp;	// 1ms free running time stamp

extern long cw_break_time;		// set value for the timer
extern unsigned int cw_period;	// cw impulse period for the keyer code(ms)
int cw_active;					// cw active flag for keyer code
int keyer_mode;					// keyer mode selector

// Frequency tune repeat counters
extern volatile int start_frep;	// start repeat
extern volatile int frep;		// repeat tiner

char beacon_buffer[BEACON_BUFFER_SIZE];	// beacon text buffer
extern char lcd_m_buf[10];		// LCD morse code display buffer

#include "tx500_eeprom.h"		// EEPROM storage structure

unsigned int fd_counter;		// counts how many times factory defaults have reloaded

union
	{
	struct defval defval;
	unsigned int storage[sizeof(struct defval)/2];
	}eeprom;

// system calibration values

union
	{
	struct calval calval;
	unsigned int ee[sizeof(struct calval)/2];
	}cal;


// external functions

extern void us_delay( unsigned int);				// delay routines
extern void ms_delay( unsigned int);

extern void init_timers_pwm(void);					// Timers & PWM DAC

extern void set_pwm3_dac(unsigned int);				// LCD back light
extern void set_pwm4_dac(unsigned int);				// LCD contrast

extern void tone_on(int);							// start tone generator, period length
extern void tone_off(void);							// stop tone generator
extern void beep(int, unsigned int);				// generate beep, period, length

extern int encoder_get(void);						// get simulated encoder value

extern void init_adc12(void);
extern int convert_adc12(unsigned int adchs);		// ADC

extern void draw_s_meter(int);						// LCD functions
extern void draw_bar(int, int);
extern void lcdoutch(unsigned char);
extern void lcd_putst(register const char *);
extern void set_chgen(void);
extern void initlcd(void);
extern void clear_lcd(void);
extern void set_cur_lcd(unsigned char);
extern void disp_freq(long);
extern void disp_tx500_freq(long);
extern void disp_rit(int);
extern void disp_meter(int, int);
extern void disp_bcd(char);
extern void lcd_putchhex(unsigned char);

extern void InitUSART1(void);						// terminal functions
extern void SetUSART1baud(int);						// baud rate select
extern void putch(char);
extern unsigned char kbhit(void);
extern unsigned char getch(void);
extern unsigned char getche(void);
extern unsigned long getlong(void);
extern void bin2ascii(unsigned long);
extern void putlong( unsigned long);

extern void service(void);							// service functions
extern void serial_test(void);						// serial I/O
extern void serial_tx500(void);						// TX500 protocol
extern void dump_eeprom(void);						// dump EEPROM content




// Morse Coder
extern void paly_string(char*);						// play Morse string
char test_msg[] = {"JUMA TX500 QRV"};

// 6 or 10MHz ref clock
unsigned long tword;								// DDS tuning word
float hz_bit;										// DDS resolution


// Helper functions

void calc_hz_bit (void)								// calculate Hz/bit from ref osc actual value
	{
	hz_bit = cal.calval.ref_osc[board_type] / DDS_RESOLUTION;
	}

void calc_tword(void)								// calculate DDS tuning word
	{
	tword = ((float)(2 * eeprom.defval.txfreq[board_type])) / hz_bit;
	}


void set_dds(void)									// calculate tuning word & set DDS
	{
	calc_tword();
	tune_ad9833(tword);
	}


// Save defaults

void save_defaults(void)
	{
	int x,y;

	eeprom.defval.d_csum = 0;
	for(x=0; x<(sizeof(struct defval)/2); x++)
		{
		if(x < ((sizeof(struct defval)/2) - 1))
			eeprom.defval.d_csum = eeprom.defval.d_csum + eeprom.storage[x]; 	// calculate mod 0xFFFF checksum
		else
			eeprom.defval.d_csum = 0 - eeprom.defval.d_csum;					// last round, invert checksum

 		y = EraseEE(EEPAGE, (2*x+EEDEF), WORD);
		y = WriteEE(&(eeprom.storage[x]), EEPAGE, (2*x+EEDEF), WORD);			// EEPROM Address 8 high bits, address + physical EEPROM start 16 low bits
		}

 	if(eeprom.defval.serial_mode == 1)	// conditional print only if RS232 = Test
		printf("\n\rWords = %d, Sucess = %d, Checksum = %X", x, y, eeprom.defval.d_csum);	// print EEPROM checksum
	}


// Read defaults

unsigned int read_defaults(void)
	{
	int x,y;
	unsigned int csum;

	csum = 0;
	for(x=0; x<(sizeof(struct defval)/2); x++)
		{
		y = ReadEE(EEPAGE, (2*x+EEDEF), &(eeprom.storage[x]), WORD);	// EEPROM Address 8 high bits, address + physical EEPROM start 16 low bits
// add error checking ?  y = success code

		csum = csum + eeprom.storage[x];								
		}

// read factory defaults reset counter
	ReadEE(EEPAGE, EE_FD_LOC, &fd_counter, WORD);

	return csum;
	}


// Save calibration values

void save_calval(void)
	{
	int x,y;

	cal.calval.c_csum = 0;
	for(x=0; x<(sizeof(struct calval)/2); x++)
		{
		if(x < ((sizeof(struct calval)/2) - 1))
			cal.calval.c_csum = cal.calval.c_csum + cal.ee[x]; // calculate mod 0xFFFF checksum
		else
			cal.calval.c_csum = 0 - cal.calval.c_csum;

		y = EraseEE(EEPAGE, (2*x+EECAL), WORD);
		y = WriteEE(&(cal.ee[x]), EEPAGE, (2*x+EECAL), WORD);			// EEPROM Address 8 high bits, address + physical EEPROM start 16 low bits
		}

 	if(eeprom.defval.serial_mode == 1)	// conditional print only if RS232 = Test
		printf("\n\rWords = %d, Success = %d, Checksum = %X", x, y, cal.calval.c_csum);
	}


// Read calibration values

unsigned int read_calval(void)
	{
	int x,y;
	unsigned int csum;

	csum = 0;
	for(x=0; x<(sizeof(struct calval)/2); x++)
		{
		y = ReadEE(EEPAGE, (2*x+EECAL), &(cal.ee[x]), WORD);			// EEPROM Address 8 high bits, address + physical EEPROM start 16 low bits
		csum = csum + cal.ee[x];
		}
	return csum;
	}

// Read Beacon string, one byte / address

void read_beacon_string(void)
	{
	int x,y,temp;

	for(x=0; x<(sizeof beacon_buffer); x++)
		{
		y = ReadEE(EEPAGE, (2*x+EEBEACON), &temp, WORD);						// EEPROM Address 8 high bits, address + physical EEPROM start 16 low bits
		beacon_buffer[x] = (char)temp;
		}
	}

// Save Beacon string, one byte / address
void save_beacon(void)
	{
	int x,y,temp;

	for(x=0; x<(sizeof beacon_buffer); x++)
		{
		temp = (char)beacon_buffer[x];
		y = EraseEE(EEPAGE, (2*x+EEBEACON), WORD);
		y = WriteEE(&temp, EEPAGE, (2*x+EEBEACON), WORD);						// EEPROM Address 8 high bits, address + physical EEPROM start 16 low bits
		}
	}



// Set factory defaults for EEPROM storage

void set_factory_defaults(void)
	{
	int x;
	eeprom.defval.txfreq[0] = U_DEFAULT_TX_FREQ;	// set default TX frequency
	eeprom.defval.txfreq[1] = TX500_DEFAULT_TX_FREQ;
	eeprom.defval.txfreq[2] = TX136_DEFAULT_TX_FREQ;

	eeprom.defval.rfpwr = 0;						// RF power level
	eeprom.defval.cwspeed = DEFAULT_CW_SPEED;		// CW speed (wpm * 10)
	eeprom.defval.preamp = 0;						// preamp setting, off, 10dB, 20dB
	eeprom.defval.converter = 0;					// 3,5MHz up converter off, on
	eeprom.defval.mox = 0;							// auto PTT
	eeprom.defval.beacon_tx_on = 0;					// beacon transmit on, 0=off, -1=continous, positive number=rounds
	eeprom.defval.pa_state = 0;						// Amplifier state, 0 = standby, 1 = oper, 2 = tune
	eeprom.defval.spare_io = 0;						// SPARE digital I/O = 0

	eeprom.defval.keyer = KEYER;					// set default keyer type, , 0=dot pri, 1=iambic A, 2=iambic B, 3=straight, 4=beacon
	eeprom.defval.cw_sidetone = CW_SIDETONE;		// set default side tone

	eeprom.defval.contrast = DEFAULT_CONTRAST;
	eeprom.defval.back_light = DEFAULT_BL;
	eeprom.defval.serial_mode = SERIAL_MODE;		// 0=TX500, 1=test
	eeprom.defval.br = DEFAULT_BAUD_RATE;			// initial baud rate = 9600

	eeprom.defval.swr_limit[0] = SWR_LIMIT_MIN;		// SWR alarm trip points
	eeprom.defval.swr_limit[1] = SWR_LIMIT_LOW;	
	eeprom.defval.swr_limit[2] = SWR_LIMIT_HI;
	eeprom.defval.swr_limit[3] = SWR_LIMIT_MAX;

// default calibration constant values
	cal.calval.ref_osc[0] = REF_OSC_U;
	cal.calval.ref_osc[1] = REF_OSC_6;				// TX500
	cal.calval.ref_osc[2] = REF_OSC_20;				// TX136

	cal.calval.id_mult = ID_MULT;
	cal.calval.batt_mult = BATT_MULT;
	cal.calval.rev_pwr_mult = REV_PWR_MULT;
	cal.calval.fwd_pwr_mult = FWD_PWR_MULT;
	cal.calval.beep_len = DEFAULT_BEEP_LEN;
	cal.calval.cw_break_time = CW_BREAK_TIME;			// default CW break timer value

// Beacon message
	for(x=0; x < BEACON_BUFFER_SIZE; x++)				// first write nulls
		{
		beacon_buffer[x] =0;
		}
	sprintf(beacon_buffer, "vvv vvv de JUMA Beacon # \r");	// then default beacon message
	save_beacon();											// save immediatelly to the EEPROM

// increment factory default reset counter
	ReadEE(EEPAGE, EE_FD_LOC, &fd_counter, WORD);
	fd_counter++;
// save factory defaults reset counter
	EraseEE(EEPAGE, EE_FD_LOC, WORD);
	WriteEE(&fd_counter, EEPAGE, EE_FD_LOC, WORD);
	}


// calculate SWR

int calc_swr(int fwd, int rev)
	{
//
// Ro = sqrt(Pr/Pf) or Ro = Ur/Uf
// SWR = (1+Ro)/(1-Ro)
//
	int swr;						// calculated swr
	long Ro100;						// 100*Ro
	long x;							// 100*(1-Ro)

	Ro100 = ((long)rev*100L) / fwd;	//  rev/fwd ratio * 100
	x = 100 - Ro100;
	if(x < 1)
		x = 1;						// prevent divide by zero

	if(fwd >= 50)					// calculate only if we have some signal
		swr = (((100 + Ro100)*100) / x);	// 100 * (1+Ro)/(1-Ro)
	else
		swr = 0;					// no swr reading if low power

	if(swr > 9999)
		swr = 9999;					// max display value 99.99

	return(swr);					// value 100 = swr 1.00
	}


// display RF power setting

void disp_rfpwr(void)
	{
		switch(eeprom.defval.rfpwr)	// display selected RF power level
			{
			case 0:
				lcd_putst("PWR MIN");
			break;

			case 1:
				lcd_putst("PWR LOW");
			break;

			case 2:
				lcd_putst("PWR  HI");
			break;

			case 3:
				lcd_putst("PWR MAX");
			break;

			default:
				lcd_putst("PWR ???");
			break;
			}
	}


// display Alarms

void display_alarms(void)
	{
	if(blink == 0)
		{
		lcd_putst("     ");						// show nothing
		alarm_beep = 0;
		}
	else										// show alarm, only highest priority is shown
		{
		if(alarm_beep == 0)						// trigger with rising edge
			{
			alarm_beep = 1;
			beep(HZ698_45, ALARM_BEEP_LEN);		// make sound
			}
		if(alarms & SWR_AL)
			lcd_putst(" SWR ");	
		else
			{
			if(alarms & CURR_AL)
				lcd_putst(" CURR");
			else
				{
				lcd_putst(" ????");				// unknown
				}
			}
		}
	}


// calculate & display bar graph power (forward voltage) meter

void display_pwr_meter(void)
	{
	int temp;
	pwr_meter = (fwd_adval * F_VOLT_GRAPH_MULT) >> 17; 	// forward voltage display
	draw_s_meter(pwr_meter);							// full bar = 60W
	}
 

void disp_fwd_pwr(void)
	{
	int temp;
	long decay_term;

	if(key != 0)								// TXon ?
		{
		if(out_pwr > peak_pwr)					// fast attach
			{
			peak_pwr = out_pwr;					// fast attach
			decay_counter = PEAK_SHOW_TIME;		// reload decay timer
			}

		else									// slow release
			{
			if(decay_counter == 0)
				{
				decay_counter = DECAY_TIME;		// reload decay timer
				decay_term = peak_pwr >> DECAY_RATE;

				if(decay_term == 0)				// zero reached
					peak_pwr = 0;
				else
					peak_pwr = peak_pwr - decay_term;	// decay
				}
			}

		lcd_putst("PWR");
		temp = (peak_pwr * cal.calval.fwd_pwr_mult) >> 16;
		disp_meter(temp, 'w');					// scaling, P*100 = ADC^2 * scaling / 65536		
		}
	else
		{
		disp_rfpwr();							// display setting
		peak_pwr = 0;
		}
	}


// measure & display Drain current meter

void disp_id(void)
	{
	if(key != 0)								// TXon ?
		{
		id_cur = ((long)convert_adc12(ID_CUR) * cal.calval.id_mult) >> 16;
		lcd_putst("I");
		disp_meter(id_cur, 1);	
		lcd_putst("A");
		}
	else
		lcd_putst("I --.-A");
	}


// Handle PWR button. VFO lock, Shut down the system or RF attenuator addjust if TX && TUNE
void power_off(void)
	 {
	beep(HZ466_85, cal.calval.beep_len);								// notify PWR button pressed
	clear_lcd();
	long_push = POWER_OFF;												// load power off guard timer

	while(PWR_SW == 1)
		{
		set_cur_lcd(LINE1);
		sprintf(lcdpbuff, "Pwr OFF after %i  ", (long_push/300));		// display off counter, 5,4,3,2,1,0
		lcd_putst(lcdpbuff);
		set_cur_lcd(LINE2);
		lcd_putst("                ");

		if(long_push == 0)
			{
			beep(HZ392_01, cal.calval.beep_len*2);						// play low sound when ready for power down
			while(PWR_SW == 1)
				{
				}
			}	
		}

	if(long_push != 0)													// too short push, continue normal operation
		return;

	save_defaults();
 	if(eeprom.defval.serial_mode == 1)	// conditional print only if RS232 = Test
		printf("\n\rUser settings saved to EEPROM, Power off\n\r");

	ms_delay(2);														// let the printout finnish
	PWR_ON = 0;
	for(;;)
		{
		}
	}
 

// check if any alarms

void check_alarms(void)
	{
// check over current alarm bit & set alarm
		if(OC)
			{
			CW = 0;											// RF off immediatelly
			alarms = alarms | CURR_AL;						// set alarm flag
			}


// check SWR, two samples neded for trip
		if(swr > eeprom.defval.swr_limit[eeprom.defval.rfpwr] && old_swr > eeprom.defval.swr_limit[eeprom.defval.rfpwr])		// Note, SWR alarm is active also in STBY
			{
			CW = 0;											// RF off immediatelly
			alarms = alarms | SWR_AL;						// set alarm flag
//			printf("\n\rSWR %i,   fwd %i,   rev %i", swr, fwd_adval, rev_adval);	// test
			}

		if(alarms != 0)
			{
			lcd_mode = 0;									// force normal display
			eeprom.defval.pa_state = 0;						// force transmitter to STBY
			eeprom.defval.beacon_tx_on = 0;					// force beacon Off
			}
	}


// Clear alarms & try to reset over current latch

void clear_alarms(void)
	{
	alarms = 0;												// clear alarm flags
	alarm_beep = 0;

	OC_CLR = 0;												// generate reset pulse for over current latch
	ms_delay(20);
	OC_CLR = 1;
	}


void display_cw_speed(void)											// display formatter for CW speed
	{
	if(eeprom.defval.cwspeed < 10)
		sprintf(lcdpbuff, "CW.%.1d",eeprom.defval.cwspeed);			// display 0.1 .. 0.9 wpm
	else
		sprintf(lcdpbuff, "CW%.2d",(eeprom.defval.cwspeed / 10));	// display 1 ... MAX wpm
	lcd_putst(lcdpbuff);
	}


// RS232 loop back test
void rs232_test(void)
	{
	unsigned char c;

	clear_lcd();
	lcd_putst("RS232 Test      ");
	set_cur_lcd(LINE2);
	lcd_putst("Waiting data....");
	for(;;)
		{
		if(kbhit())
			{
			c = getch();
			beep(HZ698_45, 10);				// give beep tone
			putch(c);						// echo character
			set_cur_lcd(LINE2);			
			lcd_putst("RX data  ");
			lcd_putch(c);					// display "as received"
			lcd_putst("  0x");
			lcd_putchhex(c);				// display in HEX format
			}

		if(PWR_SW == 1)						// exit test
			break;
		}
	}


// check I/O board type
int check_io_board_type(void)
	{
	int x, b;
	x = convert_adc12(B_TYPE);				// get board ID voltage
	b = UNKNOWN_TYPE;						// board identified

	if(x > TX500_LOW && x < TX500_HI)		// is it TX500
		b = TX500_TYPE;

	if(x > TX136_LOW && x < TX136_HI)		// is it TX136
		b = TX136_TYPE;

	return b;
	}


// set RF power relays
void set_rf_pwr_relays(void)
	{
	switch(eeprom.defval.rfpwr)
		{
		case 0: default:					// MIN & unknown
			PWR0 = 0;
			PWR1 = 0;
		break;

		case 1:								// LOW
			PWR0 = 1;
			PWR1 = 0;
		break;

		case 2:								// HI
			PWR0 = 0;
			PWR1 = 1;
		break;

		case 3:								// MAX
			PWR0 = 1;
			PWR1 = 1;
		break;

		}
	}


// set pre amplifier
void set_preamp(void)
	{
	if(eeprom.defval.preamp == 0)
		{
		PREAMP_ON = 0;								// bypass preamp
		PREAMP_GAIN = 0;							// gain 10dB
		}
	if(eeprom.defval.preamp == 1)
		{
		PREAMP_ON = 1;								// preamp on
		PREAMP_GAIN = 0;							// gain 10dB					
		}
	if(eeprom.defval.preamp == 2)
		{
		PREAMP_ON = 1;								// preamp on
		PREAMP_GAIN = 1;							// gain 20dB					
		}					
	}


// set 3.5MHz up converter
void set_converter(void)
	{
	if(eeprom.defval.converter == 1)
		MIXER_CLK_ON = 1;							// converter on
	else
		MIXER_CLK_ON = 0;
	}

// calculate CW impulse period from wpm value
void calc_cw_period(void)
	{
//	cw_period = 1200 / eeprom.defval.cwspeed;		// calculete & set period(ms) for the irq system
	cw_period = 12000 / eeprom.defval.cwspeed;		// calculete & set period(ms) for the irq system
	}


// calculate sideone
void calc_sidetone(void)
	{
	sidetone = 	FCY / (eeprom.defval.cw_sidetone * 2);	// calculated sidetone timer set value
	}


// do power measurements
void power_measurements(void)
	{
// Convert fwd & rev A/D channells
			fwd_adval = convert_adc12(FWD_PWR);
			rev_adval = convert_adc12(REV_PWR);

// store not scaled values for later use
			fwd_pwr = (long)fwd_adval * (long)fwd_adval;	// calculate relative power levels ( U^2)
			rev_pwr = (long)rev_adval * (long)rev_adval;
			out_pwr = fwd_pwr - rev_pwr;					// output power = forward - reverse.
			old_swr = swr;									// shift sample queue
			swr = calc_swr(fwd_adval, rev_adval);			// calculate SWR
	}



// main __________________________________________________________________________________

int main(void)
	{
	int x, z, temp;
	unsigned int y, w;
	unsigned char c;
	int *p;
	long ltemp1, ltemp2;
	unsigned long ultemp;
	unsigned int itemp;

// set general I/O
	TRISA = INIT_TRISA;				// SWITCHES, PTT
	PORTA = INIT_PORTA;

	TRISB = INIT_TRISB;				// ADC inputs, TXEN, RXEN, General I/O
	PORTB = INIT_PORTB;

	TRISC = INIT_TRISC;				// sideband select & switches
	PORTC = INIT_PORTC;

	TRISD = INIT_TRISD;				// LEDs & LCD pins = output
	PORTD = INIT_PORTD;

	TRISF = INIT_TRISF;				// DDS controls
	PORTF = INIT_PORTF;

	TRISG = INIT_TRISG;				// DDS controls, EEPROM, DScard signals
	PORTG = INIT_PORTG;


// Power switch
	PWR_ON = 1;								// secure power ON

// start PWM system
	cw_period = 100;						// set something before timer system starts
	init_beacon(beacon_buffer);				// init beacon logic
	IPC0 =0X5444;							// set tone generator (TMR1) priority higher than others
	init_timers_pwm();						// setup pwm & tone generators

	fcy = FCY/1000;							// clock freq (kHz)

// start LCD
	initlcd();								// init LCD
	set_chgen();							// load bar graph fonts

// start UART
	InitUSART1();							// wake up serial interface

// start ADC
	init_adc12();							// setup A/D converter, must be done before Keyer is started, RB I/O bits

// check I/O boards
	board_type = check_io_board_type();		// measure & set main board type


// put hello messages to LCD
	clear_lcd();
	switch(board_type)						// say hello
		{
		case TX500_TYPE:
			lcd_putst("JUMA TX500 ");
		break;

		case TX136_TYPE:
			lcd_putst("JUMA TX136 ");
		break;

		case UNKNOWN_TYPE: default:
			lcd_putst("JUMA ????? ");
		break;
		}
	lcd_putst(ver);							// display version
	set_cur_lcd(LINE2);
	lcd_putst("  OH2NLT OH7SV  ");			// say who we are


// check if service mode start
//	lcd_putst("Power ON");					// wait while power switch is pressed
	service_mode = 0;
	long_push = VERY_LONG_PUSH;				// set long push timer

	while(PWR_SW == 1)
		{
		if(long_push == 0)
			{

			beep(HZ392_01, 300);			// give service beep
			set_cur_lcd(LINE2);	
			lcd_putst("Service Mode    ");
			service_mode = 1;
	
			while(PWR_SW == 1)				// show message as logn as Power switxh is pressed
				{
				}
			set_cur_lcd(LINE1);
			lcd_putst("Push DISPLAY nxt");	// display some instructions
			set_cur_lcd(LINE2);
			lcd_putst("Push OPER = Save");
			}
		}


// Read calibration & default values from EEPROM
	y = read_calval();
	w = read_defaults();

 	if(eeprom.defval.serial_mode == 1)	// conditional print only if RS232 = Test
		printf("\n\rEEPROM checksums, Cal = %X, Def Cs = %X, Factory default resets = %d",y, w, fd_counter);

	if(y != 0 || w != 0)			// compare checksums
		{
		dump_eeprom();				// test, show EEPROM content before reset
		printf("\n\rEEPROM checksum error, reload factory defaults");

		set_factory_defaults();		// EEPROM empty or corrupted, set factory defaults
		save_calval();
		save_defaults();
		}


// set LCD contrast & back light with EEPROM data
	set_pwm4_dac(eeprom.defval.contrast);
	set_pwm3_dac(eeprom.defval.back_light);


// set display mode etc
	lcd_mode = 0;									// select default display
	sub_page0 = 0;

// start up beep
	beep(HZ698_45, cal.calval.beep_len * 2);		// give start up beep

	OC_CLR = 0;										// clear over current latch
	ms_delay(1);
	OC_CLR = 1;

// do calibration fonctions if service mode start
	if(service_mode != 0)
		service();

// check if factory defaults asked
	while(OPER == 0)								// if OPER button pressed ask user what to do
		{
		set_cur_lcd(LINE1);
		lcd_putst("Push SET for    ");
		set_cur_lcd(LINE2);
		lcd_putst("factory defaults");
		if(RFPWR == 0)								// factory defaults asked
			{
			set_factory_defaults();					// EEPROM empty, set factory defaults
			save_calval();
			save_defaults();
			break;
			}
		}


// set user baud rate
	ms_delay(20);									// wait TX empty
	SetUSART1baud(eeprom.defval.br);


// conditional start up text printout, print only if RS232 = Test
 	if(eeprom.defval.serial_mode == 1)
		{
// hello message
		switch(board_type)							// select hello message by board type
			{
			case TX500_TYPE:
				printf("\n\r\n\rJUMA TX500 / ");
			break;

			case TX136_TYPE:
				printf("\n\r\n\rJUMA TX136 / ");
			break;

			case UNKNOWN_TYPE: default:
				printf("\n\r\n\rJUMA Unknown Main Board type/ ");
			break;
			}
		printf(ver);
		printf(" / ");
		printf(date);
		printf("\n\rCopyright Juha Niinikoski, OH2NLT\n\r\n\r");
		printf("System Clock = %i kHz\n\r", fcy);

// serial baud rate info
		if(eeprom.defval.br != DEFAULT_BAUD_RATE)
			printf("\n\rSet UART user baud rate to #%i,  %sbd\n\r", eeprom.defval.br, br_txt[eeprom.defval.br]);	// print with user baud rate

		printf("\n\rCW break time set to %i units",cal.calval.cw_break_time);	// show CW break time setup
		}

// RS232 I/O Test
	if(DISP == 0)						// If Config/DISPLAY pressed during startup
		rs232_test();					// goto RS232 test loop

 	sub_page1 = 0;
 	lcd_mode = 0;

// other
	PTT_OUT_1 = 0;
	PTT_OUT_2 = 0;
	MIXER_CLK_ON = 0;
	SPARE = 0;

// start DDS
//	hz_bit = HZ_BIT;					// set default value, test
	calc_hz_bit();						// calculate Hz/bit from ref osc actual value
	calc_tword();
	init_ad9833();
	tune_ad9833(0);						// keep DDS stopped for now

// keyer setup
	cw_break_time = cal.calval.cw_break_time; // normal cw break time
	calc_cw_period();					// calculate CW period value(ms)
	calc_sidetone();					// calculate sidetone timer value
	read_beacon_string();				// read Beacon message from the EEPROM


// play Morse start up message if defined
// note if in OPER state goes also in to the air
#ifdef MORSE_START_MSG
	ms_delay(200);
	set_cur_lcd(LINE1);
	lcd_putst("          ");
	clear_lcd_morse_buffer();			// clear LCD scroll buffer
	paly_string(&test_msg[0]);			// morse code hello
#else
// wait
	ms_delay(2000);						// show start up message
#endif

	if(board_type == UNKNOWN_TYPE)			// stop here if unknown board
		{
		printf("\n\r\n\rUnknown main board type, press OPER to continue anyway\n\r");
		set_cur_lcd(LINE2);
		lcd_putst("OPER = Continue ");
		while(OPER == 1);				// can continue with OPER button
		}

// start with clean display
	clear_lcd();
		
// Main forever loop _____________________________________________________________________________________________________________

	for(;;)
		{
		MAIN_TEST = !MAIN_TEST;				// timing test

// Make atomic copy of KEY(TX request) signal for this user interface processing round
		if(PTT_OUT_1)						// 1 = active
			key = 1;						// copy I/O bit to status flag	
		else
			key = 0;

// Check alarm conditions
		check_alarms();												// check if any alarms 

// Set keyer active flag 
		if(eeprom.defval.pa_state != 0)		// OPER or TUNE
			cw_active = 1;					// cw active flag for keyer code
		else								// Standby
			cw_active = 0;					// no TX allowed

// set keyer mode
		if(eeprom.defval.pa_state == STATE_TUNE)	// if TUNE selected
			keyer_mode = KEYER_STRAIGHT;			// forse straight
		else										// other conditions
			keyer_mode = eeprom.defval.keyer; 		// set as selected, 4 = Beacon

// Measurements & basic calculations
		power_measurements();


// Do front panel switches

// DISPLAY / FUNC
		if(DISP == 0)												// SW1
			{
			long_push = LONG_PUSH;									// set long push timer

			if(lcd_mode == 0 && sub_page0 == MAX_SUB_PAGE0)
//				beep(HZ466_85, cal.calval.beep_len);				// Bp tone for basic display
				beep(TONE_C, cal.calval.beep_len);					// C tone for basic display
			else
				{
				if(lcd_mode == 1 && sub_page1 == MAX_SUB_PAGE1)
//					beep(HZ466_85, cal.calval.beep_len);			// Bp tone for basic display
					beep(TONE_C, cal.calval.beep_len);				// C tone for basic display
				else
//					beep(HZ587_31, cal.calval.beep_len);			// D tone beep for other displays
					beep(TONE_D, cal.calval.beep_len);				// D tone beep for other displays
				}

			while(DISP == 0)
				{
				if(long_push == 0)
					{
//					beep(HZ466_85, cal.calval.beep_len*10);			// long beep for major page change
					beep(TONE_C, cal.calval.beep_len*10);			// long beep for major page change
					break;
					}
				}
			if(long_push == 0)										// major mode change
				{
				lcd_mode++;
				if(lcd_mode > MAX_LCD_MODE)
					lcd_mode = 0;

				while(DISP == 0)									// wait until button released
					{
					}
				}
			else
				{
				if(lcd_mode == 0)									// select bub page to adjust
					{
					sub_page0++;
					if(sub_page0 > MAX_SUB_PAGE0)
					sub_page0 = 0;
					}
				else
					{
					sub_page1++;
					if(sub_page1 > MAX_SUB_PAGE1)
					sub_page1 = 0;					
					}
				}
			encoder_get();											// clear encoder after display change
			ms_delay(BUTTON_DEBOUNCE);
			}

// Oper button
// operating mode select, long push = beacon TX control
		if(OPER == 0)
			{
			long_push = LONG_PUSH;									// set long push timer

			if(alarms != 0)											// if active alarms, allways change to standby state
				{
				eeprom.defval.pa_state = 0;
				beep(TONE_B, cal.calval.beep_len);					// B tone beep for STANDBY
				}
			else
				{
				switch(eeprom.defval.pa_state)							// sound different tone for each operating state
					{
					case 2:												// next state 0
						beep(TONE_B, cal.calval.beep_len);				// B tone beep for STANDBY
					break;

					case 0:												// next state 1
						beep(TONE_C, cal.calval.beep_len);				// C tone beep for OPER
					break;

					case 1:												// next state 2
						beep(TONE_D, cal.calval.beep_len);				// D tone beep for TUNE
					break;
					}

				while(OPER == 0)
					{
					if(long_push == 0)
						{
						beep(TONE_C, cal.calval.beep_len*10);			// long beep for Beacon mode change
						break;
						}
					}

				if(long_push == 0)										// major mode change
					{
					if(eeprom.defval.beacon_tx_on == 0)					// beacon was off
						{
						if(eeprom.defval.pa_state == 1 && eeprom.defval.keyer == 4)	 // turn it on only when OPER in state and keyer mode = Beacon
							{
							init_beacon(beacon_buffer);					// init beacon logic
							eeprom.defval.beacon_tx_on = -1;			// continous play
							save_defaults();							// save system state, beacon restart automatically after power failure
							}
						}
					else												// beacon was on
						{
						eeprom.defval.beacon_tx_on = 0;					// turn it off
						}
					}

				else
					{
					eeprom.defval.pa_state++;							// increment state
					if(eeprom.defval.pa_state == 3)
						eeprom.defval.pa_state = 0;

					if(eeprom.defval.pa_state != 1 && eeprom.defval.beacon_tx_on != 0)		// everything else but oper stop beacon TX
						{
						eeprom.defval.beacon_tx_on = 0;					// stop beacon
						eeprom.defval.pa_state = 0;						// force STANDBY
						}

					}

				}



			ms_delay(BUTTON_DEBOUNCE);
			while(OPER == 0)
				{
				}

			clear_alarms();													// try to clear alarms
			}



// Freq +/- (PA100 Band buttons)
		if(FREQ_UP == 0)											// Band + button
			{
			if(RFPWR == 0)
				eeprom.defval.txfreq[board_type] = eeprom.defval.txfreq[board_type] + 100;	// speed tune
			else
				eeprom.defval.txfreq[board_type] = eeprom.defval.txfreq[board_type] + 10;	// normal tune

			if(eeprom.defval.txfreq[board_type] > hi_tx_freq[board_type])
				{
				eeprom.defval.txfreq[board_type] = hi_tx_freq[board_type];
//				beep(HZ587_31, cal.calval.beep_len);				// D tone over beep
				beep(TONE_A, cal.calval.beep_len);					// A tone over beep
				}
			else
//				beep(HZ466_85, cal.calval.beep_len);				// Bp tone ok beep
				beep(TONE_D, cal.calval.beep_len);					// D tone ok beep

			calc_tword();											// just calculate new DDS set value

			ms_delay(BUTTON_DEBOUNCE);
			}


		if(FREQ_DN == 0)											// Band - button
			{
			if(RFPWR == 0)
				eeprom.defval.txfreq[board_type] = eeprom.defval.txfreq[board_type] - 100;	// speed tune
			else
				eeprom.defval.txfreq[board_type] = eeprom.defval.txfreq[board_type] - 10;	// normal tune

			if(eeprom.defval.txfreq[board_type] < low_tx_freq[board_type])
				{
				eeprom.defval.txfreq[board_type] = low_tx_freq[board_type];
//				beep(HZ392_01, cal.calval.beep_len);				// G tone under beep
				beep(TONE_A, cal.calval.beep_len);					// A tone under beep
				}
			else
//				beep(HZ466_85, cal.calval.beep_len);				// Bp tone ok beep
				beep(TONE_C, cal.calval.beep_len);					// C tone ok beep
			calc_tword();											// just calculate new DDS set value

			ms_delay(BUTTON_DEBOUNCE);
			}


// RF power
		if(RFPWR == 0 && FREQ_UP == 1 && FREQ_DN == 1)				// RF PWR - button alone
			{
			eeprom.defval.rfpwr++;
#if 0
			if(eeprom.defval.rfpwr > MAX_RFPWR)
				{
				eeprom.defval.rfpwr = 0;
				beep(HZ587_31, cal.calval.beep_len);			// D tone beep whe roll over
				}
			else
				beep(HZ466_85, cal.calval.beep_len);			// Bp tone beep
#endif

			if(eeprom.defval.rfpwr > MAX_RFPWR)					// check roll over
				eeprom.defval.rfpwr = 0;

			switch(eeprom.defval.rfpwr)							// sound different tone for each power level
				{
				case 0:
					beep(TONE_A, cal.calval.beep_len);			// A tone beep
				break;

				case 1:
					beep(TONE_B, cal.calval.beep_len);			// B tone beep
				break;

				case 2:
					beep(TONE_C, cal.calval.beep_len);			// C tone beep
				break;

				case 3:
					beep(TONE_D, cal.calval.beep_len);			// D tone beep
				break;
				}

			ms_delay(BUTTON_DEBOUNCE);
			while(RFPWR == 0)
				{
				}
			}


//____________________________________________________________
// Do I/O

// Main board relays

	set_rf_pwr_relays();										// RF power selector

	set_preamp();												// set pre amplifier

	set_converter();											// select 3,5MHz up converter

	if(eeprom.defval.spare_io == 0)								// set SPARE digital I/O state
		SPARE = 0;
	else
		SPARE = 1;

//____________________________________________________________
// Beacon

	if(eeprom.defval.beacon_tx_on != 0)
		{
		cw_break_time = cal.calval.cw_break_time * 4;			// extended cw break time
		run_beacon();
		}
	else
		{
		cw_break_time = cal.calval.cw_break_time;				// normal cw break time
		}

//_____________________________________________________________
// Do LCD display

		set_cur_lcd(LINE1);										// start from line 1
		switch(lcd_mode)										// select major page to display
			{

// Normal display
			case 0: default:

// addjust CW speed(wpm) if UP / DOWN buttons pressed
			temp = encoder_get();
#if 0
// addjust down to min_cw_speed
			if(temp != 0)										// action only if buttons pressed
				{
				if(temp < 0)									// tone test
					beep(TONE_C, cal.calval.beep_len);			// C tone down
				else
					beep(TONE_D, cal.calval.beep_len);			// C tone up

				if(eeprom.defval.cwspeed > 10)
					{
					eeprom.defval.cwspeed = (eeprom.defval.cwspeed / 10) * 10;		// clear 0.1 wpm units
					eeprom.defval.cwspeed = eeprom.defval.cwspeed + (temp * 10);	// step = 10, 1.0 wpm
					}
				else
					eeprom.defval.cwspeed = eeprom.defval.cwspeed + temp;			// step = 1, 0.1 wpm

				if(eeprom.defval.cwspeed < MIN_CW_SPEED)		// keep within limits
					eeprom.defval.cwspeed = MIN_CW_SPEED;
				if(eeprom.defval.cwspeed > MAX_CW_SPEED)
					eeprom.defval.cwspeed = MAX_CW_SPEED;
				calc_cw_period();
				}
#endif

// addjust down to user interface min_cw_speed
			if(temp != 0)										// action only if buttons pressed
				{
				if(temp < 0)									// tone test
					beep(TONE_C, cal.calval.beep_len);			// C tone down
				else
					beep(TONE_D, cal.calval.beep_len);			// C tone up

				eeprom.defval.cwspeed = (eeprom.defval.cwspeed / 10) * 10;		// clear 0.1 wpm units
				eeprom.defval.cwspeed = eeprom.defval.cwspeed + (temp * 10);	// step = 10, 1.0 wpm

				if(eeprom.defval.cwspeed < MIN_UI_CW_SPEED)		// keep within limits
					eeprom.defval.cwspeed = MIN_UI_CW_SPEED;
				if(eeprom.defval.cwspeed > MAX_CW_SPEED)
					eeprom.defval.cwspeed = MAX_CW_SPEED;
				calc_cw_period();
				}

// first draw graphical power meter
				if(eeprom.defval.keyer != 4)					// not in Beacon mode
					{
					display_pwr_meter();						// show PWR meter bar graph
					lcdoutch(S_BAR);							// PWR-meter stopper bar
					}
				else											// Beacon
					{
					if(eeprom.defval.beacon_tx_on == 0)
//						lcd_putst("Bcon Off ");
						lcd_putst(" BEACON  ");
					else
//						lcd_putst("Bcon On  ");					// rolling beacon message ower write this
						lcd_putst(lcd_m_buf);					// display morse code buffer
					}


// select meter to display
				switch(sub_page0)								// select meter
					{
// Power
					case 0: default:							// normal display
						disp_fwd_pwr();							// display watt meter
					break;

// SWR
					case 1:										// forward power
						lcd_putst("SWR");
						if(swr == 0)							// no reliable reading
							lcd_putst(" N/A ");
						else
							disp_meter(swr, 2);					// display swr		
					break;


// battery voltage
					case 2:										// battery voltage mean value, measure only when display selected
					batt_mean_val = batt_mean_val + convert_adc12(BATT_CH);								// measure & add
					bat_samples++;																		// add sample counter
					if(bat_samples > 15)																// 16 samples done ?
						{
						bat_samples = 0;	
						ultemp = (batt_mean_val >> 4) * cal.calval.batt_mult;							// scale Battery voltage
						batt_mean_val = 0;	
						batt = ultemp >> 8;																// div by 256, save scaled value

						lcd_putst(" ");
						disp_meter(batt, 2);															// display with two decimals								
						lcd_putst("V");
						}
					break;


// PA drain current
					case 3:										// Drain current, measure only when display selected
						disp_id();								// measure & display drain current
					break;
					}

// second line
				set_cur_lcd(LINE2);								// second display line

				if(alarms !=0)									// alarm display
					{
					display_cw_speed();							// display formatter for CW speed

					display_alarms();

					lcdoutch(' ');
					disp_tx500_freq(eeprom.defval.txfreq[board_type]);
					}

				else											// normal display
					{
					if(	key == 1)
						{
						display_cw_speed();
						sprintf(lcdpbuff, "  TX  ");
						lcd_putst(lcdpbuff);
						disp_tx500_freq(eeprom.defval.txfreq[board_type]);	// display frequency
						}
					else
						{
						switch(eeprom.defval.pa_state)
							{
							case 0:
								display_cw_speed();
								sprintf(lcdpbuff, " STBY ",eeprom.defval.cwspeed);
							break;

							case 1:
								display_cw_speed();
								sprintf(lcdpbuff, " OPER ",eeprom.defval.cwspeed);
							break;

							case 2:
								display_cw_speed();
								sprintf(lcdpbuff, " TUNE ",eeprom.defval.cwspeed);
							break;
							}

						lcd_putst(lcdpbuff);
						disp_tx500_freq(eeprom.defval.txfreq[board_type]);	// display frequency
						}
					}


				break;											// end of main display #0


//________________________________________________________________________________________________
//
// User setup display page
			case 1:

// select sub mode
			switch(sub_page1)										// select sub page to display
					{

// Preamplifier setup				
					case 0:
					set_cur_lcd(LINE1);
					lcd_putst("Pre Amplifier   ");
					set_cur_lcd(LINE2);
					eeprom.defval.preamp = eeprom.defval.preamp + encoder_get();						// addjust preamp settings

					if(eeprom.defval.preamp < 0)														// keep within limits
						eeprom.defval.preamp = 0;
					if(eeprom.defval.preamp > 2)
						eeprom.defval.preamp = 2;

					lcd_putst("Select = ");

					if(eeprom.defval.preamp == 0)
						lcd_putst("OFF    ");
					if(eeprom.defval.preamp == 1)
						lcd_putst("10dB   ");
					if(eeprom.defval.preamp == 2)
						lcd_putst("20dB   ");
					break;


// Converter on/off				
					case 1:
					set_cur_lcd(LINE1);

//					lcd_putst("Up Converter    ");
					switch(board_type)
							{
							case 0:
								lcd_putst("???MHz converter");
							break;

							case 1:
								lcd_putst("3.5MHz converter");
							break;

							case 2:
								lcd_putst("10MHz converter");
							break;
							}

					set_cur_lcd(LINE2);
					eeprom.defval.converter = eeprom.defval.converter + encoder_get();					// converter on /off

					if(eeprom.defval.converter < 0)														// keep within limits
						eeprom.defval.converter = 0;
					if(eeprom.defval.converter > 1)
						eeprom.defval.converter = 1;

					lcd_putst("Select = ");

					if(eeprom.defval.converter == 0)
						lcd_putst("OFF    ");
					if(eeprom.defval.converter == 1)
						lcd_putst("ON     ");
					break;


// Sidetone setup				
					case 2:
					set_cur_lcd(LINE1);
					lcd_putst("CW Sidetone     ");
					set_cur_lcd(LINE2);
					temp = encoder_get();
					eeprom.defval.cw_sidetone = eeprom.defval.cw_sidetone + (temp * CW_SIDETONE_STEP);
					if(eeprom.defval.cw_sidetone > CW_SIDETONE_HI)
						eeprom.defval.cw_sidetone = CW_SIDETONE_HI;
					if(eeprom.defval.cw_sidetone < CW_SIDETONE_LOW)
						eeprom.defval.cw_sidetone = CW_SIDETONE_LOW;

					if(eeprom.defval.cw_sidetone == CW_SIDETONE_OFF)
						sprintf(lcdpbuff, "Tone = OFF      ");
					else
						sprintf(lcdpbuff, "Tone = %iHz      ",eeprom.defval.cw_sidetone);

					lcd_putst(lcdpbuff);
					calc_sidetone();																// calculate new timer value

					if(temp != 0)																	// if encoder changed
							beep(sidetone, cal.calval.beep_len);									// test sound
					break;


// SWR alarm limit				
					case 3:
					set_cur_lcd(LINE1);
					lcd_putst("SWR Prot ");
					disp_rfpwr();																// display RF power level
					set_cur_lcd(LINE2);
					eeprom.defval.swr_limit[eeprom.defval.rfpwr] = eeprom.defval.swr_limit[eeprom.defval.rfpwr] + (encoder_get()*10);
					if(eeprom.defval.swr_limit[eeprom.defval.rfpwr] > MAX_SWR)
						eeprom.defval.swr_limit[eeprom.defval.rfpwr] = MAX_SWR;
					if(eeprom.defval.swr_limit[eeprom.defval.rfpwr] < 100)						// 1.00
						eeprom.defval.swr_limit[eeprom.defval.rfpwr] = 100;

					lcd_putst("Limit = ");
					disp_meter(eeprom.defval.swr_limit[eeprom.defval.rfpwr], 2);				// display swr meter
					lcd_putst("    ");
					break;


// Keyer mode
					case 4:
					set_cur_lcd(LINE1);
					lcd_putst("Keyer type      ");
					set_cur_lcd(LINE2);
					eeprom.defval.keyer = eeprom.defval.keyer + encoder_get();					// addjust keyer operating mode
					if(eeprom.defval.keyer < 0)													// keep within limits
						eeprom.defval.keyer = 0;
					if(eeprom.defval.keyer > 4)
						eeprom.defval.keyer = 4;

					switch(eeprom.defval.keyer)
						{
						case 0:
							lcd_putst("Keyer = Dot pri.");
						break;

						case 1:
							lcd_putst("Keyer = Iambic A");
						break;

						case 2:
							lcd_putst("Keyer = Iambic B");
						break;

						case 3:
							lcd_putst("Keyer = Straight");
						break;

						case 4:
							lcd_putst("Keyer = Beacon  ");
						break;
						}


					if(eeprom.defval.keyer != 4)						// stop beacon TX if it was on if any other type than beacon selected
						eeprom.defval.beacon_tx_on = 0;					// stop beacon

					break;


// LCD back light				
					case 5: default:
					set_cur_lcd(LINE1);
					lcd_putst("Displ Brightness");
					set_cur_lcd(LINE2);
					eeprom.defval.back_light = eeprom.defval.back_light + encoder_get();
					if(eeprom.defval.back_light > MAX_BL)
						eeprom.defval.back_light = MAX_BL;
					if(eeprom.defval.back_light < 0)
						eeprom.defval.back_light = 0;
					sprintf(lcdpbuff, "LCD BL = %i      ",eeprom.defval.back_light);
					lcd_putst(lcdpbuff);
					set_pwm3_dac(eeprom.defval.back_light);
					break;


// LCD Contrast
					case 6:
					set_cur_lcd(LINE1);
					lcd_putst("Display Contrast");
					set_cur_lcd(LINE2);
					eeprom.defval.contrast = eeprom.defval.contrast + (encoder_get()*50);
					if(eeprom.defval.contrast > MAX_CONTRAST)
						eeprom.defval.contrast = MAX_CONTRAST;
					if(eeprom.defval.contrast < 0)
						eeprom.defval.contrast = 0;
					sprintf(lcdpbuff, "Contrast = %i  ",eeprom.defval.contrast);
					lcd_putst(lcdpbuff);
					set_pwm4_dac(eeprom.defval.contrast);
					break;


// Serial I/O mode select
					case 7:
					set_cur_lcd(LINE1);
					lcd_putst("Serial Protocol ");
					set_cur_lcd(LINE2);
					eeprom.defval.serial_mode = eeprom.defval.serial_mode + encoder_get();				// addjust serial mode
					if(eeprom.defval.serial_mode < 0)													// keep within limits
						eeprom.defval.serial_mode = 0;
					if(eeprom.defval.serial_mode > 1)
						eeprom.defval.serial_mode = 1;

					lcd_putst("RS232 =");
					if(eeprom.defval.serial_mode == 0)
						lcd_putst("TX136/500");
					if(eeprom.defval.serial_mode == 1)
//						lcd_putst(" Test    ");
						lcd_putst(" Terminal");
					break;


// Select user UART1 baud rate
					case 8:
					set_cur_lcd(LINE1);
					lcd_putst("Serial Speed    ");
					set_cur_lcd(LINE2);
					itemp = encoder_get();																// get encoder change
					if(itemp != 0)																		// changed
						{
						eeprom.defval.br = eeprom.defval.br + itemp;									// addjust baud rate
						if(eeprom.defval.br < 0)														// keep within limits
							eeprom.defval.br = 0;
						if(eeprom.defval.br > 7)
							eeprom.defval.br = 7;

						SetUSART1baud(eeprom.defval.br);												// set new baud rate
						}

					sprintf(lcdpbuff, "Baud Rate=%s",br_txt[eeprom.defval.br]);							// display current selection
					lcd_putst(lcdpbuff);
					break;

// MOX on/off				
					case 9:
					set_cur_lcd(LINE1);
					lcd_putst("TX Control      ");														// manually operated TX, 1=manual TX, 0=auto
					set_cur_lcd(LINE2);
//					eeprom.defval.mox = eeprom.defval.mox + encoder_get();								// UP = MOX, DOWN = AUTO
					eeprom.defval.mox = eeprom.defval.mox - encoder_get();								// UP = Auto, DOWN = MOX

					if(eeprom.defval.mox < 0)															// keep within limits
						eeprom.defval.mox = 0;				
					if(eeprom.defval.mox > 1)
						eeprom.defval.mox = 1;

					lcd_putst("Select = ");

					if(eeprom.defval.mox == 0)
						lcd_putst("Auto   ");					// keyer logic control
					else
						lcd_putst("MOX    ");					// external PTT IN
					break;

// SPARE I/O signal on/off				
					case 10:
					set_cur_lcd(LINE1);
					lcd_putst("SPARE I/O signal");

					set_cur_lcd(LINE2);
					eeprom.defval.spare_io = eeprom.defval.spare_io + encoder_get();					// converter on /off

					if(eeprom.defval.spare_io < 0)														// keep within limits
						eeprom.defval.spare_io = 0;
					if(eeprom.defval.spare_io > 1)
						eeprom.defval.spare_io = 1;

					lcd_putst("Select = ");

					if(eeprom.defval.spare_io == 0)
						lcd_putst("OFF    ");
					if(eeprom.defval.spare_io == 1)
						lcd_putst("ON     ");
					break;

					}					// end switch sub_page1
				break;					// end of main disp #1
			}							// switch(lcd_mode)  end
	

// run serial interface functions

		switch(eeprom.defval.serial_mode)
			{
			case 0:
				serial_tx500();					// TX500 / TX136 protocol
			break;

			case 1: default:
				serial_test();					// test commands
			break;
			}


// Power switch

		if(PWR_SW == 1)
			power_off();						// go shut down


		}	// end for(;;)
	}		// end main

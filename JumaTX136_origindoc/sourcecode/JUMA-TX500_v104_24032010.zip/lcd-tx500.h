/* 2 * 16 LCD display memory layout */

#define LINE1     0x00         /* line 1 start address */
#define LINE2     0x40         /* line 2 start address */


#define CURSET     0x80         /* set memory cursor */
#define	CLEAR	   0x01			/* clear display */
#define ADRSET	   0x40			/* set cgram address */

